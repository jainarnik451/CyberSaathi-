"""Early-warning network, user side. Reports hold only fixed choices; alerts are published only after a
moderator approves them (owner side: owner_community.py). Users see published alerts and aggregates only."""
import uuid
from datetime import date, timedelta

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import AuthContext, require_user
from app.community import alerts as alert_logic
from app.community import reports as report_logic
from app.community import similarity
from app.core.config import settings
from app.database.session import get_db
from app.models.features import AlertFlag, CommunityAlert, CommunityReport
from app.security.rate_limit import rate_limit
from app.services.features import feature_enabled

router = APIRouter(prefix="/community", tags=["community"])


def _require(db: Session) -> None:
    if not feature_enabled(db, "community"):
        raise HTTPException(status_code=404, detail="This feature is not available right now")


def _key(user_id) -> str:
    return report_logic.reporter_key(user_id, settings.secret_key)


def report_dicts(db: Session, since_weeks: int = 12) -> list[dict]:
    since = (report_logic.week_start(date.today()) - timedelta(weeks=since_weeks)).isoformat()
    rows = db.execute(select(CommunityReport).where(CommunityReport.week >= since).order_by(CommunityReport.created_at)).scalars().all()
    return [{"scam_type": r.scam_type, "channel": r.channel, "tactics": [t for t in r.tactics.split(",") if t],
             "week": r.week, "reporter": r.reporter_key, "payment_requested": r.payment_requested} for r in rows]


@router.post("/reports", dependencies=[Depends(rate_limit("community-report", 10, 3600))])
def submit_report(payload: dict = Body(...), ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db)
    try:
        clean = report_logic.clean_report(payload, date.today())
    except report_logic.ReportError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from None
    key, fp = _key(ctx.user.id), report_logic.fingerprint(clean)
    db.add(CommunityReport(reporter_key=key, fingerprint=fp, scam_type=clean["scam_type"], channel=clean["channel"],
                           tactics=",".join(clean["tactics"]), payment_requested=clean["payment_requested"],
                           region=clean["region"], week=clean["week"]))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return {"status": "duplicate", "message": "You already reported this same pattern this week, so it was not counted twice."}
    return {"status": "received", "message": "Thank you. Your report was stored without any personal details. It only counts toward a "
                                              "published alert after several people report the pattern and a moderator reviews it."}


@router.get("/alerts")
def published_alerts(ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db)
    rows = db.execute(select(CommunityAlert).where(CommunityAlert.status == "PUBLISHED")
                      .order_by(CommunityAlert.published_at.desc())).scalars().all()
    views = [alert_logic.public_view({
        "id": str(r.id), "title": r.title, "body": r.body, "disclaimer": alert_logic.DISCLAIMER, "scam_type": r.scam_type,
        "channel": r.channel, "published_at": r.published_at.isoformat() if r.published_at else None,
        "reporter_count": r.reporter_count, "status": r.status}) for r in rows]
    return {"alerts": [v for v in views if v]}


@router.post("/alerts/{alert_id}/flag", dependencies=[Depends(rate_limit("alert-flag", 20, 3600))])
def flag_inaccurate(alert_id: str, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db)
    try:
        aid = uuid.UUID(alert_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Alert not found") from None
    alert = db.get(CommunityAlert, aid)
    if alert is None or alert.status != "PUBLISHED":
        raise HTTPException(status_code=404, detail="Alert not found")
    db.add(AlertFlag(alert_id=aid, flagger_key=_key(ctx.user.id)))
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        return {"status": "already_flagged", "message": "You have already told us about this alert."}
    distinct = db.scalar(select(func.count(func.distinct(AlertFlag.flagger_key))).where(AlertFlag.alert_id == aid)) or 0
    new_status = alert_logic.status_after_flag(alert.status, distinct)
    if new_status != alert.status:
        alert.status = new_status
    db.commit()
    return {"status": "flagged", "message": "Thank you. A moderator will review this alert."}


@router.get("/trends")
def trends(ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    """Aggregates only. Patterns reported by fewer than MIN_REPORTERS different people are NOT shown, so small
    groups cannot be picked out."""
    _require(db)
    reports = report_dicts(db)
    groups = [g for g in similarity.group_reports(reports) if g["distinct_reporters"] >= alert_logic.MIN_REPORTERS]
    return {"weekly": similarity.weekly_trend(reports), "total_reports_last_12_weeks": len(reports),
            "patterns": [{"scam_type": g["scam_type"], "channel": g["channel"], "reporter_count": g["distinct_reporters"],
                          "first_week": g["first_week"], "last_week": g["last_week"], "tactic_counts": g["tactic_counts"]} for g in groups],
            "note": f"Patterns with fewer than {alert_logic.MIN_REPORTERS} different reporters are hidden to protect privacy. Reports are unverified."}
