"""Founder Control Centre API.

Every route here MUST declare `require_permission(...)`. tests/test_owner_guards.py parses this file
and fails the build if any route does not (deny by default).
"""
import os
import time
import uuid
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select, text, update
from sqlalchemy.orm import Session

from app.api.deps import AuthContext, require_permission
from app.control import analytics as analytics_logic
from app.control import features as feature_logic
from app.control.backup_status import read_backup_status
from app.control.devstatus import read_status_file
from app.control.health import (
    backup_component_status, disk_status, overall_status, probe_database, provider_status,
)
from app.control.metrics import collector
from app.control.modules import module_report
from app.control.notify import DEFAULT_PREFS
from app.control.providers import merge_with_observed, provider_monitor
from app.core.config import settings
from app.database.session import get_db
from app.models.base import utcnow
from app.models.ops import AuditLog, Notification, SecurityEvent
from app.models.platform import ApplicationRelease, FeatureFlag, NotificationPreference
from app.models.user import LoginHistory, User, UserSession
from app.schemas.base import MessageResponse
from app.schemas.owner import (
    AuditLogOut, ConfirmRequest, FeatureUpdate, NotificationOut, NotificationPrefsOut, NotificationPrefsUpdate,
    ReleaseOut, SecurityEventOut, SecurityEventUpdate, UserAdminOut, UserDetailOut, UserRoleUpdate, UserStatusUpdate,
)
from app.security import rbac
from app.security.sessions import revoke_all_sessions
from app.security.sqlsafe import escape_like
from app.services.audit import record_audit, verify_chain
from app.services.features import load_overrides
from app.services.usage import analysis_counts, usage_summary
from app.services.security_events import record_security_event

router = APIRouter(prefix="/owner", tags=["owner"])


def _has_secret(value) -> bool:
    return bool(value and value.get_secret_value())


def _provider_component(provider: str, api_key) -> dict:
    static = provider_status(provider, _has_secret(api_key))
    return merge_with_observed(static, provider_monitor.summary(provider or "none", 60))


# ------------------------------------------------------------------ overview
@router.get("/overview")
def overview(ctx: AuthContext = Depends(require_permission(rbac.OWNER_OVERVIEW_READ)),
             db: Session = Depends(get_db)):
    now = utcnow()

    def count(stmt):
        return db.scalar(stmt) or 0

    users = select(func.count()).select_from(User)
    day = func.date(User.created_at)
    registrations = db.execute(select(day, func.count()).where(User.created_at >= now - timedelta(days=14))
                               .group_by(day).order_by(day)).all()
    sev_rows = db.execute(select(SecurityEvent.severity, func.count()).where(SecurityEvent.status != "RESOLVED")
                          .group_by(SecurityEvent.severity)).all()
    return {
        "users_total": count(users),
        "users_active_30d": count(users.where(User.last_login_at > now - timedelta(days=30))),
        "users_new_7d": count(users.where(User.created_at > now - timedelta(days=7))),
        "users_suspended": count(users.where(User.status == "SUSPENDED")),
        "users_by_role": {role: n for role, n in db.execute(select(User.role, func.count()).group_by(User.role)).all()},
        "users_by_status": {s: n for s, n in db.execute(select(User.status, func.count()).group_by(User.status)).all()},
        "registrations_last_14_days": [{"date": str(d), "count": n} for d, n in registrations],
        "open_security_events_by_severity": {sev: n for sev, n in sev_rows},
        "unread_notifications": count(select(func.count()).select_from(Notification).where(
            Notification.recipient_user_id == ctx.user.id, Notification.read_at.is_(None))),
        "modules": module_report(analysis_counts(db)),
        "usage": usage_summary(db),
        "requests_last_60_minutes": collector.summary(60),
        "data_source": "database",
    }


@router.get("/modules")
def modules(ctx: AuthContext = Depends(require_permission(rbac.OWNER_OVERVIEW_READ)),
            db: Session = Depends(get_db)):
    return {"modules": module_report(analysis_counts(db))}


# -------------------------------------------------------------------- health
@router.get("/health")
def platform_health(ctx: AuthContext = Depends(require_permission(rbac.OWNER_HEALTH_READ)),
                    db: Session = Depends(get_db)):
    now = utcnow()
    backup = read_backup_status(settings.backup_dir or None, now, settings.backup_max_age_hours)
    components = {
        "backend": {"status": "ok", "version": settings.backend_version, "environment": settings.environment,
                    "uptime_seconds": int(time.time() - collector.started_at)},
        "database": {**probe_database(lambda: db.execute(text("SELECT 1"))), "dialect": db.get_bind().dialect.name},
        "storage": disk_status(os.getcwd()),
        "ai_provider": _provider_component(settings.ai_provider, settings.ai_api_key),
        "threat_intelligence": _provider_component(settings.threat_intel_provider, settings.threat_intel_api_key),
        "background_tasks": {"status": "not_implemented", "detail": "No background task runner exists yet."},
        "email": merge_with_observed(
            {"status": {"disabled": "not_configured", "dev_outbox": "dev_only"}.get(settings.email_backend, "configured_unverified"),
             "backend": settings.email_backend}, provider_monitor.summary("email")),
        "backup": {"status": backup_component_status(backup["status"]), "backup_status": backup["status"],
                   "last_success_at": backup["last_success_at"]},
        "frontend": {"status": "not_measured", "detail": "The API cannot observe browsers; the public web app is not built."},
    }
    return {
        "overall": overall_status({name: c["status"] for name, c in components.items()}),
        "checked_at": now.isoformat(),
        "components": components,
        "requests": {"last_5_minutes": collector.summary(5), "last_60_minutes": collector.summary(60),
                     "per_minute": collector.series(30)},
        "notes": ["Request metrics are in memory, per process, and reset on restart.",
                  "If the database is down this API cannot authenticate you; use /readyz from an external monitor."],
    }


# ------------------------------------------------------------ AI monitoring
@router.get("/ai-monitoring")
def ai_monitoring(ctx: AuthContext = Depends(require_permission(rbac.OWNER_HEALTH_READ))):
    out = {}
    for label, provider, key in (("ai_provider", settings.ai_provider, settings.ai_api_key),
                                 ("threat_intelligence", settings.threat_intel_provider, settings.threat_intel_api_key)):
        static = provider_status(provider, _has_secret(key))
        out[label] = {"configuration": static,
                      "observed_last_60_minutes": provider_monitor.summary(provider or "none", 60),
                      "observed_last_24_hours": provider_monitor.summary(provider or "none", 1440)}
    return {"providers": out,
            "notes": ["Availability comes from real calls recorded by provider adapters. 'no_data' means no call "
                      "has been recorded, which is not the same as healthy.",
                      "Only error class names are kept: never prompts, responses or error messages.",
                      "In memory, per process, resets on restart. No AI provider adapter exists yet."]}


# -------------------------------------------------------- business analytics
@router.get("/analytics")
def analytics(days: int = Query(30, ge=7, le=90),
              ctx: AuthContext = Depends(require_permission(rbac.OWNER_OVERVIEW_READ)),
              db: Session = Depends(get_db)):
    end = utcnow().date()
    start = end - timedelta(days=days - 1)
    first_moment = utcnow().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days - 1)

    def by_day(stmt):
        return {date.fromisoformat(str(d)): n for d, n in db.execute(stmt).all()}

    reg_day = func.date(User.created_at)
    login_day = func.date(LoginHistory.created_at)
    registrations = by_day(select(reg_day, func.count()).where(User.created_at >= first_moment).group_by(reg_day))
    signins = by_day(select(login_day, func.count()).where(
        LoginHistory.success.is_(True), LoginHistory.created_at >= first_moment).group_by(login_day))
    active = by_day(select(login_day, func.count(func.distinct(LoginHistory.user_id))).where(
        LoginHistory.success.is_(True), LoginHistory.user_id.is_not(None),
        LoginHistory.created_at >= first_moment).group_by(login_day))
    total = db.scalar(select(func.count()).select_from(User)) or 0
    before = db.scalar(select(func.count()).select_from(User).where(User.created_at < first_moment)) or 0

    def count_where(*conds):
        return db.scalar(select(func.count()).select_from(User).where(*conds)) or 0

    totals = {"users_total": total, "verified": count_where(User.email_verified.is_(True)),
              "mfa_enabled": count_where(User.mfa_enabled.is_(True)),
              "suspended": count_where(User.status == "SUSPENDED"),
              "pending_deletion": count_where(User.status == "PENDING_DELETION")}
    report = analytics_logic.build_growth_report(end=end, days=days, registrations=registrations,
                                                 active_users=active, signins=signins,
                                                 users_before_window=before, totals=totals)
    report["from"] = start.isoformat()
    report["usage"] = usage_summary(db)
    report["data_source"] = "database"
    return report


# --------------------------------------------------------------------- users
@router.get("/users", response_model=list[UserAdminOut])
def list_users(q: str | None = Query(default=None, max_length=100), role: str | None = None,
               status: str | None = None, page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=100),
               ctx: AuthContext = Depends(require_permission(rbac.OWNER_USERS_READ)),
               db: Session = Depends(get_db)):
    stmt = select(User)
    if q:
        # Bound parameter (no SQL injection); wildcards typed by the searcher are made literal.
        stmt = stmt.where(User.email.ilike(f"%{escape_like(q.lower())}%", escape="\\"))
    if role:
        stmt = stmt.where(User.role == role)
    if status:
        stmt = stmt.where(User.status == status)
    stmt = stmt.order_by(User.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    return db.execute(stmt).scalars().all()


@router.get("/users/{user_id}", response_model=UserDetailOut)
def user_detail(user_id: uuid.UUID, ctx: AuthContext = Depends(require_permission(rbac.OWNER_USERS_READ)),
                db: Session = Depends(get_db)):
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")
    now = utcnow()
    active = db.scalar(select(func.count()).select_from(UserSession).where(
        UserSession.user_id == target.id, UserSession.revoked_at.is_(None), UserSession.expires_at > now)) or 0
    failed = db.scalar(select(func.count()).select_from(LoginHistory).where(
        LoginHistory.user_id == target.id, LoginHistory.success.is_(False),
        LoginHistory.created_at > now - timedelta(hours=24))) or 0
    return UserDetailOut.model_validate({**UserAdminOut.model_validate(target).model_dump(),
                                         "active_sessions": active, "failed_logins_24h": failed})


@router.patch("/users/{user_id}/status", response_model=UserAdminOut)
def update_user_status(user_id: uuid.UUID, payload: UserStatusUpdate,
                       ctx: AuthContext = Depends(require_permission(rbac.OWNER_USERS_WRITE)),
                       db: Session = Depends(get_db)):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Confirmation required (set confirm=true)")
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == ctx.user.id or target.role == rbac.Role.OWNER.value:
        raise HTTPException(status_code=400, detail="Owner accounts cannot be suspended")
    if payload.status == "SUSPENDED":
        if not payload.reason or not payload.reason.strip():
            raise HTTPException(status_code=422, detail="A reason is required to suspend an account")
        target.status = "SUSPENDED"
        target.suspended_reason = payload.reason.strip()
        revoke_all_sessions(db, target.id)
    else:
        target.status = "ACTIVE"
        target.suspended_reason = None
    record_audit(db, actor_id=ctx.user.id, action=f"user.status.{payload.status.lower()}", target_type="user",
                 target_id=target.id, metadata={"reason": payload.reason})
    db.commit()
    return target


@router.patch("/users/{user_id}/role", response_model=UserAdminOut)
def update_user_role(user_id: uuid.UUID, payload: UserRoleUpdate,
                     ctx: AuthContext = Depends(require_permission(rbac.OWNER_ROLES_WRITE)),
                     db: Session = Depends(get_db)):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Confirmation required (set confirm=true)")
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == ctx.user.id or target.role == rbac.Role.OWNER.value:
        raise HTTPException(status_code=400, detail="The owner role cannot be changed")
    if target.status != "ACTIVE" or not target.email_verified:
        raise HTTPException(status_code=409, detail="Only active, email-verified accounts can change role")
    if target.role == payload.role:
        raise HTTPException(status_code=409, detail="The account already has this role")
    old_role = target.role
    target.role = payload.role
    # Force a fresh sign-in so MFA enrolment/verification is evaluated under the new role.
    revoke_all_sessions(db, target.id)
    record_audit(db, actor_id=ctx.user.id, action="user.role.change", target_type="user", target_id=target.id,
                 metadata={"from": old_role, "to": payload.role, "reason": payload.reason})
    if rbac.is_privileged(old_role) or rbac.is_privileged(payload.role):
        record_security_event(db, category="ADMIN_ROLE_CHANGE", severity="HIGH", component="rbac",
                              metadata={"target": str(target.id), "from": old_role, "to": payload.role})
    db.commit()
    return target


@router.post("/users/{user_id}/revoke-sessions", response_model=MessageResponse)
def revoke_user_sessions(user_id: uuid.UUID, payload: ConfirmRequest,
                         ctx: AuthContext = Depends(require_permission(rbac.OWNER_USERS_WRITE)),
                         db: Session = Depends(get_db)):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Confirmation required (set confirm=true)")
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == ctx.user.id:
        raise HTTPException(status_code=400, detail="Use sign out to end your own session")
    revoked = revoke_all_sessions(db, target.id)
    record_audit(db, actor_id=ctx.user.id, action="user.sessions.revoke", target_type="user", target_id=target.id,
                 metadata={"revoked": revoked})
    db.commit()
    return MessageResponse(message=f"Revoked {revoked} session(s)")


# ----------------------------------------------------------- security events
@router.get("/security-events", response_model=list[SecurityEventOut])
def list_security_events(severity: str | None = None, status: str | None = None, category: str | None = None,
                         page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=100),
                         ctx: AuthContext = Depends(require_permission(rbac.SECURITY_EVENTS_READ)),
                         db: Session = Depends(get_db)):
    stmt = select(SecurityEvent)
    if severity:
        stmt = stmt.where(SecurityEvent.severity == severity)
    if status:
        stmt = stmt.where(SecurityEvent.status == status)
    if category:
        stmt = stmt.where(SecurityEvent.category == category)
    stmt = stmt.order_by(SecurityEvent.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    return db.execute(stmt).scalars().all()


@router.patch("/security-events/{event_id}", response_model=SecurityEventOut)
def update_security_event(event_id: uuid.UUID, payload: SecurityEventUpdate,
                          ctx: AuthContext = Depends(require_permission(rbac.SECURITY_EVENTS_WRITE)),
                          db: Session = Depends(get_db)):
    event = db.get(SecurityEvent, event_id)
    if event is None:
        raise HTTPException(status_code=404, detail="Event not found")
    event.status = payload.status
    event.resolution_notes = payload.resolution_notes
    record_audit(db, actor_id=ctx.user.id, action="security_event.update", target_type="security_event",
                 target_id=event.id, metadata={"status": payload.status})
    db.commit()
    return event


@router.get("/errors")
def error_reports(page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=100),
                  ctx: AuthContext = Depends(require_permission(rbac.OWNER_ERRORS_READ)),
                  db: Session = Depends(get_db)):
    rows = db.execute(select(SecurityEvent).where(SecurityEvent.category.in_(("APP_ERROR", "ERROR_RATE_SPIKE")))
                      .order_by(SecurityEvent.created_at.desc()).offset((page - 1) * page_size)
                      .limit(page_size)).scalars().all()
    return {
        "summary": {"last_5_minutes": collector.summary(5), "last_60_minutes": collector.summary(60)},
        "events": [SecurityEventOut.model_validate(e).model_dump(mode="json") for e in rows],
        "notes": ["Reports hold the exception class and route template only, never messages or request data.",
                  "Rates are in memory, per process."],
    }


# ---------------------------------------------------------------- audit logs
@router.get("/audit-logs", response_model=list[AuditLogOut])
def list_audit_logs(page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200),
                    ctx: AuthContext = Depends(require_permission(rbac.OWNER_AUDIT_READ)),
                    db: Session = Depends(get_db)):
    stmt = select(AuditLog).order_by(AuditLog.id.desc()).offset((page - 1) * page_size).limit(page_size)
    return db.execute(stmt).scalars().all()


@router.get("/audit-logs/verify")
def verify_audit(ctx: AuthContext = Depends(require_permission(rbac.OWNER_AUDIT_READ)),
                 db: Session = Depends(get_db)):
    result = verify_chain(db)
    if not result["valid"]:
        record_security_event(db, category="AUDIT_TAMPERING_SUSPECTED", severity="CRITICAL", component="audit",
                              metadata={"first_invalid_id": result["first_invalid_id"]})
        db.commit()
    return result


# ------------------------------------------------------------ feature flags
@router.get("/features")
def list_features(ctx: AuthContext = Depends(require_permission(rbac.OWNER_FEATURES_READ)),
                  db: Session = Depends(get_db)):
    return {"features": feature_logic.describe_features(load_overrides(db))}


@router.patch("/features/{name}")
def set_feature(name: str, payload: FeatureUpdate,
                ctx: AuthContext = Depends(require_permission(rbac.OWNER_FEATURES_WRITE)),
                db: Session = Depends(get_db)):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Confirmation required (set confirm=true)")
    try:
        feature_logic.check_change(name, payload.enabled)
    except feature_logic.UnknownFeature:
        raise HTTPException(status_code=404, detail="Unknown feature") from None
    except feature_logic.FeatureUnavailable:
        raise HTTPException(status_code=409, detail="This module is not implemented yet and cannot be enabled") from None
    overrides = load_overrides(db)
    before = feature_logic.effective(name, overrides)
    row = db.get(FeatureFlag, name)
    if row is None:
        db.add(FeatureFlag(name=name, enabled=payload.enabled, updated_by=ctx.user.id))
    else:
        row.enabled = payload.enabled
        row.updated_by = ctx.user.id
        row.updated_at = utcnow()
    record_audit(db, actor_id=ctx.user.id, action="feature.change", target_type="feature", target_id=name,
                 metadata={"from": before, "to": payload.enabled})
    db.commit()
    return {"features": feature_logic.describe_features(load_overrides(db))}


# -------------------------------------------------- releases and development
@router.get("/releases")
def releases(ctx: AuthContext = Depends(require_permission(rbac.OWNER_RELEASES_READ)),
             db: Session = Depends(get_db)):
    rows = db.execute(select(ApplicationRelease).order_by(ApplicationRelease.deployed_at.desc())
                      .limit(50)).scalars().all()
    latest = rows[0] if rows else None
    return {
        "running": {"app_version": settings.app_version, "backend_version": settings.backend_version,
                    "process_started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(collector.started_at))},
        "latest_recorded_release": ReleaseOut.model_validate(latest).model_dump(mode="json") if latest else None,
        "running_version_matches_latest_record": (latest.version == settings.app_version) if latest else None,
        "history": [ReleaseOut.model_validate(r).model_dump(mode="json") for r in rows],
        "notes": ["Release records are written by the deployment procedure (python -m app.cli record-release). "
                  "Nothing is inferred; an empty history means none were recorded."],
    }


@router.get("/backup")
def backup_status(ctx: AuthContext = Depends(require_permission(rbac.OWNER_BACKUP_READ))):
    return read_backup_status(settings.backup_dir or None, utcnow(), settings.backup_max_age_hours)


@router.get("/development-status")
def development_status(ctx: AuthContext = Depends(require_permission(rbac.OWNER_DEVSTATUS_READ))):
    return read_status_file(settings.status_file)


# ------------------------------------------------------------- notifications
@router.get("/notifications", response_model=list[NotificationOut])
def list_notifications(unread_only: bool = False, page: int = Query(1, ge=1),
                       page_size: int = Query(25, ge=1, le=100),
                       ctx: AuthContext = Depends(require_permission(rbac.OWNER_NOTIFICATIONS)),
                       db: Session = Depends(get_db)):
    stmt = select(Notification).where(Notification.recipient_user_id == ctx.user.id)
    if unread_only:
        stmt = stmt.where(Notification.read_at.is_(None))
    stmt = stmt.order_by(Notification.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    return db.execute(stmt).scalars().all()


@router.post("/notifications/read-all")
def mark_all_read(ctx: AuthContext = Depends(require_permission(rbac.OWNER_NOTIFICATIONS)),
                  db: Session = Depends(get_db)):
    result = db.execute(update(Notification).where(
        Notification.recipient_user_id == ctx.user.id, Notification.read_at.is_(None)).values(read_at=utcnow()))
    db.commit()
    return {"updated": result.rowcount or 0}


@router.post("/notifications/{notification_id}/read", response_model=NotificationOut)
def mark_read(notification_id: uuid.UUID,
              ctx: AuthContext = Depends(require_permission(rbac.OWNER_NOTIFICATIONS)),
              db: Session = Depends(get_db)):
    item = db.scalar(select(Notification).where(Notification.id == notification_id,
                                                Notification.recipient_user_id == ctx.user.id))
    if item is None:  # also covers other users' notifications (no IDOR)
        raise HTTPException(status_code=404, detail="Notification not found")
    if item.read_at is None:
        item.read_at = utcnow()
        db.commit()
    return item


def _prefs_out(row: NotificationPreference | None) -> NotificationPrefsOut:
    return NotificationPrefsOut(
        in_app_enabled=row.in_app_enabled if row else DEFAULT_PREFS.in_app_enabled,
        min_severity=row.min_severity if row else DEFAULT_PREFS.min_severity,
        email_enabled=row.email_enabled if row else DEFAULT_PREFS.email_enabled,
        email_available=settings.email_backend != "disabled")


@router.get("/notification-preferences", response_model=NotificationPrefsOut)
def get_notification_preferences(ctx: AuthContext = Depends(require_permission(rbac.OWNER_NOTIFICATIONS)),
                                 db: Session = Depends(get_db)):
    return _prefs_out(db.get(NotificationPreference, ctx.user.id))


@router.put("/notification-preferences", response_model=NotificationPrefsOut)
def update_notification_preferences(payload: NotificationPrefsUpdate,
                                    ctx: AuthContext = Depends(require_permission(rbac.OWNER_NOTIFICATIONS)),
                                    db: Session = Depends(get_db)):
    if payload.email_enabled and settings.email_backend == "disabled":
        raise HTTPException(status_code=409, detail="Email delivery is not configured on this server")
    row = db.get(NotificationPreference, ctx.user.id)
    if row is None:
        row = NotificationPreference(user_id=ctx.user.id)
        db.add(row)
    row.in_app_enabled = payload.in_app_enabled
    row.min_severity = payload.min_severity
    row.email_enabled = payload.email_enabled
    row.updated_at = utcnow()
    record_audit(db, actor_id=ctx.user.id, action="notification_prefs.update", target_type="user",
                 target_id=ctx.user.id, metadata={"min_severity": payload.min_severity,
                                                  "in_app": payload.in_app_enabled, "email": payload.email_enabled})
    db.commit()
    return _prefs_out(row)
