"""Unauthenticated, read-only endpoints. Keep this file tiny and review every addition."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.control.features import public_flags
from app.database.session import get_db
from app.security.rate_limit import rate_limit
from app.services.features import load_overrides

router = APIRouter(tags=["public"])


@router.get("/features", dependencies=[Depends(rate_limit("public-features", 120, 60))])
def public_features(db: Session = Depends(get_db)):
    """Which modules the frontend may show. Names and on/off only; no configuration or secrets."""
    return {"features": public_flags(load_overrides(db))}
