"""User-facing analysis features. Every route needs a signed-in user (require_user) and its feature flag ON.

Pasted text is analysed IN MEMORY and never stored. Only the feature name and result level are counted
(AnalysisRun) so the owner sees usage without seeing content. Nothing here contacts anyone, opens links, runs
generated code or queries anything based on user text.
"""
import re
from datetime import date

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.analysis import recovery, simulator
from app.analysis.exposure import analyze_exposure
from app.analysis.journey import analyze_journey
from app.analysis.proofpass import ProofInputError, build_proofpass
from app.analysis.report import build_unified
from app.analysis.text import InputError, parse_pasted, prepare_messages
from app.api.deps import AuthContext, require_user
from app.database.session import get_db
from app.models.features import AnalysisRun, SimulationAttempt
from app.security.rate_limit import rate_limit
from app.services.features import feature_enabled

router = APIRouter(prefix="/features", tags=["features"])
_COUNTRY = re.compile(r"^[A-Za-z]{2}$")


class MessageIn(BaseModel):
    sender: str | None = Field(default=None, max_length=60)
    timestamp: str | None = Field(default=None, max_length=40)
    text: str = Field(max_length=4000)


class AnalyzeIn(BaseModel):
    """Either `text` (a pasted chat) or `messages` (already split). Limits are enforced again by the engine."""
    text: str | None = Field(default=None, max_length=130_000)
    messages: list[MessageIn] | None = Field(default=None, max_length=200)


class AnswerIn(BaseModel):
    scenario_id: str = Field(max_length=48)
    choice_id: str = Field(max_length=8)


def _require(db: Session, flag: str) -> None:
    if not feature_enabled(db, flag):
        raise HTTPException(status_code=404, detail="This feature is not available right now")


def _messages(payload: AnalyzeIn):
    try:
        if payload.messages:
            raw = [m.model_dump() for m in payload.messages]
        elif payload.text:
            raw = parse_pasted(payload.text)
        else:
            raise InputError("Paste a conversation or add messages.")
        return prepare_messages(raw)
    except InputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from None


def _count(db: Session, feature: str, level: str | None) -> None:
    db.add(AnalysisRun(feature=feature, level=level))
    db.commit()


@router.post("/journey/analyze", dependencies=[Depends(rate_limit("analyze", 30, 60))])
def journey(payload: AnalyzeIn, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db, "scam_journey")
    msgs, note = _messages(payload)
    report = analyze_journey(msgs, note)
    _count(db, "scam_journey", report["level"])
    return report


@router.post("/exposure/analyze", dependencies=[Depends(rate_limit("analyze", 30, 60))])
def exposure(payload: AnalyzeIn, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db, "digital_footprint")
    msgs, _ = _messages(payload)
    report = analyze_exposure(msgs)
    _count(db, "digital_footprint", report["highest_sensitivity"])
    return report


@router.post("/analyze", dependencies=[Depends(rate_limit("analyze", 30, 60))])
def unified(payload: AnalyzeIn, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    """Unified report: Journey and/or Exposure, whichever are switched on."""
    want_journey, want_exposure = feature_enabled(db, "scam_journey"), feature_enabled(db, "digital_footprint")
    if not (want_journey or want_exposure):
        raise HTTPException(status_code=404, detail="This feature is not available right now")
    msgs, note = _messages(payload)
    j = analyze_journey(msgs, note) if want_journey else None
    e = analyze_exposure(msgs) if want_exposure else None
    report = build_unified(j, e)
    if j:
        db.add(AnalysisRun(feature="scam_journey", level=j["level"]))
    if e:
        db.add(AnalysisRun(feature="digital_footprint", level=e["highest_sensitivity"]))
    db.commit()
    return report


@router.post("/proofpass", dependencies=[Depends(rate_limit("proofpass", 30, 60))])
def proofpass(payload: dict = Body(...), ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db, "trustcheck")
    try:
        report = build_proofpass(payload, date.today())
    except ProofInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from None
    _count(db, "trustcheck", None)
    return report


@router.get("/safechoice/scenarios")
def scenarios(ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db, "learning")
    return {"scenarios": simulator.list_scenarios()}


@router.get("/safechoice/scenarios/{scenario_id}")
def scenario(scenario_id: str, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db, "learning")
    found = simulator.get_scenario(scenario_id)
    if not found:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return found


@router.post("/safechoice/answer", dependencies=[Depends(rate_limit("safechoice", 60, 60))])
def answer(payload: AnswerIn, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db, "learning")
    result = simulator.evaluate_choice(payload.scenario_id, payload.choice_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Scenario or choice not found")
    db.add(SimulationAttempt(user_id=ctx.user.id, scenario_id=payload.scenario_id,
                             choice_id=payload.choice_id, rating=result["rating"]))
    db.commit()
    return result


@router.get("/safechoice/progress")
def progress(ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    _require(db, "learning")
    rows = db.execute(select(SimulationAttempt).where(SimulationAttempt.user_id == ctx.user.id)
                      .order_by(SimulationAttempt.created_at)).scalars().all()
    return simulator.summarize_progress([{"scenario_id": r.scenario_id, "rating": r.rating} for r in rows])


@router.get("/recovery/{situation}")
def recovery_checklist(situation: str, country: str | None = None, ctx: AuthContext = Depends(require_user),
                       db: Session = Depends(get_db)):
    _require(db, "recovery")
    if country is not None and not _COUNTRY.match(country):
        raise HTTPException(status_code=422, detail="country must be a two-letter code such as IN")
    key = situation.upper()
    if key not in recovery.SITUATIONS:
        raise HTTPException(status_code=404, detail="Unknown situation")
    return recovery.get_checklist(key, country)
