"""Authentication endpoints."""
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import AuthContext, get_context, require_user
from app.core.config import settings
from app.database.session import get_db
from app.models.base import utcnow
from app.models.user import EmailVerification, LoginHistory, MfaCredential, PasswordResetToken, User, UserSession
from app.schemas.auth import (
    DeleteRequest, ForgotPasswordRequest, LoginRequest, LoginResponse, MeResponse, MessageResponse,
    MfaCodeRequest, MfaDisableRequest, MfaSetupResponse, RegisterRequest, ResetPasswordRequest,
    SessionOut, UserOut, VerifyEmailRequest,
)
from app.security import mfa as mfa_lib
from app.security.crypto import decrypt_secret, encrypt_secret
from app.security.passwords import (
    hash_password, needs_rehash, password_problems, verify_dummy, verify_password,
)
from app.security.rate_limit import limiter, rate_limit
from app.security.rbac import Role, is_privileged
from app.security.sessions import (
    clear_auth_cookies, create_session, ip_prefix, revoke_all_sessions, session_ttl_seconds, set_auth_cookies,
)
from app.security.tokens import pseudonymize
from app.services.audit import record_audit
from app.services.auth_tokens import consume_token, issue_token
from app.services.email import EmailMessage, send_email
from app.services.email_templates import reset_email, verification_email
from app.services.features import feature_enabled
from app.services.security_events import record_security_event

router = APIRouter(prefix="/auth", tags=["auth"])

GENERIC_LOGIN_ERROR = "Invalid email or password"
_VERIFY_ERROR = "Invalid or expired verification link, or wrong password"


def _password_errors(problems: list[str]) -> list[dict]:
    """Same shape as the global validation-error handler, so the frontend handles one format."""
    return [{"field": "password", "message": p} for p in problems]


def _fail_login(db: Session, request: Request, user: User | None, email: str, reason: str) -> None:
    db.add(LoginHistory(user_id=user.id if user else None, email_hash=pseudonymize(email), success=False,
                        reason=reason, ip_prefix=ip_prefix(request)))


@router.post("/register", response_model=MessageResponse, status_code=202,
             dependencies=[Depends(rate_limit("register", 5, 3600))])
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if not feature_enabled(db, "registration_open"):  # owner can close sign-ups from the Control Centre
        raise HTTPException(status_code=403, detail="Registration is currently closed.")
    email = payload.email.lower()
    problems = password_problems(payload.password, email)
    if problems:
        raise HTTPException(status_code=422, detail=_password_errors(problems))
    existing = db.scalar(select(User).where(User.email == email))
    password_hash = hash_password(payload.password)  # hash in both branches (similar timing)
    if existing is None:
        user = User(email=email, password_hash=password_hash, full_name=payload.full_name,
                    role=Role.STANDARD_USER.value)  # role is never taken from user input
        db.add(user)
        db.flush()
        raw = issue_token(db, EmailVerification, user.id, ttl_minutes=60 * 24)
        db.commit()
        subject, body = verification_email(settings.frontend_base_url, raw)
        send_email(EmailMessage(to=email, subject=subject, body=body))
    return MessageResponse(message="If the address can be registered, a verification email has been sent.")


@router.post("/verify-email", response_model=MessageResponse,
             dependencies=[Depends(rate_limit("verify-email", 10, 3600))])
def verify_email(payload: VerifyEmailRequest, db: Session = Depends(get_db)):
    """The link alone is not enough: the person must also enter the password the account was registered with.

    Otherwise an attacker could register with a victim's address and a password they chose, and the
    victim clicking the emailed link would hand the attacker a verified account ("pre-hijacking").
    """
    user_id = consume_token(db, EmailVerification, payload.token)
    user = db.get(User, user_id) if user_id is not None else None
    if user is None:
        verify_dummy(payload.password)  # same cost either way
        db.rollback()
        raise HTTPException(status_code=400, detail=_VERIFY_ERROR)
    if not verify_password(user.password_hash, payload.password):
        db.rollback()  # the link stays usable by whoever really owns the account
        record_security_event(db, category="EMAIL_VERIFY_PASSWORD_MISMATCH", severity="LOW", component="auth",
                              metadata={"account": pseudonymize(user.email)})
        db.commit()
        raise HTTPException(status_code=400, detail=_VERIFY_ERROR)
    user.email_verified = True
    db.commit()
    return MessageResponse(message="Email verified. You can now sign in.")


@router.post("/resend-verification", response_model=MessageResponse,
             dependencies=[Depends(rate_limit("resend-verification", 5, 3600))])
def resend_verification(payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    email = payload.email.lower()
    user = db.scalar(select(User).where(User.email == email))
    if user is not None and not user.email_verified and user.status != "SUSPENDED":
        raw = issue_token(db, EmailVerification, user.id, ttl_minutes=60 * 24)
        db.commit()
        subject, body = verification_email(settings.frontend_base_url, raw)
        send_email(EmailMessage(to=email, subject=subject, body=body))
    return MessageResponse(message="If that address still needs verification, a new email has been sent.")


@router.post("/login", response_model=LoginResponse, dependencies=[Depends(rate_limit("login", 10, 300))])
def login(payload: LoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    email = payload.email.lower()
    now = utcnow()
    user = db.scalar(select(User).where(User.email == email))

    if user is None:
        verify_dummy(payload.password)
        _fail_login(db, request, None, email, "unknown_account")
        record_security_event(db, category="AUTH_FAILED_LOGIN", severity="INFO", component="auth",
                              metadata={"account": pseudonymize(email), "reason": "unknown_account"})
        db.commit()
        raise HTTPException(status_code=401, detail=GENERIC_LOGIN_ERROR)

    if user.locked_until and user.locked_until > now:
        verify_dummy(payload.password)  # same cost as a real check, so "locked" is not detectable by timing
        _fail_login(db, request, user, email, "locked")
        db.commit()
        raise HTTPException(status_code=401, detail=GENERIC_LOGIN_ERROR)

    if not verify_password(user.password_hash, payload.password):
        user.failed_login_count += 1
        _fail_login(db, request, user, email, "bad_password")
        severity = "INFO"
        if user.failed_login_count >= settings.max_failed_logins:
            user.locked_until = now + timedelta(minutes=settings.lockout_minutes)
            user.failed_login_count = 0
            severity = "HIGH" if is_privileged(user.role) else "MEDIUM"
            record_security_event(db, category="AUTH_ACCOUNT_LOCKED", severity=severity, component="auth",
                                  metadata={"account": pseudonymize(email), "role": user.role})
        else:
            record_security_event(db, category="AUTH_FAILED_LOGIN", severity="INFO", component="auth",
                                  metadata={"account": pseudonymize(email), "reason": "bad_password"})
        db.commit()
        raise HTTPException(status_code=401, detail=GENERIC_LOGIN_ERROR)

    # Password is correct from here on.
    if not user.email_verified:
        raise HTTPException(status_code=403, detail="Please verify your email before signing in")
    if user.status == "SUSPENDED":
        raise HTTPException(status_code=403, detail="This account is not available. Please contact support.")

    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(payload.password)
    user.failed_login_count = 0
    user.locked_until = None
    user.last_login_at = now

    requires_mfa = user.mfa_enabled
    privileged = is_privileged(user.role)
    raw_token, raw_csrf, _ = create_session(db, user, request, mfa_passed=not (requires_mfa or privileged))
    db.add(LoginHistory(user_id=user.id, email_hash=pseudonymize(email), success=True,
                        reason="password_ok", ip_prefix=ip_prefix(request)))
    db.commit()

    set_auth_cookies(response, raw_token, raw_csrf, session_ttl_seconds(user))
    status = "ok"
    if requires_mfa:
        status = "mfa_required"
    elif privileged:
        status = "mfa_enrollment_required"
    return LoginResponse(status=status, user=UserOut.model_validate(user), csrf_token=raw_csrf)


@router.post("/logout", response_model=MessageResponse)
def logout(response: Response, ctx: AuthContext = Depends(get_context), db: Session = Depends(get_db)):
    ctx.session.revoked_at = utcnow()
    db.commit()
    clear_auth_cookies(response)
    return MessageResponse(message="Signed out")


@router.get("/me", response_model=MeResponse)
def me(ctx: AuthContext = Depends(get_context)):
    privileged = is_privileged(ctx.user.role)
    return MeResponse(user=UserOut.model_validate(ctx.user), mfa_passed=ctx.session.mfa_passed,
                      mfa_enrollment_required=privileged and not ctx.user.mfa_enabled)


@router.post("/forgot-password", response_model=MessageResponse,
             dependencies=[Depends(rate_limit("forgot-password", 5, 3600))])
def forgot_password(payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    email = payload.email.lower()
    user = db.scalar(select(User).where(User.email == email))
    if user is not None and user.status != "SUSPENDED":
        raw = issue_token(db, PasswordResetToken, user.id, ttl_minutes=60)
        db.commit()
        subject, body = reset_email(settings.frontend_base_url, raw)
        send_email(EmailMessage(to=email, subject=subject, body=body))
    return MessageResponse(message="If an account exists for that address, a reset link has been sent.")


@router.post("/reset-password", response_model=MessageResponse,
             dependencies=[Depends(rate_limit("reset-password", 10, 3600))])
def reset_password(payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    user_id = consume_token(db, PasswordResetToken, payload.token)
    if user_id is None:
        db.commit()
        raise HTTPException(status_code=400, detail="Invalid or expired reset link")
    user = db.get(User, user_id)
    problems = password_problems(payload.new_password, user.email)
    if problems:
        db.rollback()  # leave the token unused so the user can retry
        raise HTTPException(status_code=422, detail=_password_errors(problems))
    user.password_hash = hash_password(payload.new_password)
    # The reset link was delivered to the mailbox, so using it proves control of that mailbox. This also
    # replaces any password an attacker may have set when pre-registering this address.
    user.email_verified = True
    user.failed_login_count = 0
    user.locked_until = None
    revoke_all_sessions(db, user.id)
    record_security_event(db, category="PASSWORD_RESET", severity="INFO", component="auth",
                          metadata={"account": pseudonymize(user.email)})
    db.commit()
    return MessageResponse(message="Password updated. Please sign in again.")


# ---------------------------------------------------------------- MFA
@router.post("/mfa/setup", response_model=MfaSetupResponse)
def mfa_setup(ctx: AuthContext = Depends(get_context), db: Session = Depends(get_db)):
    if ctx.user.mfa_enabled:
        raise HTTPException(status_code=409, detail="MFA is already enabled")
    secret = mfa_lib.new_secret()
    cred = db.scalar(select(MfaCredential).where(MfaCredential.user_id == ctx.user.id))
    if cred is None:
        db.add(MfaCredential(user_id=ctx.user.id, secret_encrypted=encrypt_secret(secret)))
    else:
        cred.secret_encrypted = encrypt_secret(secret)
        cred.confirmed_at = None
        cred.last_used_step = None
    db.commit()
    return MfaSetupResponse(secret=secret, otpauth_uri=mfa_lib.provisioning_uri(secret, ctx.user.email))


def _check_code(db: Session, ctx: AuthContext, code: str) -> bool:
    # Two caps: per session, and per USER across all sessions. Without the per-user cap an attacker
    # who knows the password could log in repeatedly to get fresh sessions and keep guessing codes.
    by_session = limiter.hit(f"mfa:{ctx.session.id}", 5, 300)
    by_user = limiter.hit(f"mfa-user:{ctx.user.id}", 10, 1800)
    if by_user.first_block:
        record_security_event(db, category="MFA_BRUTE_FORCE_SUSPECTED", severity="HIGH", component="auth",
                              metadata={"account": pseudonymize(ctx.user.email), "role": ctx.user.role})
        db.commit()
    if not (by_session.allowed and by_user.allowed):
        raise HTTPException(status_code=429, detail="Too many attempts. Please try again later.")
    cred = db.scalar(select(MfaCredential).where(MfaCredential.user_id == ctx.user.id))
    if cred is None:
        return False
    step = mfa_lib.verify_totp(decrypt_secret(cred.secret_encrypted), code, cred.last_used_step)
    if step is None:
        record_security_event(db, category="MFA_FAILED", severity="LOW", component="auth",
                              metadata={"account": pseudonymize(ctx.user.email)})
        db.commit()
        return False
    cred.last_used_step = step
    return True


@router.post("/mfa/confirm", response_model=MessageResponse)
def mfa_confirm(payload: MfaCodeRequest, ctx: AuthContext = Depends(get_context), db: Session = Depends(get_db)):
    if ctx.user.mfa_enabled:
        raise HTTPException(status_code=409, detail="MFA is already enabled")
    if not _check_code(db, ctx, payload.code):
        raise HTTPException(status_code=400, detail="Invalid code")
    cred = db.scalar(select(MfaCredential).where(MfaCredential.user_id == ctx.user.id))
    cred.confirmed_at = utcnow()
    ctx.user.mfa_enabled = True
    ctx.session.mfa_passed = True
    if is_privileged(ctx.user.role):
        record_audit(db, actor_id=ctx.user.id, action="auth.mfa_enrolled", target_type="user", target_id=ctx.user.id)
    db.commit()
    return MessageResponse(message="MFA enabled")


@router.post("/mfa/verify", response_model=MessageResponse)
def mfa_verify(payload: MfaCodeRequest, ctx: AuthContext = Depends(get_context), db: Session = Depends(get_db)):
    if not ctx.user.mfa_enabled:
        raise HTTPException(status_code=400, detail="MFA is not enabled")
    if not _check_code(db, ctx, payload.code):
        raise HTTPException(status_code=400, detail="Invalid code")
    ctx.session.mfa_passed = True
    db.commit()
    return MessageResponse(message="MFA verified")


@router.post("/mfa/disable", response_model=MessageResponse)
def mfa_disable(payload: MfaDisableRequest, ctx: AuthContext = Depends(require_user),
                db: Session = Depends(get_db)):
    if is_privileged(ctx.user.role):
        raise HTTPException(status_code=403, detail="MFA is mandatory for this account")
    if not verify_password(ctx.user.password_hash, payload.password) or not _check_code(db, ctx, payload.code):
        raise HTTPException(status_code=400, detail="Invalid password or code")
    cred = db.scalar(select(MfaCredential).where(MfaCredential.user_id == ctx.user.id))
    if cred is not None:
        db.delete(cred)
    ctx.user.mfa_enabled = False
    db.commit()
    return MessageResponse(message="MFA disabled")


# ------------------------------------------------- sessions, history, deletion
@router.get("/sessions", response_model=list[SessionOut])
def list_sessions(ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    rows = db.execute(select(UserSession).where(
        UserSession.user_id == ctx.user.id, UserSession.revoked_at.is_(None),
        UserSession.expires_at > utcnow()).order_by(UserSession.created_at.desc())).scalars().all()
    return [SessionOut(id=r.id, created_at=r.created_at, expires_at=r.expires_at, ip_prefix=r.ip_prefix,
                       user_agent=r.user_agent, current=(r.id == ctx.session.id)) for r in rows]


@router.delete("/sessions/{session_id}", response_model=MessageResponse)
def revoke_session(session_id: str, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    try:
        sid = uuid.UUID(session_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Not found") from None
    row = db.scalar(select(UserSession).where(UserSession.id == sid, UserSession.user_id == ctx.user.id))
    if row is None:  # also covers other users' sessions (no IDOR)
        raise HTTPException(status_code=404, detail="Not found")
    row.revoked_at = utcnow()
    db.commit()
    return MessageResponse(message="Session revoked")


@router.get("/login-history")
def login_history(ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    rows = db.execute(select(LoginHistory).where(LoginHistory.user_id == ctx.user.id)
                      .order_by(LoginHistory.created_at.desc()).limit(50)).scalars().all()
    return [{"success": r.success, "reason": r.reason, "ip_prefix": r.ip_prefix, "created_at": r.created_at}
            for r in rows]


@router.post("/account/delete-request", response_model=MessageResponse)
def delete_request(payload: DeleteRequest, ctx: AuthContext = Depends(require_user), db: Session = Depends(get_db)):
    if ctx.user.role == Role.OWNER.value:
        raise HTTPException(status_code=400, detail="The owner account cannot be deleted this way")
    if not verify_password(ctx.user.password_hash, payload.password):
        raise HTTPException(status_code=400, detail="Incorrect password")
    ctx.user.status = "PENDING_DELETION"
    ctx.user.deletion_requested_at = utcnow()
    db.commit()
    return MessageResponse(message="Deletion requested. Your data will be removed per the retention policy.")
