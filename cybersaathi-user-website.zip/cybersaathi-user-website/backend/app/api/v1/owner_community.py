"""Founder moderation of community alerts. Every route MUST use require_permission (tests/test_feature_guards.py
checks). The owner sees fixed choices and counts only: reports contain no free text and no user identity."""
import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import AuthContext, require_permission
from app.api.v1.community import report_dicts
from app.community import alerts as alert_logic
from app.community import similarity
from app.database.session import get_db
from app.models.base import utcnow
from app.models.features import CommunityAlert
from app.security import rbac
from app.services.audit import record_audit

router = APIRouter(prefix="/owner/community", tags=["owner"])


class ModerateIn(BaseModel):
    action: str  # approve | reject | unpublish
    confirm: bool = False


def _view(a: CommunityAlert) -> dict:
    return {"id": str(a.id), "scam_type": a.scam_type, "channel": a.channel, "title": a.title, "body": a.body, "status": a.status,
            "reporter_count": a.reporter_count, "can_publish": alert_logic.can_publish(a.reporter_count)[0],
            "created_at": a.created_at.isoformat(), "published_at": a.published_at.isoformat() if a.published_at else None}


@router.get("")
def moderation_queue(ctx: AuthContext = Depends(require_permission(rbac.OWNER_COMMUNITY_MODERATE)), db: Session = Depends(get_db)):
    rows = db.execute(select(CommunityAlert).order_by(CommunityAlert.created_at.desc())).scalars().all()
    reports = report_dicts(db)
    return {"alerts": [_view(a) for a in rows], "reports_last_12_weeks": len(reports),
            "min_reporters_to_publish": alert_logic.MIN_REPORTERS,
            "note": "You see fixed choices and counts only. Reports contain no free text and no user identity."}


@router.post("/refresh")
def refresh(ctx: AuthContext = Depends(require_permission(rbac.OWNER_COMMUNITY_MODERATE)), db: Session = Depends(get_db)):
    """Group recent reports and create PENDING alerts for patterns with enough different reporters.
    One alert per (scam type, channel). A rejected alert is not recreated; counts of existing alerts are refreshed."""
    clusters = similarity.group_reports(report_dicts(db))
    existing = {(a.scam_type, a.channel): a for a in db.execute(select(CommunityAlert)).scalars()}
    created = updated = 0
    seen = set()
    for c in clusters:
        pair = (c["scam_type"], c["channel"])
        if pair in seen:
            continue
        seen.add(pair)
        current = existing.get(pair)
        if current is not None:
            if current.reporter_count != c["distinct_reporters"]:
                current.reporter_count, updated = c["distinct_reporters"], updated + 1
            continue
        if not alert_logic.can_publish(c["distinct_reporters"])[0]:
            continue
        text = alert_logic.build_alert_text(c)
        db.add(CommunityAlert(scam_type=c["scam_type"], channel=c["channel"], title=text["title"], body=text["body"],
                              status="PENDING", reporter_count=c["distinct_reporters"]))
        created += 1
    record_audit(db, actor_id=ctx.user.id, action="community.refresh", target_type="community", metadata={"created": created, "updated": updated})
    db.commit()
    return {"created": created, "updated": updated}


@router.patch("/alerts/{alert_id}")
def moderate(alert_id: uuid.UUID, payload: ModerateIn,
             ctx: AuthContext = Depends(require_permission(rbac.OWNER_COMMUNITY_MODERATE)), db: Session = Depends(get_db)):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Confirmation required (set confirm=true)")
    target = {"approve": "PUBLISHED", "reject": "REJECTED", "unpublish": "UNDER_REVIEW"}.get(payload.action)
    if target is None:
        raise HTTPException(status_code=422, detail="action must be approve, reject or unpublish")
    alert = db.get(CommunityAlert, alert_id)
    if alert is None:
        raise HTTPException(status_code=404, detail="Alert not found")
    before = alert.status
    if target == "PUBLISHED":
        ok, why = alert_logic.can_publish(alert.reporter_count)
        if not ok:
            raise HTTPException(status_code=409, detail=why)
    try:
        alert.status = alert_logic.transition(alert.status, target)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from None
    alert.reviewed_by, alert.reviewed_at = ctx.user.id, utcnow()
    if target == "PUBLISHED":
        alert.published_at = utcnow()
    record_audit(db, actor_id=ctx.user.id, action=f"community.alert.{payload.action}", target_type="community_alert",
                 target_id=alert.id, metadata={"from": before, "to": alert.status})
    db.commit()
    return _view(alert)
