from fastapi import APIRouter

from app.api.v1 import auth, community, features, owner, owner_community, public
from app.core.safety import site_mounts


def build_api_router(mode: str = "full") -> APIRouter:
    """Sign-in is always available. The owner API exists only where the mode says so (never on the public site)."""
    mounts = site_mounts(mode)
    router = APIRouter(prefix="/api/v1")
    router.include_router(auth.router)
    if mounts["owner_api"]:
        router.include_router(owner.router)
        router.include_router(owner_community.router)
    if mounts["user_api"]:
        router.include_router(public.router)
        router.include_router(features.router)
        router.include_router(community.router)
    return router


api_router = build_api_router("full")  # kept for tests and tools that expect the complete API
