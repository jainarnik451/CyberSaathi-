"""Authentication / authorization dependencies. Every protected route uses these."""
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models.base import utcnow
from app.models.user import User, UserSession
from app.security.rbac import has_permission, is_privileged
from app.security.sessions import CSRF_COOKIE, SESSION_COOKIE
from app.security.tokens import constant_time_equals, hash_token
from app.services.security_events import record_security_event

SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


@dataclass
class AuthContext:
    user: User
    session: UserSession


def get_context(request: Request, db: Session = Depends(get_db)) -> AuthContext:
    """Authenticated user + CSRF enforcement. MFA is NOT required here (used for MFA endpoints)."""
    raw = request.cookies.get(SESSION_COOKIE)
    if not raw:
        raise HTTPException(status_code=401, detail="Not authenticated")
    session = db.execute(select(UserSession).where(UserSession.token_hash == hash_token(raw))).scalar_one_or_none()
    if session is None or session.revoked_at is not None or session.expires_at < utcnow():
        raise HTTPException(status_code=401, detail="Not authenticated")
    user = db.get(User, session.user_id)
    if user is None or user.status == "SUSPENDED":
        raise HTTPException(status_code=401, detail="Not authenticated")

    if request.method not in SAFE_METHODS:
        header = request.headers.get("x-csrf-token", "")
        cookie = request.cookies.get(CSRF_COOKIE, "")
        if not header or not cookie or not constant_time_equals(header, cookie) \
                or not constant_time_equals(hash_token(header), session.csrf_token_hash):
            record_security_event(db, category="CSRF_FAILURE", severity="MEDIUM", component="api",
                                  metadata={"path": request.url.path})
            db.commit()
            raise HTTPException(status_code=403, detail="CSRF validation failed")
    return AuthContext(user=user, session=session)


def require_user(ctx: AuthContext = Depends(get_context)) -> AuthContext:
    """Authenticated and, where required, MFA-verified."""
    user, session = ctx.user, ctx.session
    if is_privileged(user.role) and not user.mfa_enabled:
        raise HTTPException(status_code=403, detail="mfa_enrollment_required")
    if (user.mfa_enabled or is_privileged(user.role)) and not session.mfa_passed:
        raise HTTPException(status_code=403, detail="mfa_required")
    return ctx


def require_permission(permission: str):
    def dependency(request: Request, ctx: AuthContext = Depends(require_user),
                   db: Session = Depends(get_db)) -> AuthContext:
        if not has_permission(ctx.user.role, permission):
            record_security_event(db, category="PERMISSION_DENIED", severity="LOW", component="api",
                                  metadata={"permission": permission, "role": ctx.user.role,
                                            "path": request.url.path})
            db.commit()
            raise HTTPException(status_code=403, detail="Forbidden")
        return ctx
    return dependency
