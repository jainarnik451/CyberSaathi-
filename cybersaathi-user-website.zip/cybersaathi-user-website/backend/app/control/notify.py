"""Notification delivery rules for the owner."""
from dataclasses import dataclass

SEVERITY_RANK = {"INFO": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
# INFO and LOW events (e.g. every failed login) are visible in the security-events list but never notify:
# this keeps the owner's inbox meaningful and avoids a database lookup on every minor event.
SELECTABLE_MIN_SEVERITIES = ("MEDIUM", "HIGH", "CRITICAL")
NOTIFY_FLOOR = SEVERITY_RANK["MEDIUM"]


@dataclass(frozen=True)
class NotificationPrefs:
    in_app_enabled: bool = True
    min_severity: str = "HIGH"
    email_enabled: bool = False


DEFAULT_PREFS = NotificationPrefs()


def _rank(severity: str) -> int:
    return SEVERITY_RANK.get(severity, 0)


def should_notify_in_app(severity: str, prefs: NotificationPrefs) -> bool:
    if _rank(severity) < NOTIFY_FLOOR:
        return False
    if severity == "CRITICAL":
        return True  # critical alerts cannot be switched off
    return prefs.in_app_enabled and _rank(severity) >= _rank(prefs.min_severity)


def should_email(severity: str, prefs: NotificationPrefs, email_backend_active: bool) -> bool:
    return (email_backend_active and prefs.email_enabled
            and _rank(severity) >= max(NOTIFY_FLOOR, _rank(prefs.min_severity)))
