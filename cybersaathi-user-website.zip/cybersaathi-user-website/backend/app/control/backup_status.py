"""Read backup status from the marker file written by app/backup.py. Never touches the backups themselves."""
import json
from datetime import datetime, timezone
from pathlib import Path

STATUS_FILENAME = "backup_status.json"


def _parse(value) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def read_backup_status(backup_dir: str | None, now: datetime, max_age_hours: int = 26) -> dict:
    base = {"status": "not_configured", "last_success_at": None, "last_attempt_at": None, "last_result": None,
            "age_hours": None, "size_bytes": None, "filename": None, "max_age_hours": max_age_hours}
    if not backup_dir:
        return {**base, "detail": "No backup directory configured (CYBERSAATHI_BACKUP_DIR)."}
    marker = Path(backup_dir) / STATUS_FILENAME
    if not marker.is_file():
        return {**base, "status": "no_backup_recorded", "detail": "No backup has been recorded yet."}
    try:
        data = json.loads(marker.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("not an object")
    except (OSError, ValueError):
        return {**base, "status": "unreadable", "detail": "Backup status file could not be read."}

    last_success = _parse(data.get("last_success_at"))
    last_attempt = _parse(data.get("last_attempt_at"))
    result = data.get("last_result") if data.get("last_result") in ("success", "failed") else None
    age = round((now - last_success).total_seconds() / 3600, 2) if last_success else None
    size = data.get("size_bytes") if isinstance(data.get("size_bytes"), int) else None
    filename = Path(str(data.get("filename", ""))).name or None  # name only, never a path

    if result == "failed":
        status = "failed"
    elif last_success is None:
        status = "no_backup_recorded"
    elif age is not None and age > max_age_hours:
        status = "stale"
    else:
        status = "ok"
    return {**base, "status": status, "last_success_at": last_success.isoformat() if last_success else None,
            "last_attempt_at": last_attempt.isoformat() if last_attempt else None, "last_result": result,
            "age_hours": age, "size_bytes": size, "filename": filename,
            "detail": "Status comes from the backup marker file; restore has not been tested by this system."}
