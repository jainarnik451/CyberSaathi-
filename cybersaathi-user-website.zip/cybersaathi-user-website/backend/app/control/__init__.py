"""Founder Control Centre logic that has no third-party dependencies.

Everything here is plain Python so it can be unit-tested anywhere. The API layer (api/v1/owner.py)
only adds authentication, permission checks and database access around these functions.
"""
