"""Feature flags the owner may switch. Only names in this registry can be changed (deny by default).

Security controls (MFA, CSRF, rate limits, audit logging) are deliberately NOT flags.
"""
from collections.abc import Mapping
from dataclasses import dataclass

from app.control.modules import MODULES


class FeatureError(Exception):
    pass


class UnknownFeature(FeatureError):
    pass


class FeatureUnavailable(FeatureError):
    pass


@dataclass(frozen=True)
class FeatureDef:
    name: str
    description: str
    default: bool
    enforced: bool        # True only if backend code checks this flag today
    module_key: str | None = None  # module this flag gates; it cannot be enabled until that module exists


_FEATURES = (
    FeatureDef("registration_open", "Allow new users to register", True, True),
    FeatureDef("scam_journey", "Trust Journey X-Ray", True, True, "scam_journey"),
    FeatureDef("trustcheck", "ProofPass claim-to-proof verification", True, True, "trustcheck"),
    FeatureDef("url_analyzer", "Suspicious URL Analyzer", False, False, "url_analyzer"),
    FeatureDef("impersonation", "AI Impersonation Awareness", False, False, "impersonation"),
    FeatureDef("digital_footprint", "Exposure Map", True, True, "digital_footprint"),
    FeatureDef("community", "Scam Pattern Early-Warning Network (off until you are ready to moderate)", False, True, "community"),
    FeatureDef("learning", "SafeChoice Simulator", True, True, "learning"),
    FeatureDef("recovery", "Recovery Navigator", True, True, "recovery"),
)

FEATURES: dict[str, FeatureDef] = {f.name: f for f in _FEATURES}


def _get(name: str) -> FeatureDef:
    try:
        return FEATURES[name]
    except KeyError:
        raise UnknownFeature(name) from None


def can_enable(feature: FeatureDef) -> bool:
    return feature.module_key is None or MODULES[feature.module_key].available


def effective(name: str, overrides: Mapping[str, bool]) -> bool:
    feature = _get(name)
    value = overrides.get(name, feature.default)
    # Defensive: a flag row edited directly in the database cannot switch on a module that does not exist.
    return bool(value) and can_enable(feature)


def check_change(name: str, enabled: bool) -> FeatureDef:
    feature = _get(name)
    if enabled and not can_enable(feature):
        raise FeatureUnavailable(f"{name}: its module is not implemented yet")
    return feature


def describe_features(overrides: Mapping[str, bool]) -> list[dict]:
    return [
        {"name": f.name, "description": f.description, "enabled": effective(f.name, overrides),
         "default": f.default, "enforced": f.enforced, "can_enable": can_enable(f),
         "overridden": f.name in overrides}
        for f in _FEATURES
    ]


def public_flags(overrides: Mapping[str, bool]) -> dict[str, bool]:
    return {f.name: effective(f.name, overrides) for f in _FEATURES}
