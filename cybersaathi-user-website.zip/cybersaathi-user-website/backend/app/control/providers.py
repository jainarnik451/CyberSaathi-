"""Availability and error tracking for external providers (AI model, threat intelligence).

HOW IT WORKS: every provider adapter (not built yet) must call `provider_monitor.record(...)` after each
outbound call. Until a provider has recorded calls, its availability is reported as "no_data" and NEVER as
"ok": a green light must mean something actually succeeded recently.

PRIVACY: only the provider name, success flag, latency and the exception CLASS NAME are stored. Never
prompts, responses, user text, URLs or error messages (these can contain submitted data or credentials).

LIMITATIONS (shown to the owner): per process, in memory, resets on restart.
"""
import re
import threading
import time
from collections import deque

_NAME = re.compile(r"[^a-z0-9_\-]")
_TYPE = re.compile(r"[^A-Za-z0-9_]")

# Judgement thresholds, chosen by the developer and documented here so they can be changed knowingly.
MIN_CALLS_FOR_RATE = 5        # fewer calls than this: the error rate is too noisy to judge
DEGRADED_ERROR_RATE = 0.20    # at least 20% of recent calls failed
DOWN_CONSECUTIVE_FAILURES = 3  # the latest N calls all failed
MAX_EVENTS_PER_PROVIDER = 500


def _clean_name(provider: str) -> str:
    return _NAME.sub("", (provider or "").strip().lower())[:40] or "unknown"


def _clean_type(error_type: str | None) -> str | None:
    if not error_type:
        return None
    return _TYPE.sub("", str(error_type))[:64] or "Error"


def classify(calls: int, errors: int, consecutive_failures: int) -> str:
    """Pure decision rule. 'no_data' when nothing was recorded; never 'ok' without a recorded success."""
    if calls == 0:
        return "no_data"
    if consecutive_failures >= DOWN_CONSECUTIVE_FAILURES:
        return "down"
    if calls >= MIN_CALLS_FOR_RATE and errors / calls >= DEGRADED_ERROR_RATE:
        return "degraded"
    if errors == calls:
        return "degraded"  # every recorded call failed, but too few to call it "down"
    return "ok"


class ProviderMonitor:
    def __init__(self) -> None:
        self._events: dict[str, deque] = {}  # name -> deque[(ts, ok, latency_ms, error_type)]
        self._lock = threading.Lock()

    def reset(self) -> None:
        with self._lock:
            self._events.clear()

    def record(self, provider: str, ok: bool, latency_ms: float | None = None,
               error_type: str | None = None, now: float | None = None) -> None:
        ts = time.time() if now is None else now
        latency = None if latency_ms is None else max(0.0, float(latency_ms))
        with self._lock:
            q = self._events.setdefault(_clean_name(provider), deque(maxlen=MAX_EVENTS_PER_PROVIDER))
            q.append((ts, bool(ok), latency, None if ok else (_clean_type(error_type) or "Error")))

    def summary(self, provider: str, window_minutes: int = 60, now: float | None = None) -> dict:
        ts = time.time() if now is None else now
        since = ts - window_minutes * 60
        with self._lock:
            events = list(self._events.get(_clean_name(provider), ()))
        recent = [e for e in events if e[0] >= since]
        errors = [e for e in recent if not e[1]]
        latencies = [e[2] for e in recent if e[1] and e[2] is not None]
        streak = 0
        for e in reversed(recent):
            if e[1]:
                break
            streak += 1
        by_type: dict[str, int] = {}
        for e in errors:
            by_type[e[3]] = by_type.get(e[3], 0) + 1
        last_ok = next((e[0] for e in reversed(events) if e[1]), None)
        last_err = next((e for e in reversed(events) if not e[1]), None)
        return {
            "window_minutes": window_minutes,
            "calls": len(recent),
            "errors": len(errors),
            "error_rate": round(len(errors) / len(recent), 4) if recent else None,
            "avg_latency_ms": round(sum(latencies) / len(latencies), 2) if latencies else None,
            "max_latency_ms": round(max(latencies), 2) if latencies else None,
            "consecutive_failures": streak,
            "errors_by_type": by_type,
            "last_success_epoch": last_ok,
            "last_error_epoch": last_err[0] if last_err else None,
            "last_error_type": last_err[3] if last_err else None,
            "availability": classify(len(recent), len(errors), streak),
        }


provider_monitor = ProviderMonitor()


def merge_with_observed(static: dict, observed: dict) -> dict:
    """Combine the configuration-based status with what real calls showed.

    Without recorded calls the static status stands ("configured_unverified" never becomes "ok").
    """
    if static.get("status") == "not_configured" or observed["availability"] == "no_data":
        return {**static, "observed_calls": observed["calls"]}
    return {**static, "status": observed["availability"], "observed_calls": observed["calls"],
            "detail": f"Based on {observed['calls']} recorded call(s) in the last {observed['window_minutes']} minutes."}
