"""In-memory request metrics, one-minute buckets.

LIMITATIONS (shown to the owner): per process, so with several workers each reports its own share;
resets on restart. Real production monitoring should add Prometheus or a hosted service.
"""
import threading
import time


class MetricsCollector:
    def __init__(self, retention_minutes: int = 180) -> None:
        self._retention = retention_minutes
        self._buckets: dict[int, list[float]] = {}  # minute -> [requests, 4xx, 5xx, latency_sum, latency_max]
        self._lock = threading.Lock()
        self.started_at = time.time()

    def reset(self) -> None:
        with self._lock:
            self._buckets.clear()
            self.started_at = time.time()

    def record(self, status: int, duration_ms: float, now: float | None = None) -> None:
        now = time.time() if now is None else now
        minute = int(now // 60)
        with self._lock:
            b = self._buckets.setdefault(minute, [0, 0, 0, 0.0, 0.0])
            b[0] += 1
            if 400 <= status < 500:
                b[1] += 1
            elif status >= 500:
                b[2] += 1
            b[3] += duration_ms
            b[4] = max(b[4], duration_ms)
            cutoff = minute - self._retention
            for old in [m for m in self._buckets if m < cutoff]:
                del self._buckets[old]

    def summary(self, window_minutes: int, now: float | None = None) -> dict:
        now = time.time() if now is None else now
        current = int(now // 60)
        total = e4 = e5 = 0
        lat_sum = lat_max = 0.0
        with self._lock:
            for minute, b in self._buckets.items():
                if current - window_minutes < minute <= current:
                    total += int(b[0])
                    e4 += int(b[1])
                    e5 += int(b[2])
                    lat_sum += b[3]
                    lat_max = max(lat_max, b[4])
        return {
            "window_minutes": window_minutes,
            "requests": total,
            "errors_4xx": e4,
            "errors_5xx": e5,
            "error_rate_5xx": round(e5 / total, 4) if total else None,
            "avg_latency_ms": round(lat_sum / total, 2) if total else None,
            "max_latency_ms": round(lat_max, 2) if total else None,
        }

    def series(self, window_minutes: int, now: float | None = None) -> list[dict]:
        now = time.time() if now is None else now
        current = int(now // 60)
        with self._lock:
            rows = []
            for minute in range(current - window_minutes + 1, current + 1):
                b = self._buckets.get(minute)
                rows.append({"minute_utc": time.strftime("%Y-%m-%dT%H:%MZ", time.gmtime(minute * 60)),
                             "requests": int(b[0]) if b else 0, "errors_5xx": int(b[2]) if b else 0})
            return rows


collector = MetricsCollector()
