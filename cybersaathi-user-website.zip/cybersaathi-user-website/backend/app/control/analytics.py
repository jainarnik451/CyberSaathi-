"""Business analytics: usage and growth, computed ONLY from rows that exist.

Pure functions (no database imports) so the arithmetic can be tested without SQLAlchemy. The route in
api/v1/owner.py does the queries and passes plain dicts in.

Honesty rules:
* A rate with no denominator is None (shown as "no data"), never 0% or 100%.
* Analysis counts per module are None until a module exists (see control/modules.py).
* "Active" means "signed in successfully", counted by calendar day in UTC. This is sign-in activity, not
  product usage; real usage metrics arrive with the analysis modules.
"""
from datetime import date, timedelta


def date_range(end: date, days: int) -> list[date]:
    """`days` consecutive dates ending at (and including) `end`, oldest first."""
    return [end - timedelta(days=i) for i in range(days - 1, -1, -1)]


def rate(part: int, whole: int) -> float | None:
    return round(part / whole, 4) if whole > 0 else None


def growth_percent(current: int, previous: int) -> float | None:
    """Percent change; None when the previous period had nothing to compare against."""
    if previous <= 0:
        return None
    return round((current - previous) / previous * 100, 1)


def build_growth_report(*, end: date, days: int, registrations: dict[date, int], active_users: dict[date, int],
                        signins: dict[date, int], users_before_window: int, totals: dict) -> dict:
    """Assemble the report. `registrations`, `active_users`, `signins` map a UTC date to a count; missing
    days mean zero events (a real zero, because the query covered the whole window)."""
    window = date_range(end, days)
    series = []
    running = users_before_window
    for d in window:
        running += registrations.get(d, 0)
        series.append({"date": d.isoformat(), "new_users": registrations.get(d, 0), "total_users": running,
                       "active_users": active_users.get(d, 0), "successful_signins": signins.get(d, 0)})

    half = days // 2
    recent, earlier = window[half:], window[:half]
    new_recent = sum(registrations.get(d, 0) for d in recent)
    new_earlier = sum(registrations.get(d, 0) for d in earlier)
    users_total = totals["users_total"]
    return {
        "window_days": days,
        "from": window[0].isoformat(),
        "to": window[-1].isoformat(),
        "timezone": "UTC",
        "series": series,
        "totals": {
            "users_total": users_total,
            "new_users_in_window": sum(registrations.get(d, 0) for d in window),
            "email_verified_rate": rate(totals["verified"], users_total),
            "mfa_adoption_rate": rate(totals["mfa_enabled"], users_total),
            "suspended_users": totals["suspended"],
            "pending_deletion_users": totals["pending_deletion"],
        },
        "growth": {
            "compares": f"last {len(recent)} days vs the {len(earlier)} days before",
            "new_users_recent": new_recent,
            "new_users_earlier": new_earlier,
            "change_percent": growth_percent(new_recent, new_earlier),
        },
        "usage": {
            "analyses_by_module": None,
            "reason": "No analysis module exists yet, so analysis counts are unavailable (not zero).",
        },
    }
