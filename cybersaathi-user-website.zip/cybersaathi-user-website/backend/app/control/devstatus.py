"""Serve DEVELOPMENT_STATUS.md to the owner. The path comes from server configuration only, never from a request."""
from datetime import datetime, timezone
from pathlib import Path

MAX_BYTES = 200_000


def read_status_file(path: str | None) -> dict:
    if not path:
        return {"available": False, "content": None, "updated_at": None, "truncated": False}
    p = Path(path)
    try:
        if not p.is_file():
            return {"available": False, "content": None, "updated_at": None, "truncated": False}
        with p.open("rb") as fh:
            raw = fh.read(MAX_BYTES + 1)
        updated = datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat()
    except OSError:
        return {"available": False, "content": None, "updated_at": None, "truncated": False}
    return {"available": True, "content": raw[:MAX_BYTES].decode("utf-8", errors="replace"),
            "updated_at": updated, "truncated": len(raw) > MAX_BYTES, "format": "markdown-plain-text"}
