"""Health status helpers. Nothing here invents a value: unknowns are reported as unknown."""
import shutil
import time
from collections.abc import Callable

# Statuses that are informational and do not make the platform "degraded".
INFORMATIONAL = {"ok", "not_configured", "not_implemented", "not_measured", "configured_unverified", "dev_only"}
DEGRADED = {"degraded", "stale"}
DOWN = {"down", "failed"}


def overall_status(statuses: dict[str, str]) -> str:
    """down > degraded > ok. An unrecognised status counts as degraded so it cannot hide a problem."""
    values = set(statuses.values())
    if values & DOWN:
        return "down"
    if any(v in DEGRADED or v not in INFORMATIONAL for v in values):
        return "degraded"
    return "ok"


def provider_status(provider: str, has_credentials: bool) -> dict:
    """Describe an external provider (AI, threat intelligence) WITHOUT revealing any credential.

    Availability is not probed: no provider adapter exists yet, and the dashboard must not claim a
    service is up when nothing has checked.
    """
    name = (provider or "none").strip().lower()
    if name in ("", "none"):
        return {"status": "not_configured", "provider": None, "credentials_present": False,
                "detail": "No provider selected."}
    if not has_credentials:
        return {"status": "not_configured", "provider": name, "credentials_present": False,
                "detail": "Provider selected but no API key is set."}
    return {"status": "configured_unverified", "provider": name, "credentials_present": True,
            "detail": "Credentials are present. Availability is not probed."}


def probe_database(run_query: Callable[[], None], slow_ms: float = 1000.0) -> dict:
    start = time.perf_counter()
    try:
        run_query()
    except Exception as exc:  # report the class only; messages can contain connection details
        return {"status": "down", "latency_ms": None, "error_type": type(exc).__name__}
    latency = round((time.perf_counter() - start) * 1000, 2)
    return {"status": "degraded" if latency > slow_ms else "ok", "latency_ms": latency, "error_type": None}


def disk_status(path: str, degraded_pct: float = 90.0, down_pct: float = 97.0,
                usage: Callable = shutil.disk_usage) -> dict:
    try:
        total, used, free = usage(path)
    except OSError as exc:
        return {"status": "not_measured", "error_type": type(exc).__name__}
    pct = round(used / total * 100, 1) if total else 0.0
    status = "down" if pct >= down_pct else "degraded" if pct >= degraded_pct else "ok"
    return {"status": status, "used_percent": pct, "free_bytes": free, "total_bytes": total,
            "detail": "Disk of the machine running the API, not of a separate database server."}


def backup_component_status(backup_status: str) -> str:
    return {"ok": "ok", "not_configured": "not_configured", "stale": "degraded",
            "failed": "down", "no_backup_recorded": "degraded", "unreadable": "degraded"}.get(backup_status, "degraded")
