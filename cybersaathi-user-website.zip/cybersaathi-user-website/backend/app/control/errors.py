"""Error-report helpers. Reports contain the exception CLASS, never its message or request data."""


def safe_error_metadata(exc: BaseException, method: str, route_template: str | None) -> dict:
    return {
        "exception_type": type(exc).__name__[:80],
        "method": (method or "")[:10],
        # The route template (/users/{user_id}), never the real URL, which may contain identifiers.
        "route": (route_template or "unknown")[:120],
    }


def is_error_spike(summary: dict, min_requests: int = 20, min_errors: int = 10, min_rate: float = 0.05) -> bool:
    rate = summary.get("error_rate_5xx")
    return (summary.get("requests", 0) >= min_requests and summary.get("errors_5xx", 0) >= min_errors
            and rate is not None and rate >= min_rate)
