"""Registry of platform modules and whether their code actually exists.

This is a statement about the codebase, not a success indicator: flip `implemented` to True only
in the same change that adds the working module and its counters.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class ModuleInfo:
    key: str
    name: str
    status: str  # "implemented" | "partial" | "not_implemented"
    note: str

    @property
    def implemented(self) -> bool:
        return self.status == "implemented"

    @property
    def available(self) -> bool:
        """Code exists and may be switched on ('partial' = written and unit-tested, but not yet run end to end)."""
        return self.status in ("implemented", "partial")


_MODULES = (
    ModuleInfo("auth", "Accounts and authentication", "implemented",
               "Registration, login, MFA, sessions, password reset."),
    ModuleInfo("owner_api", "Founder Control Centre API", "implemented",
               "Founder API endpoints (users, security, health, features, audit, analytics, AI monitoring)."),
    ModuleInfo("owner_ui", "Founder Control Centre dashboard", "partial",
               "Built (static files in frontend-owner/). Tested in a browser against a MOCK API only; "
               "not yet run against the real backend."),
    ModuleInfo("frontend", "Public web frontend", "not_implemented", "Not started."),
    ModuleInfo("scam_journey", "Trust Journey X-Ray", "partial", "Pattern engine unit-tested (executed). API routes and database code written but NOT yet run against a real server; see docs/FEATURE_REPORT.md."),
    ModuleInfo("trustcheck", "ProofPass", "partial", "Evidence organiser using user-supplied evidence, with no web lookups. Pattern engine unit-tested (executed). API routes and database code written but NOT yet run against a real server; see docs/FEATURE_REPORT.md."),
    ModuleInfo("url_analyzer", "URL Analyzer", "not_implemented", "Planned for Phase 3."),
    ModuleInfo("impersonation", "AI Impersonation Awareness", "not_implemented", "Planned for Phase 3."),
    ModuleInfo("digital_footprint", "Exposure Map", "partial", "Pattern engine unit-tested (executed). API routes and database code written but NOT yet run against a real server; see docs/FEATURE_REPORT.md."),
    ModuleInfo("community", "Scam Pattern Early-Warning Network", "partial", "Moderated, aggregate-only. Pattern engine unit-tested (executed). API routes and database code written but NOT yet run against a real server; see docs/FEATURE_REPORT.md."),
    ModuleInfo("learning", "SafeChoice Simulator", "partial", "Six fictional scenarios with progress tracking. Pattern engine unit-tested (executed). API routes and database code written but NOT yet run against a real server; see docs/FEATURE_REPORT.md."),
    ModuleInfo("recovery", "Recovery Navigator", "partial", "Checklists; India details carry a verified-on date. Pattern engine unit-tested (executed). API routes and database code written but NOT yet run against a real server; see docs/FEATURE_REPORT.md."),
)

MODULES: dict[str, ModuleInfo] = {m.key: m for m in _MODULES}

# Modules that perform analyses. Counts for these are reported as null (not 0) until the module exists,
# because "0 analyses" and "module does not exist" are different facts.
ANALYSIS_MODULES = ("scam_journey", "trustcheck", "digital_footprint", "url_analyzer")


def module_report(counts: dict | None = None) -> list[dict]:
    """`counts` maps module key -> real count from the database. Without it (or for a module with no
    counter) the count is null: unknown is not zero."""
    counts = counts or {}
    rows = []
    for m in _MODULES:
        value = counts.get(m.key) if m.key in ANALYSIS_MODULES and m.available else None
        reason = None
        if m.key in ANALYSIS_MODULES and value is None:
            reason = ("Module not implemented; no analyses can exist." if not m.available
                      else "No count supplied by the database query.")
        rows.append({"key": m.key, "name": m.name, "status": m.status, "note": m.note,
                     "analysis_count": value, "analysis_count_reason": reason})
    return rows
