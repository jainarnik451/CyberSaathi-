"""FastAPI application factory."""
import logging
from pathlib import Path

from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from app.api.v1 import build_api_router
from app.control.metrics import collector
from app.core.config import settings
from app.core.logging import configure_logging
from app.core.safety import site_mounts
from app.database.session import SessionLocal, get_db
from app.middleware.body_limit import BodySizeLimitMiddleware
from app.middleware.global_limit import GlobalRateLimitMiddleware
from app.middleware.metrics import MetricsMiddleware
from app.middleware.proxy import TrustedProxyMiddleware
from app.middleware.security import SecurityHeadersMiddleware
from app.security.gate import BusyError
from app.security.limiter import limiter
from app.services.error_reports import record_app_error

logger = logging.getLogger(__name__)
OWNER_UI_DIR = Path(__file__).resolve().parents[2] / "frontend-owner"
APP_UI_DIR = Path(__file__).resolve().parents[2] / "frontend-app"


def create_app() -> FastAPI:
    configure_logging()
    is_prod = settings.environment == "production"
    app = FastAPI(
        title="CyberSaathi API", version=settings.backend_version,
        docs_url=None if is_prod else "/docs", redoc_url=None, openapi_url=None if is_prod else "/openapi.json",
    )
    app.state.session_factory = SessionLocal  # tests replace this with their own database
    # add_middleware order: the LAST one added is outermost.
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(GlobalRateLimitMiddleware, per_minute=settings.global_rate_limit_per_minute,
                       limiter=limiter)  # inside CORS, so 429 responses still carry CORS headers
    app.add_middleware(
        CORSMiddleware, allow_origins=settings.cors_origin_list, allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE"], allow_headers=["Content-Type", "X-CSRF-Token"],
    )
    app.add_middleware(BodySizeLimitMiddleware, max_bytes=settings.max_request_bytes)
    app.add_middleware(MetricsMiddleware, collector=collector)
    # Outermost: every other layer (limits, logs, sessions) must see the real visitor address.
    app.add_middleware(TrustedProxyMiddleware, hops=settings.trusted_proxy_hops)

    @app.exception_handler(RequestValidationError)
    async def validation_handler(request: Request, exc: RequestValidationError):
        # Default FastAPI echoes submitted values (could include passwords). Return field + message only.
        errors = [{"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]}
                  for e in exc.errors()]
        return JSONResponse(status_code=422, content={"detail": errors})

    @app.exception_handler(BusyError)
    async def busy_handler(request: Request, exc: BusyError):
        return JSONResponse(status_code=503, content={"detail": "The server is busy. Please try again shortly."},
                            headers={"Retry-After": "5"})

    @app.exception_handler(Exception)
    async def unhandled_handler(request: Request, exc: Exception):
        route = getattr(request.scope.get("route"), "path", None)  # template like /users/{user_id}
        logger.error("Unhandled error on %s: %s", route or "unknown route", type(exc).__name__)
        await run_in_threadpool(record_app_error, request.app.state.session_factory, exc, request.method, route)
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})

    @app.get("/healthz", tags=["health"])
    def healthz():
        """Liveness: the process is running. Says nothing about the database."""
        return {"status": "ok"}

    @app.get("/readyz", tags=["health"])
    def readyz(db: Session = Depends(get_db)):
        """Readiness for external monitors: 503 when the database is unreachable. Reveals no details."""
        try:
            db.execute(text("SELECT 1"))
        except Exception:
            return JSONResponse(status_code=503, content={"status": "database_unavailable"})
        return {"status": "ok"}

    mounts = site_mounts(settings.site_mode)
    app.include_router(build_api_router(settings.site_mode))
    # Founder dashboard: plain static files (no build step). It holds no data and no secrets: everything it
    # shows comes from the authenticated /api/v1/owner/* endpoints. Served from the same origin as the API.
    # In "public" mode it is not mounted at all, so the internet cannot even see that it exists.
    if mounts["owner_ui"] and OWNER_UI_DIR.is_dir():
        app.mount("/owner-ui", StaticFiles(directory=OWNER_UI_DIR, html=True), name="owner-ui")
    if mounts["user_app"] and APP_UI_DIR.is_dir():
        app.mount("/app", StaticFiles(directory=APP_UI_DIR, html=True), name="app-ui")

        @app.get("/", include_in_schema=False)
        def home():
            return RedirectResponse("/app/")
    elif mounts["owner_ui"]:
        @app.get("/", include_in_schema=False)
        def owner_home():
            return RedirectResponse("/owner-ui/")
    return app


app = create_app()
