"""Tables for the innovation features. ADDITIVE ONLY: no existing table is changed.

PRIVACY BY DESIGN: there is no column anywhere that could hold pasted message text, evidence, names, phone
numbers or links. AnalysisRun deliberately has NO user id, so usage counts cannot be traced to a person.
"""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from app.database.session import Base
from app.models.base import UTCDateTime, utcnow


class AnalysisRun(Base):
    """One row per analysis, for the owner's usage counts. Holds the feature and result level only."""

    __tablename__ = "analysis_runs"

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    feature: Mapped[str] = mapped_column(String(32), index=True)  # module key, e.g. scam_journey
    level: Mapped[str | None] = mapped_column(String(24), nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)


class SimulationAttempt(Base):
    """A learner's answer in SafeChoice. Needed so the learner can see their own progress."""

    __tablename__ = "simulation_attempts"

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    scenario_id: Mapped[str] = mapped_column(String(48))
    choice_id: Mapped[str] = mapped_column(String(8))
    rating: Mapped[str] = mapped_column(String(8))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class CommunityReport(Base):
    """A voluntary report made only of fixed choices (see app/community/reports.py)."""

    __tablename__ = "community_reports"
    __table_args__ = (UniqueConstraint("reporter_key", "fingerprint", name="uq_report_once_per_pattern_week"),)

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    reporter_key: Mapped[str] = mapped_column(String(64), index=True)  # keyed hash, not a user id
    fingerprint: Mapped[str] = mapped_column(String(32), index=True)
    scam_type: Mapped[str] = mapped_column(String(32), index=True)
    channel: Mapped[str] = mapped_column(String(16))
    tactics: Mapped[str] = mapped_column(String(200), default="")  # comma-separated fixed values
    payment_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    region: Mapped[str | None] = mapped_column(String(2), nullable=True)
    week: Mapped[str] = mapped_column(String(10), index=True)  # Monday of the report week (ISO date)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class CommunityAlert(Base):
    __tablename__ = "community_alerts"
    __table_args__ = (UniqueConstraint("scam_type", "channel", name="uq_alert_per_pair"),)

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    scam_type: Mapped[str] = mapped_column(String(32))
    channel: Mapped[str] = mapped_column(String(16))
    title: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="PENDING", index=True)
    reporter_count: Mapped[int] = mapped_column(Integer, default=0)
    reviewed_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    published_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class AlertFlag(Base):
    """A user saying an alert looks inaccurate. One flag per person per alert."""

    __tablename__ = "alert_flags"
    __table_args__ = (UniqueConstraint("alert_id", "flagger_key", name="uq_flag_once"),)

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    alert_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("community_alerts.id", ondelete="CASCADE"), index=True)
    flagger_key: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
