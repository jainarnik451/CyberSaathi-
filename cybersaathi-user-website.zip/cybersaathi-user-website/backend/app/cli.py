"""Command-line tools. Run from the backend folder:

    python -m app.cli create-owner --email you@example.com

The password is typed at a hidden prompt (never passed as an argument, never stored in
shell history). Only one owner can be created this way.
"""
import argparse
import getpass
import sys
from datetime import timedelta

from sqlalchemy import select

from app.database.session import SessionLocal
from app.models.base import utcnow
from app.models.user import MfaCredential, User
from app.security import mfa as mfa_lib
from app.security.crypto import encrypt_secret
from app.security.passwords import hash_password, password_problems
from app.security.rbac import Role
from app.security.sessions import revoke_all_sessions
from app.security.tokens import pseudonymize
from app.services.audit import record_audit
from app.services.security_events import record_security_event


def create_owner(email: str) -> int:
    email = email.strip().lower()
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.role == Role.OWNER.value)):
            print("An owner account already exists. Refusing to create another.", file=sys.stderr)
            return 1
        if db.scalar(select(User).where(User.email == email)):
            print("That email is already registered.", file=sys.stderr)
            return 1
        pw = getpass.getpass("Choose a strong owner password (min 12 chars): ")
        if pw != getpass.getpass("Repeat password: "):
            print("Passwords do not match.", file=sys.stderr)
            return 1
        problems = password_problems(pw, email)
        if problems:
            print("\n".join(problems), file=sys.stderr)
            return 1
        # Enrol MFA now, so the owner account is never usable with a password alone.
        secret = mfa_lib.new_secret()
        print("\nSet up your authenticator app now (Google Authenticator, Microsoft Authenticator, Authy...).")
        print("Choose 'enter a setup key', type of key: time-based, and enter this key:\n")
        print(f"    {secret}\n")
        print("Keep this key private. Clear this terminal window afterwards.\n")
        step = mfa_lib.verify_totp(secret, input("Enter the 6-digit code now shown in the app: "), None)
        if step is None:
            print("That code did not match. Nothing was created. Run the command again.", file=sys.stderr)
            return 1
        user = User(email=email, password_hash=hash_password(pw), role=Role.OWNER.value,
                    email_verified=True, mfa_enabled=True, full_name="Founder")
        db.add(user)
        db.flush()
        db.add(MfaCredential(user_id=user.id, secret_encrypted=encrypt_secret(secret), confirmed_at=utcnow(),
                             last_used_step=step))
        record_audit(db, actor_id=None, action="owner.bootstrap", target_type="user", target_id=user.id,
                     metadata={"mfa": "enrolled"})
        db.commit()
    print("Owner created with MFA enabled. Sign in with your password and the 6-digit code.")
    return 0


def reset_mfa(email: str) -> int:
    """Recovery for a lost authenticator. Needs access to the server, which is the point: it is not an API."""
    email = email.strip().lower()
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.email == email))
        if user is None:
            print("No such account.", file=sys.stderr)
            return 1
        if input(f"This removes MFA for {email} and signs them out everywhere.\n"
                 "Type the email again to confirm: ").strip().lower() != email:
            print("Cancelled.")
            return 1
        cred = db.scalar(select(MfaCredential).where(MfaCredential.user_id == user.id))
        if cred is not None:
            db.delete(cred)
        user.mfa_enabled = False
        revoke_all_sessions(db, user.id)
        record_audit(db, actor_id=None, action="auth.mfa_reset", target_type="user", target_id=user.id,
                     metadata={"via": "cli"})
        record_security_event(db, category="MFA_RESET", severity="HIGH", component="auth",
                              metadata={"account": pseudonymize(email), "role": user.role})
        db.commit()
    print("MFA removed. Sign in to the dashboard NOW: it will show a setup key for a new authenticator. "
          "Until you finish that, the account is protected by its password only.")
    return 0


def process_deletions(older_than_days: int) -> int:
    """Permanently delete accounts whose owners asked for deletion at least N days ago (grace period)."""
    cutoff = utcnow() - timedelta(days=older_than_days)
    deleted = 0
    with SessionLocal() as db:
        due = db.execute(select(User).where(User.status == "PENDING_DELETION",
                                            User.deletion_requested_at <= cutoff)).scalars().all()
        for user in due:
            if user.role == Role.OWNER.value:
                continue
            # Child rows (sessions, tokens, MFA, login history, notifications) go via ON DELETE CASCADE.
            record_audit(db, actor_id=None, action="account.deleted", target_type="user", target_id=user.id,
                         metadata={"grace_days": older_than_days})
            db.delete(user)
            deleted += 1
        db.commit()
    print(f"Deleted {deleted} account(s).")
    return 0


def init_db() -> int:
    """TEMPORARY: creates tables directly from the models.

    This is a stop-gap until Alembic migrations exist (still on the to-do list). Do not use it for
    production databases that must evolve over time.
    """
    from app.database.session import Base, engine
    import app.models  # noqa: F401  (registers the tables)
    Base.metadata.create_all(engine)
    print("Database tables created (if they did not already exist).")
    return 0


def record_release(version: str, backend_version: str, status: str, notes: str) -> int:
    """Record a deployment so it appears in the Control Centre release history (run by your deploy steps)."""
    from app.models.platform import ApplicationRelease
    from app.services.security_events import record_security_event

    failed = status == "FAILED"
    with SessionLocal() as db:
        rel = ApplicationRelease(version=version[:32], backend_version=backend_version[:32], status=status,
                                 notes=notes[:2000])
        db.add(rel)
        db.flush()
        record_audit(db, actor_id=None, action="release.recorded", target_type="release", target_id=rel.id,
                     metadata={"version": version[:32], "status": status})
        record_security_event(db, category="DEPLOYMENT_FAILED" if failed else "DEPLOYMENT_RECORDED",
                              severity="HIGH" if failed else "MEDIUM", component="deployment",
                              metadata={"version": version[:32]})
        db.commit()
    print(f"Recorded release {version} ({status}).")
    return 0


def backup() -> int:
    from app.backup import run_backup
    from app.core.config import settings

    if not settings.backup_dir:
        print("Set CYBERSAATHI_BACKUP_DIR first (a folder outside the project, ideally on another disk).",
              file=sys.stderr)
        return 1
    status = run_backup(settings.database_url, settings.backup_dir, keep_last=settings.backup_keep_last)
    if status["last_result"] == "success":
        print(f"Backup written: {status['filename']} ({status['size_bytes']} bytes)")
        return 0
    print(f"Backup FAILED: {status.get('error', 'unknown error')}", file=sys.stderr)
    try:  # tell the owner, if the database is reachable
        from app.services.security_events import record_security_event
        with SessionLocal() as db:
            record_security_event(db, category="BACKUP_FAILED", severity="HIGH", component="backup")
            db.commit()
    except Exception as exc:
        print(f"(Could not record the failure in the database: {type(exc).__name__})", file=sys.stderr)
    return 1


def show_outbox(count: int) -> int:
    """Print the newest emails the app saved in dev_outbox mode (what a real inbox would have received)."""
    from pathlib import Path
    from app.core.config import settings

    folder = Path(settings.dev_outbox_dir)
    files = sorted(folder.glob("*.txt"), key=lambda f: f.stat().st_mtime, reverse=True)[:count] if folder.is_dir() else []
    if not files:
        print(f"No saved emails in {folder.resolve()}.\n"
              f"Current email setting: CYBERSAATHI_EMAIL_BACKEND={settings.email_backend}. Emails are only saved "
              "when it is dev_outbox; with 'smtp' they are sent to the real inbox, with 'disabled' nothing is sent.")
        return 1
    for f in reversed(files):
        print(f"===== {f.name} =====\n{f.read_text(encoding='utf-8', errors='replace')}\n")
    return 0


def verify_user(email: str) -> int:
    """LOCAL TESTING ONLY: marks an account's email as verified without a code. Refused in production."""
    from app.core.config import settings

    if settings.environment == "production":
        print("Refused: this shortcut is disabled in production.", file=sys.stderr)
        return 1
    email = email.strip().lower()
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.email == email))
        if user is None:
            print("No such account. Register it in the app first.", file=sys.stderr)
            return 1
        user.email_verified = True
        record_audit(db, actor_id=None, action="auth.email_verified_via_cli", target_type="user", target_id=user.id,
                     metadata={"via": "cli"})
        db.commit()
    print(f"{email} is now verified. You can sign in with the password you chose at registration.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="app.cli")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init-db", help="Create database tables (temporary, pre-migrations)")
    sub.add_parser("backup", help="Back up the database to CYBERSAATHI_BACKUP_DIR")
    m = sub.add_parser("reset-mfa", help="Remove MFA from an account (lost authenticator recovery)")
    m.add_argument("--email", required=True)
    d = sub.add_parser("process-deletions", help="Permanently delete accounts that requested deletion")
    d.add_argument("--older-than-days", type=int, default=7)
    r = sub.add_parser("record-release", help="Record a deployment in the release history")
    r.add_argument("--version", required=True)
    r.add_argument("--backend-version")
    r.add_argument("--status", choices=["DEPLOYED", "FAILED"], default="DEPLOYED")
    r.add_argument("--notes", default="")
    o = sub.add_parser("show-outbox", help="Show saved emails (dev_outbox mode)")
    o.add_argument("--count", type=int, default=3)
    v = sub.add_parser("verify-user", help="Local testing only: mark an email as verified")
    v.add_argument("--email", required=True)
    p = sub.add_parser("create-owner", help="Create the first owner account")
    p.add_argument("--email", required=True)
    args = parser.parse_args()
    if args.command == "init-db":
        return init_db()
    if args.command == "backup":
        return backup()
    if args.command == "reset-mfa":
        return reset_mfa(args.email)
    if args.command == "process-deletions":
        return process_deletions(args.older_than_days)
    if args.command == "record-release":
        return record_release(args.version, args.backend_version or args.version, args.status, args.notes)
    if args.command == "show-outbox":
        return show_outbox(args.count)
    if args.command == "verify-user":
        return verify_user(args.email)
    if args.command == "create-owner":
        return create_owner(args.email)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
