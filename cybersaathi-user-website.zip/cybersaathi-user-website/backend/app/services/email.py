"""Email sending. Backends:
- disabled   : nothing is sent (default, safe).
- dev_outbox : writes each email to a local file (development only; read them with `python -m app.cli show-outbox`).
- smtp       : real delivery through your mail provider (see .env.example). Needed for emails to reach real inboxes.
"""
import logging
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from app.control.providers import provider_monitor
from app.core.config import settings
from app.services.smtp import SmtpConfig, send_via_smtp

logger = logging.getLogger(__name__)


@dataclass
class EmailMessage:
    to: str
    subject: str
    body: str


class DisabledBackend:
    def send(self, message: EmailMessage) -> None:
        logger.warning("Email is DISABLED (CYBERSAATHI_EMAIL_BACKEND), so no email was sent (subject=%s)", message.subject)


class DevOutboxBackend:
    def send(self, message: EmailMessage) -> None:
        out = Path(settings.dev_outbox_dir)
        out.mkdir(parents=True, exist_ok=True)
        (out / f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}.txt").write_text(
            f"To: {message.to}\nSubject: {message.subject}\n\n{message.body}\n", encoding="utf-8")


class SmtpBackend:
    def send(self, message: EmailMessage) -> None:
        cfg = SmtpConfig(host=settings.smtp_host or "", port=settings.smtp_port, sender=settings.smtp_from or "",
                         username=settings.smtp_username,
                         password=settings.smtp_password.get_secret_value() if settings.smtp_password else None,
                         security=settings.smtp_security)
        send_via_smtp(cfg, message.to, message.subject, message.body)


_override = None  # tests replace this


def get_email_backend():
    if _override is not None:
        return _override
    return {"dev_outbox": DevOutboxBackend, "smtp": SmtpBackend}.get(settings.email_backend, DisabledBackend)()


def send_email(message: EmailMessage) -> bool:
    """Returns True if the backend accepted the message. A failure never breaks the request, and is recorded
    (class name only, never the address, message or password) so the owner can see it in the dashboard."""
    started = time.monotonic()
    try:
        get_email_backend().send(message)
    except Exception as exc:
        provider_monitor.record("email", False, (time.monotonic() - started) * 1000, type(exc).__name__)
        logger.error("Email sending failed (%s). Check the CYBERSAATHI_SMTP_* settings.", type(exc).__name__)
        return False
    provider_monitor.record("email", True, (time.monotonic() - started) * 1000)
    return True
