"""Security event recording. Metadata is sanitised; MEDIUM+ events can notify the owner per their preferences."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.control.notify import (
    DEFAULT_PREFS, NOTIFY_FLOOR, SEVERITY_RANK, NotificationPrefs, should_email, should_notify_in_app,
)
from app.core.config import settings
from app.models.ops import Notification, SecurityEvent
from app.models.platform import NotificationPreference
from app.models.user import User
from app.security.rbac import Role
from app.security.redaction import sanitize_metadata
from app.services.email import EmailMessage, send_email


def record_security_event(db: Session, *, category: str, severity: str, component: str,
                          metadata: dict | None = None) -> SecurityEvent:
    event = SecurityEvent(category=category, severity=severity, component=component,
                          metadata_json=sanitize_metadata(metadata or {}))
    db.add(event)
    db.flush()
    if SEVERITY_RANK.get(severity, 0) >= NOTIFY_FLOOR:
        _notify_owners(db, event)
    return event


def _notify_owners(db: Session, event: SecurityEvent) -> None:
    owners = db.execute(select(User.id, User.email).where(
        User.role == Role.OWNER.value, User.status == "ACTIVE")).all()
    if not owners:
        return
    rows = db.execute(select(NotificationPreference).where(
        NotificationPreference.user_id.in_([o.id for o in owners]))).scalars()
    prefs_by_user = {p.user_id: NotificationPrefs(p.in_app_enabled, p.min_severity, p.email_enabled) for p in rows}
    email_active = settings.email_backend != "disabled"
    title = f"{event.severity} security event: {event.category}"
    for owner_id, owner_email in owners:
        prefs = prefs_by_user.get(owner_id, DEFAULT_PREFS)
        if should_notify_in_app(event.severity, prefs):
            db.add(Notification(recipient_user_id=owner_id, severity=event.severity, title=title,
                                body=f"Component: {event.component}. Event ID: {event.id}"))
        if should_email(event.severity, prefs, email_active):
            # No event metadata in email: it travels over an external channel.
            send_email(EmailMessage(to=owner_email, subject=f"[CyberSaathi] {title}",
                                    body="Sign in to the Founder Control Centre to review this event."))
