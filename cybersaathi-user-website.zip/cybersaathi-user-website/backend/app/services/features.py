"""Database access for feature flags (decision logic lives in app/control/features.py)."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.control.features import effective
from app.models.platform import FeatureFlag


def load_overrides(db: Session) -> dict[str, bool]:
    return {row.name: row.enabled for row in db.execute(select(FeatureFlag)).scalars()}


def feature_enabled(db: Session, name: str) -> bool:
    return effective(name, load_overrides(db))
