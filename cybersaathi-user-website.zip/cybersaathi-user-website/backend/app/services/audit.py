"""Tamper-evident audit log (hash chain).

Each entry stores the hash of the previous entry. Editing or deleting a row breaks the
chain, which `verify_chain` detects. LIMITATION: someone with full database write access
could rebuild the whole chain; for higher assurance ship entries to external append-only
storage (documented in docs/SECURITY.md).
"""
import hashlib
import json

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from app.models.base import utcnow
from app.models.ops import AuditLog
from app.security.redaction import sanitize_metadata

GENESIS = "GENESIS"


def _digest(prev_hash: str, payload: dict) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256((prev_hash + canonical).encode()).hexdigest()


def _payload(row_fields: dict) -> dict:
    return {k: row_fields[k] for k in ("actor_id", "action", "target_type", "target_id", "result", "metadata", "created_at")}


def record_audit(db: Session, *, actor_id, action: str, target_type: str | None = None,
                 target_id=None, result: str = "SUCCESS", metadata: dict | None = None) -> AuditLog:
    if db.get_bind().dialect.name == "postgresql":
        # Serialise audit writes so two concurrent actions cannot fork the hash chain.
        db.execute(text("SELECT pg_advisory_xact_lock(724300101)"))
    last = db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(1)).scalar_one_or_none()
    prev = last.entry_hash if last else GENESIS
    created_at = utcnow()
    meta = sanitize_metadata(metadata or {})
    fields = {
        "actor_id": str(actor_id) if actor_id else None,
        "action": action,
        "target_type": target_type,
        "target_id": str(target_id) if target_id else None,
        "result": result,
        "metadata": meta,
        "created_at": created_at.isoformat(),
    }
    entry = AuditLog(
        actor_id=fields["actor_id"], action=action, target_type=target_type, target_id=fields["target_id"],
        result=result, metadata_json=meta, prev_hash=prev, entry_hash=_digest(prev, _payload(fields)),
        created_at=created_at,
    )
    db.add(entry)
    db.flush()
    return entry


def verify_chain(db: Session) -> dict:
    prev = GENESIS
    count = 0
    for row in db.execute(select(AuditLog).order_by(AuditLog.id.asc())).scalars():
        fields = {
            "actor_id": row.actor_id, "action": row.action, "target_type": row.target_type,
            "target_id": row.target_id, "result": row.result, "metadata": row.metadata_json,
            "created_at": row.created_at.isoformat(),
        }
        if row.prev_hash != prev or row.entry_hash != _digest(prev, _payload(fields)):
            return {"valid": False, "entries_checked": count, "first_invalid_id": row.id}
        prev = row.entry_hash
        count += 1
    return {"valid": True, "entries_checked": count, "first_invalid_id": None}
