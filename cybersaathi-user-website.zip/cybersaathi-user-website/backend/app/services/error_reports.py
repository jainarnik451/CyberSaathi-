"""Turn unhandled exceptions into owner-visible error reports. Must never raise."""
import logging

from app.control.errors import is_error_spike, safe_error_metadata
from app.control.metrics import collector
from app.security.limiter import limiter
from app.services.security_events import record_security_event

logger = logging.getLogger(__name__)


def record_app_error(session_factory, exc: BaseException, method: str, route_template: str | None) -> None:
    try:
        meta = safe_error_metadata(exc, method, route_template)
        # One report per error type and route per minute, so a crash loop cannot flood the database.
        if not limiter.hit(f"apperr:{meta['exception_type']}:{meta['route']}", 1, 60).allowed:
            return
        with session_factory() as db:
            record_security_event(db, category="APP_ERROR", severity="MEDIUM", component="api", metadata=meta)
            summary = collector.summary(5)
            if is_error_spike(summary) and limiter.hit("error-rate-spike", 1, 900).allowed:
                record_security_event(
                    db, category="ERROR_RATE_SPIKE", severity="HIGH", component="api",
                    metadata={"requests": summary["requests"], "errors_5xx": summary["errors_5xx"], "window_minutes": 5})
            db.commit()
    except Exception as inner:  # the error reporter itself failed: log the class only
        logger.error("Could not record application error: %s", type(inner).__name__)
