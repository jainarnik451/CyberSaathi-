"""Usage counts for the Founder Control Centre. COUNTS ONLY: no message content exists to show."""
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.base import utcnow
from app.models.features import AlertFlag, AnalysisRun, CommunityAlert, CommunityReport, SimulationAttempt

TRACKED = ("scam_journey", "trustcheck", "digital_footprint")


def analysis_counts(db: Session) -> dict[str, int]:
    """module key -> real count. A zero is a real zero: the table exists and was queried."""
    counts = {k: 0 for k in TRACKED}
    for feature, n in db.execute(select(AnalysisRun.feature, func.count()).group_by(AnalysisRun.feature)).all():
        counts[feature] = n
    return counts


def usage_summary(db: Session) -> dict:
    def one(stmt):
        return db.scalar(stmt) or 0

    week_ago = utcnow() - timedelta(days=7)
    by_status = {s: n for s, n in db.execute(select(CommunityAlert.status, func.count()).group_by(CommunityAlert.status)).all()}
    counts = analysis_counts(db)
    return {
        "analyses_by_module": counts,
        "analyses_total": sum(counts.values()),
        "analyses_last_7_days": one(select(func.count()).select_from(AnalysisRun).where(AnalysisRun.created_at >= week_ago)),
        "safechoice_attempts": one(select(func.count()).select_from(SimulationAttempt)),
        "safechoice_learners": one(select(func.count(func.distinct(SimulationAttempt.user_id)))),
        "community": {
            "reports_total": one(select(func.count()).select_from(CommunityReport)),
            "alerts_pending": by_status.get("PENDING", 0),
            "alerts_under_review": by_status.get("UNDER_REVIEW", 0),
            "alerts_published": by_status.get("PUBLISHED", 0),
            "inaccuracy_flags": one(select(func.count()).select_from(AlertFlag)),
        },
        "privacy_note": "Counts only. Pasted messages are analysed in memory and never stored, so the founder cannot see them.",
    }
