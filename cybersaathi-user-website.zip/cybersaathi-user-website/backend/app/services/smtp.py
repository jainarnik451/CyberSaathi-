"""Real email delivery over SMTP (standard library only, no config imports, so it is testable on its own).

Security rules:
* Certificates are verified (ssl.create_default_context). STARTTLS is the default; 'ssl' uses implicit TLS.
* Unencrypted SMTP ('none') is refused unless the server is on this computer, because a password would
  otherwise cross the network in clear text.
* Header injection is impossible: a recipient or subject with a line break raises ValueError.
* The password is never logged and never put in an error message by this module.
"""
import smtplib
import ssl
from dataclasses import dataclass
from email.message import EmailMessage as MimeMessage
from email.utils import formatdate, make_msgid

LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
SECURITY_MODES = ("starttls", "ssl", "none")


@dataclass(frozen=True)
class SmtpConfig:
    host: str
    port: int
    sender: str
    username: str | None = None
    password: str | None = None
    security: str = "starttls"
    timeout: int = 15


def config_problems(host: str | None, port: int, sender: str | None, username: str | None,
                    password: str | None, security: str) -> list[str]:
    problems = []
    if not host:
        problems.append("CYBERSAATHI_SMTP_HOST is required when the email backend is smtp")
    if not sender or "@" not in sender:
        problems.append("CYBERSAATHI_SMTP_FROM must be an email address such as no-reply@yourdomain.com")
    if not 1 <= port <= 65535:
        problems.append("CYBERSAATHI_SMTP_PORT must be between 1 and 65535")
    if security not in SECURITY_MODES:
        problems.append("CYBERSAATHI_SMTP_SECURITY must be starttls, ssl or none")
    if security == "none" and host and host not in LOCAL_HOSTS:
        problems.append("Unencrypted SMTP is only allowed for a server on this computer")
    if bool(username) != bool(password):
        problems.append("CYBERSAATHI_SMTP_USERNAME and CYBERSAATHI_SMTP_PASSWORD must be set together")
    return problems


def build_message(sender: str, to: str, subject: str, body: str) -> MimeMessage:
    msg = MimeMessage()
    msg["From"], msg["To"], msg["Subject"] = sender, to, subject  # raises ValueError on line breaks
    msg["Date"] = formatdate(localtime=False)
    msg["Message-ID"] = make_msgid(domain=sender.rsplit("@", 1)[-1])
    msg.set_content(body)
    return msg


def send_via_smtp(cfg: SmtpConfig, to: str, subject: str, body: str) -> None:
    problems = config_problems(cfg.host, cfg.port, cfg.sender, cfg.username, cfg.password, cfg.security)
    if problems:
        raise ValueError(problems[0])
    message = build_message(cfg.sender, to, subject, body)
    context = ssl.create_default_context()
    if cfg.security == "ssl":
        client = smtplib.SMTP_SSL(cfg.host, cfg.port, timeout=cfg.timeout, context=context)
    else:
        client = smtplib.SMTP(cfg.host, cfg.port, timeout=cfg.timeout)
    with client:
        client.ehlo()
        if cfg.security == "starttls":
            client.starttls(context=context)
            client.ehlo()
        if cfg.username and cfg.password:
            client.login(cfg.username, cfg.password)
        client.send_message(message)
