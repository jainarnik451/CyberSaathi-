"""One-time tokens for email verification and password reset."""
import uuid
from datetime import timedelta

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.models.base import utcnow
from app.security.tokens import generate_token, hash_token


def issue_token(db: Session, model, user_id: uuid.UUID, ttl_minutes: int) -> str:
    raw = generate_token()
    db.add(model(user_id=user_id, token_hash=hash_token(raw), expires_at=utcnow() + timedelta(minutes=ttl_minutes)))
    return raw


def consume_token(db: Session, model, raw: str) -> uuid.UUID | None:
    """Validate and mark used. Returns the user id, or None if invalid/expired/used.

    The claim is a single conditional UPDATE, so two simultaneous requests with the same token cannot
    both succeed (a read-then-write would let both through).
    """
    row = db.execute(select(model).where(model.token_hash == hash_token(raw))).scalar_one_or_none()
    now = utcnow()
    if row is None or row.used_at is not None or row.expires_at < now:
        return None
    claimed = db.execute(update(model).where(model.id == row.id, model.used_at.is_(None)).values(used_at=now))
    if claimed.rowcount != 1:
        return None
    return row.user_id
