"""Wording of account emails. Pure functions. Links use the URL fragment (#), which browsers never send to a
server and web-server logs never record, so the token does not leak through access logs or Referer headers."""


def _base(base_url: str) -> str:
    return base_url.rstrip("/")


def verification_email(base_url: str, token: str) -> tuple[str, str]:
    return ("Verify your CyberSaathi email",
            "Welcome to CyberSaathi.\n\n"
            f"Your verification code:\n\n{token}\n\n"
            f"Or open this link in the browser on the same computer or phone you registered on:\n{_base(base_url)}/app/#/verify?token={token}\n\n"
            "You will also be asked for the password you chose when you registered. The code works for 24 hours.\n"
            "If you did not create an account, ignore this email. CyberSaathi never asks for your OTP, PIN or bank details.")


def reset_email(base_url: str, token: str) -> tuple[str, str]:
    return ("Reset your CyberSaathi password",
            f"Your password reset code (valid 1 hour):\n\n{token}\n\n"
            f"Or open this link:\n{_base(base_url)}/app/#/reset?token={token}\n\n"
            "If you did not request this, ignore this email. Your password stays unchanged.")
