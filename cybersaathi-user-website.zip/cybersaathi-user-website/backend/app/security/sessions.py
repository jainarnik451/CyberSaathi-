"""Server-side sessions. The browser holds a random token; the DB holds only its hash."""
import ipaddress
from datetime import timedelta

from fastapi import Request, Response
from sqlalchemy import update
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.base import utcnow
from app.models.user import User, UserSession
from app.security.rate_limit import client_ip
from app.security.rbac import is_privileged
from app.security.tokens import generate_token, hash_token

SESSION_COOKIE = "cs_session"
CSRF_COOKIE = "cs_csrf"


def ip_prefix(request: Request) -> str:
    """Store only a coarse network prefix (privacy)."""
    raw = client_ip(request)
    try:
        addr = ipaddress.ip_address(raw)
    except ValueError:
        return "unknown"
    prefix = 24 if addr.version == 4 else 48
    return str(ipaddress.ip_network(f"{addr}/{prefix}", strict=False))


def session_ttl_seconds(user: User) -> int:
    minutes = settings.privileged_session_ttl_minutes if is_privileged(user.role) else settings.session_ttl_minutes
    return minutes * 60


def create_session(db: Session, user: User, request: Request, mfa_passed: bool) -> tuple[str, str, UserSession]:
    raw_token, raw_csrf = generate_token(), generate_token()
    session = UserSession(
        user_id=user.id, token_hash=hash_token(raw_token), csrf_token_hash=hash_token(raw_csrf),
        mfa_passed=mfa_passed, ip_prefix=ip_prefix(request),
        user_agent=(request.headers.get("user-agent") or "")[:200],
        expires_at=utcnow() + timedelta(seconds=session_ttl_seconds(user)),
    )
    db.add(session)
    db.flush()
    return raw_token, raw_csrf, session


def set_auth_cookies(response: Response, raw_token: str, raw_csrf: str, max_age: int) -> None:
    response.set_cookie(SESSION_COOKIE, raw_token, max_age=max_age, httponly=True,
                        secure=settings.secure_cookies, samesite="lax", path="/")
    # CSRF cookie must be readable by the frontend so it can echo it in a header.
    response.set_cookie(CSRF_COOKIE, raw_csrf, max_age=max_age, httponly=False,
                        secure=settings.secure_cookies, samesite="lax", path="/")


def clear_auth_cookies(response: Response) -> None:
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")


def revoke_all_sessions(db: Session, user_id, except_session_id=None) -> int:
    """Revoke every live session of a user. Returns how many were revoked."""
    stmt = update(UserSession).where(UserSession.user_id == user_id, UserSession.revoked_at.is_(None))
    if except_session_id is not None:
        stmt = stmt.where(UserSession.id != except_session_id)
    return db.execute(stmt.values(revoked_at=utcnow())).rowcount or 0
