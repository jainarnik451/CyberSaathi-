"""FastAPI integration for the rate limiter."""
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.security.limiter import RateLimiter, limiter  # noqa: F401  (re-exported)


def client_ip(request: Request) -> str:
    # We deliberately do not trust X-Forwarded-For here. Behind a reverse proxy every user would
    # share the proxy's IP; configure trusted-proxy handling in deployment (see docs/DEPLOYMENT.md).
    return request.client.host if request.client else "unknown"


def rate_limit(scope: str, limit: int, window_seconds: int):
    def dependency(request: Request, db: Session = Depends(get_db)) -> None:
        result = limiter.hit(f"{scope}:{client_ip(request)}", limit, window_seconds)
        if not result.allowed:
            if result.first_block:  # one event per window, avoids flooding the log
                from app.services.security_events import record_security_event
                record_security_event(
                    db, category="RATE_LIMIT", severity="LOW", component="api",
                    metadata={"scope": scope, "limit": limit, "window_seconds": window_seconds},
                )
                db.commit()
            raise HTTPException(status_code=429, detail="Too many requests. Please try again later.",
                                headers={"Retry-After": str(window_seconds)})
    return dependency
