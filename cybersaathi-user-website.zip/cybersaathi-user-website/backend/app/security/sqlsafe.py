"""Helpers for building safe SQL fragments (values are still always passed as bound parameters)."""


def escape_like(value: str, escape: str = "\\") -> str:
    """Make %, _ and the escape character literal inside a LIKE pattern.

    Use as: column.ilike(f"%{escape_like(q)}%", escape="\\")
    """
    return value.replace(escape, escape * 2).replace("%", escape + "%").replace("_", escape + "_")
