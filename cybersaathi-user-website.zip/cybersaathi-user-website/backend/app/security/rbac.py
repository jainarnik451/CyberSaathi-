"""Role-based access control. Deny by default.

Permissions live in code (reviewable in Git, not editable through the database).
"""
from enum import Enum


class Role(str, Enum):
    OWNER = "OWNER"
    ADMIN = "ADMIN"
    SECURITY_ANALYST = "SECURITY_ANALYST"
    STANDARD_USER = "STANDARD_USER"


PRIVILEGED_ROLES = {Role.OWNER.value, Role.ADMIN.value, Role.SECURITY_ANALYST.value}

# Permission names
OWNER_OVERVIEW_READ = "owner:overview:read"
OWNER_USERS_READ = "owner:users:read"
OWNER_USERS_WRITE = "owner:users:write"
OWNER_ROLES_WRITE = "owner:roles:write"
OWNER_AUDIT_READ = "owner:audit:read"
OWNER_HEALTH_READ = "owner:health:read"
OWNER_FEATURES_READ = "owner:features:read"
OWNER_FEATURES_WRITE = "owner:features:write"
OWNER_RELEASES_READ = "owner:releases:read"
OWNER_BACKUP_READ = "owner:backup:read"
OWNER_ERRORS_READ = "owner:errors:read"
OWNER_DEVSTATUS_READ = "owner:devstatus:read"
OWNER_NOTIFICATIONS = "owner:notifications:manage"
OWNER_COMMUNITY_MODERATE = "owner:community:moderate"
SECURITY_EVENTS_READ = "security:events:read"
SECURITY_EVENTS_WRITE = "security:events:write"

_OWNER_ONLY = {
    OWNER_USERS_WRITE, OWNER_ROLES_WRITE, OWNER_AUDIT_READ, OWNER_HEALTH_READ, OWNER_FEATURES_READ,
    OWNER_FEATURES_WRITE, OWNER_RELEASES_READ, OWNER_BACKUP_READ, OWNER_DEVSTATUS_READ, OWNER_NOTIFICATIONS,
    OWNER_COMMUNITY_MODERATE,
}

ROLE_PERMISSIONS: dict[str, frozenset[str]] = {
    Role.OWNER.value: frozenset(_OWNER_ONLY | {
        OWNER_OVERVIEW_READ, OWNER_USERS_READ, OWNER_ERRORS_READ, SECURITY_EVENTS_READ, SECURITY_EVENTS_WRITE,
    }),
    Role.ADMIN.value: frozenset({OWNER_OVERVIEW_READ, OWNER_USERS_READ, SECURITY_EVENTS_READ}),
    Role.SECURITY_ANALYST.value: frozenset({SECURITY_EVENTS_READ, SECURITY_EVENTS_WRITE, OWNER_ERRORS_READ}),
    Role.STANDARD_USER.value: frozenset(),
}


def has_permission(role: str, permission: str) -> bool:
    return permission in ROLE_PERMISSIONS.get(role, frozenset())


def is_privileged(role: str) -> bool:
    return role in PRIVILEGED_ROLES
