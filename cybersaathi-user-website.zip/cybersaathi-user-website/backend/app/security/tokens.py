"""Random tokens. Only hashes are stored in the database."""
import hashlib
import hmac
import secrets

from app.core.config import settings


def generate_token() -> str:
    return secrets.token_urlsafe(32)  # 256 bits


def hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())


def pseudonymize(value: str) -> str:
    """Keyed hash so logs can correlate events without storing the raw value."""
    return hmac.new(settings.secret_key.encode(), value.lower().encode(), hashlib.sha256).hexdigest()[:16]
