"""PII redaction and safe-metadata helpers.

Best-effort pattern matching: it reduces, but cannot eliminate, personal data in
stored text. Users are told this in the UI and privacy docs.
"""
import re

_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")),
    ("UPI_ID", re.compile(r"\b[\w.\-]{2,}@[a-zA-Z]{2,}\b")),
    ("URL_CREDENTIALS", re.compile(r"(?i)\b(?:https?://)[^\s/@:]+:[^\s/@]+@")),
    ("PAN", re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")),
    # CARD (13-19 digits) must run before AADHAAR (12 digits), otherwise the first 12 digits of a
    # card number would be matched as an Aadhaar number and the rest left visible.
    ("CARD", re.compile(r"\b(?:\d[ -]?){12,18}\d\b")),
    ("AADHAAR", re.compile(r"\b\d{4}[ -]?\d{4}[ -]?\d{4}\b")),
    ("PHONE", re.compile(r"(?<!\w)(?:\+?\d{1,3}[ -]?)?(?:\d[ -]?){9,11}\d(?!\w)")),
]


def redact_text(text: str) -> str:
    for label, pattern in _PATTERNS:
        text = pattern.sub(f"[{label} REDACTED]", text)
    return text


_FORBIDDEN_KEYS = {"password", "token", "otp", "code", "secret", "message", "messages", "text", "authorization", "cookie"}


def sanitize_metadata(data, depth: int = 0):
    """Remove sensitive keys and truncate long strings before storing event/audit metadata."""
    if depth > 4:
        return "[truncated]"
    if isinstance(data, dict):
        return {
            str(k): ("[removed]" if str(k).lower() in _FORBIDDEN_KEYS else sanitize_metadata(v, depth + 1))
            for k, v in list(data.items())[:50]
        }
    if isinstance(data, (list, tuple)):
        return [sanitize_metadata(v, depth + 1) for v in list(data)[:50]]
    if isinstance(data, str):
        return data[:300]
    return data
