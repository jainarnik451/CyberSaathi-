"""Argon2id password hashing and password policy."""
import os

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from app.security.gate import ConcurrencyGate

_hasher = PasswordHasher()  # argon2-cffi defaults to Argon2id
# At most N hashes at once (each uses ~64 MiB). Extra requests wait briefly, then get HTTP 503.
_gate = ConcurrencyGate(int(os.environ.get("CYBERSAATHI_MAX_CONCURRENT_HASHES", "4")), wait_seconds=15.0)
_DUMMY_HASH = _hasher.hash("dummy-password-for-timing-equalisation")

_COMMON = {
    "password1234", "123456789012", "qwertyuiop12", "iloveyou1234", "admin1234567",
    "welcome12345", "letmein12345", "password12345", "cybersaathi",
}


def hash_password(password: str) -> str:
    with _gate.slot():
        return _hasher.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    with _gate.slot():
        try:
            return _hasher.verify(stored_hash, password)
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False


def verify_dummy(password: str) -> None:
    """Spend similar time as a real verification (reduces user-enumeration timing signal)."""
    verify_password(_DUMMY_HASH, password)


def needs_rehash(stored_hash: str) -> bool:
    return _hasher.check_needs_rehash(stored_hash)


def password_problems(password: str, email: str = "") -> list[str]:
    problems = []
    if len(password) < 12:
        problems.append("Password must be at least 12 characters long.")
    if len(password) > 128:
        problems.append("Password must be at most 128 characters long.")
    if password.lower() in _COMMON:
        problems.append("Password is too common.")
    local = email.split("@")[0].lower() if email else ""
    if local and len(local) >= 4 and local in password.lower():
        problems.append("Password must not contain your email name.")
    if password.strip() != password or not password.strip():
        problems.append("Password must not start or end with spaces.")
    return problems
