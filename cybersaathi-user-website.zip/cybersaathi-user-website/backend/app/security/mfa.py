"""TOTP multi-factor authentication (RFC 6238) with replay protection."""
import hmac
import time

import pyotp

STEP_SECONDS = 30


def new_secret() -> str:
    return pyotp.random_base32()


def provisioning_uri(secret: str, email: str) -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=email, issuer_name="CyberSaathi")


def verify_totp(secret: str, code: str, last_step: int | None) -> int | None:
    """Return the matched time step, or None. A step can only be used once."""
    code = code.strip()
    if not (code.isdigit() and len(code) == 6):
        return None
    totp = pyotp.TOTP(secret)
    current = int(time.time()) // STEP_SECONDS
    for offset in (-1, 0, 1):
        step = current + offset
        if hmac.compare_digest(totp.generate_otp(step), code) and (last_step is None or step > last_step):
            return step
    return None
