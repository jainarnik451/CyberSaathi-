"""Limit how many memory-hungry operations (Argon2 hashing, ~64 MiB each) run at the same time.

Without a cap, a burst of login requests from many addresses could exhaust server memory even though
each address is individually rate limited.
"""
import threading
from collections.abc import Iterator
from contextlib import contextmanager


class BusyError(Exception):
    """Raised when no slot frees up in time. The API turns this into HTTP 503."""


class ConcurrencyGate:
    def __init__(self, limit: int, wait_seconds: float) -> None:
        self._semaphore = threading.BoundedSemaphore(max(1, limit))
        self._wait = wait_seconds

    @contextmanager
    def slot(self) -> Iterator[None]:
        if not self._semaphore.acquire(timeout=self._wait):
            raise BusyError("too many concurrent password operations")
        try:
            yield
        finally:
            self._semaphore.release()
