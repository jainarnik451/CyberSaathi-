"""Sliding-window rate limiter core (in-memory, no third-party imports so it is easy to test).

LIMITATION: counters are per-process. With several backend workers, use Redis instead.
Blocked attempts are NOT recorded: memory stays bounded and a block ends when the window slides.
"""
import threading
import time
from collections import deque
from typing import NamedTuple

_MAX_WINDOW = 3600


class HitResult(NamedTuple):
    allowed: bool
    attempts: int  # NOT named "count": that would shadow tuple.count()
    first_block: bool  # True only for the first denial in a window (use it to log one event, not thousands)


class RateLimiter:
    def __init__(self, max_keys: int = 50_000) -> None:
        self._hits: dict[str, deque[float]] = {}
        self._alerted: dict[str, float] = {}
        self._lock = threading.Lock()
        self._max_keys = max_keys

    def _purge(self, now: float) -> None:
        self._hits = {k: q for k, q in self._hits.items() if q and now - q[-1] <= _MAX_WINDOW}
        self._alerted = {k: t for k, t in self._alerted.items() if now - t <= _MAX_WINDOW}

    def hit(self, key: str, limit: int, window_seconds: int) -> HitResult:
        now = time.monotonic()
        with self._lock:
            q = self._hits.get(key)
            if q is None:
                if len(self._hits) >= self._max_keys:
                    self._purge(now)
                q = self._hits[key] = deque()
            while q and now - q[0] > window_seconds:
                q.popleft()
            if len(q) < limit:
                q.append(now)
                return HitResult(True, len(q), False)
            last = self._alerted.get(key)
            first = last is None or now - last > window_seconds
            if first:
                self._alerted[key] = now
            return HitResult(False, len(q), first)

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()
            self._alerted.clear()


limiter = RateLimiter()
