"""Scam Pattern Early-Warning Network: privacy-preserving, moderated, aggregate-only. Pure logic."""
