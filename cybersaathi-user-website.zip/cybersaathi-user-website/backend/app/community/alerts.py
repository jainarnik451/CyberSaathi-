"""Alert rules: when a cluster may be published, what the text says, and when it is pulled back.

* Publishing needs BOTH enough distinct reporters (MIN_REPORTERS) AND explicit moderator approval.
* The text comes from a template over fixed choices. No free text exists anywhere in the pipeline, so an
  alert cannot name a person, organisation, number or link.
* Wording says "reported pattern", never "confirmed scam", because reports are unverified.
* Enough independent 'inaccurate' flags move a published alert back to review automatically.
"""
from app.community.reports import LABELS

MIN_REPORTERS = 3
FLAGS_TO_REVIEW = 2
STATUSES = ("PENDING", "PUBLISHED", "REJECTED", "UNDER_REVIEW")
_TRANSITIONS = {  # moderator/system moves allowed from each status
    "PENDING": {"PUBLISHED", "REJECTED"},
    "PUBLISHED": {"UNDER_REVIEW", "REJECTED"},
    "UNDER_REVIEW": {"PUBLISHED", "REJECTED"},
    "REJECTED": set(),
}
DISCLAIMER = ("This alert summarises a pattern that several people reported. It has not been independently verified and does not name or accuse any person or organisation. "
              "If it does not match your situation, it does not mean you are safe.")


def can_publish(distinct_reporters: int) -> tuple[bool, str]:
    if distinct_reporters < MIN_REPORTERS:
        return False, f"Needs reports from at least {MIN_REPORTERS} different people (has {distinct_reporters})."
    return True, ""


def build_alert_text(cluster: dict) -> dict:
    """Title and body from enums only. `cluster` comes from similarity.group_reports."""
    kind, chan = LABELS[cluster["scam_type"]], LABELS[cluster["channel"]]
    tactics = [LABELS[t] for t in list(cluster["tactic_counts"])[:4]]
    body = f"Several people reported this pattern, mostly through {chan}."
    if tactics:
        body += " Reports commonly mention " + (", ".join(tactics[:-1]) + (" and " if len(tactics) > 1 else "") + tactics[-1]) + "."
    body += " Take time to verify before paying or sharing information, and use the Recovery Navigator if you already did."
    return {"title": f"Reported pattern: {kind} ({chan})", "body": body, "disclaimer": DISCLAIMER}


def transition(current: str, target: str) -> str:
    if current not in STATUSES or target not in STATUSES:
        raise ValueError("unknown status")
    if target not in _TRANSITIONS[current]:
        raise ValueError(f"cannot move an alert from {current} to {target}")
    return target


def status_after_flag(status: str, distinct_flaggers: int) -> str:
    """A published alert returns to review once enough different users flag it as inaccurate."""
    return "UNDER_REVIEW" if status == "PUBLISHED" and distinct_flaggers >= FLAGS_TO_REVIEW else status


def public_view(alert: dict) -> dict | None:
    """What an ordinary user may see. Anything not PUBLISHED is invisible; counts are shown, identities never are."""
    if alert.get("status") != "PUBLISHED":
        return None
    return {k: alert[k] for k in ("id", "title", "body", "disclaimer", "scam_type", "channel", "published_at", "reporter_count")}
