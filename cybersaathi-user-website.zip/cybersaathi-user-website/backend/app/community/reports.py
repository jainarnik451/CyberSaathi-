"""Voluntary pattern reports. A report holds ONLY choices from fixed lists, so it cannot contain a name, phone
number, link, account number or any message text. There is deliberately no free-text field."""
import hashlib
import hmac
from datetime import date, timedelta

SCAM_TYPES = ("FAKE_INTERNSHIP", "SCHOLARSHIP_FEE", "QR_PAYMENT", "INSTITUTION_IMPERSONATION", "FAKE_SUPPORT", "OTP_REQUEST", "OTHER")
CHANNELS = ("WHATSAPP", "TELEGRAM", "SMS", "EMAIL", "PHONE_CALL", "SOCIAL_MEDIA", "WEBSITE", "OTHER")
TACTICS = ("URGENCY", "PAYMENT_REQUEST", "SECRECY", "CHANNEL_SHIFT", "AUTHORITY_CLAIM", "REMOTE_ACCESS", "SECRET_CODES", "PERSONAL_INFO_REQUEST")
MAX_TACTICS = len(TACTICS)
LABELS = {
    "FAKE_INTERNSHIP": "Fake internship offers", "SCHOLARSHIP_FEE": "Scholarship fee requests", "QR_PAYMENT": "QR-code or collect-request payment tricks",
    "INSTITUTION_IMPERSONATION": "Messages pretending to be from an educational institution", "FAKE_SUPPORT": "Fake customer support",
    "OTP_REQUEST": "Requests for OTPs or confidential codes", "OTHER": "Other scam pattern",
    "WHATSAPP": "WhatsApp", "TELEGRAM": "Telegram", "SMS": "SMS", "EMAIL": "email", "PHONE_CALL": "phone calls", "SOCIAL_MEDIA": "social media", "WEBSITE": "websites",
    "URGENCY": "urgency", "PAYMENT_REQUEST": "a payment request", "SECRECY": "a request for secrecy", "CHANNEL_SHIFT": "a move to a private chat",
    "AUTHORITY_CLAIM": "claims of authority", "REMOTE_ACCESS": "remote-access apps", "SECRET_CODES": "requests for secret codes",
    "PERSONAL_INFO_REQUEST": "requests for personal information",
}


class ReportError(ValueError):
    pass


def week_start(d: date) -> date:
    return d - timedelta(days=d.weekday())


def clean_report(payload: dict, today: date) -> dict:
    """Validate and normalise. Any field outside the allowed list is rejected, never stored."""
    if not isinstance(payload, dict):
        raise ReportError("Send an object")
    extra = set(payload) - {"scam_type", "channel", "tactics", "payment_requested", "region"}
    if extra:
        raise ReportError("Only fixed choices can be reported. Free text and identifiers are not accepted.")
    if payload.get("scam_type") not in SCAM_TYPES:
        raise ReportError("scam_type is not one of the allowed values")
    if payload.get("channel") not in CHANNELS:
        raise ReportError("channel is not one of the allowed values")
    tactics = payload.get("tactics", [])
    if not isinstance(tactics, list) or len(tactics) > MAX_TACTICS or any(t not in TACTICS for t in tactics):
        raise ReportError("tactics must be a list of allowed values")
    pay = payload.get("payment_requested", False)
    if not isinstance(pay, bool):
        raise ReportError("payment_requested must be true or false")
    region = payload.get("region")
    if region is not None and not (isinstance(region, str) and len(region) == 2 and region.isalpha() and region.isascii()):
        raise ReportError("region must be a two-letter country code")
    return {"scam_type": payload["scam_type"], "channel": payload["channel"], "tactics": sorted(set(tactics)),
            "payment_requested": pay, "region": region.upper() if region else None, "week": week_start(today).isoformat()}


def reporter_key(user_id: int, secret: str) -> str:
    """Keyed hash so the reports table does not directly list user ids. It only serves to count distinct reporters."""
    if not secret or len(secret) < 16:
        raise ValueError("a server secret of at least 16 characters is required")
    return hmac.new(secret.encode(), f"reporter:{user_id}".encode(), hashlib.sha256).hexdigest()


def fingerprint(clean: dict) -> str:
    basis = "|".join([clean["scam_type"], clean["channel"], ",".join(clean["tactics"]), str(clean["payment_requested"]), clean["week"]])
    return hashlib.sha256(basis.encode()).hexdigest()[:32]
