"""Group similar reports. Similar = same scam type and channel, with overlapping tactics (Jaccard >= threshold)."""
MIN_JACCARD = 0.5


def jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 1.0
    return len(a & b) / len(a | b)


def group_reports(reports: list[dict], threshold: float = MIN_JACCARD) -> list[dict]:
    """reports: [{'scam_type','channel','tactics','week','reporter'}]. Returns clusters, biggest first.
    Greedy and deterministic: each report joins the first cluster it is similar to, in input order."""
    clusters: list[dict] = []
    for r in reports:
        tactics = set(r["tactics"])
        for c in clusters:
            if c["scam_type"] == r["scam_type"] and c["channel"] == r["channel"] and jaccard(tactics, c["_seed"]) >= threshold:
                c["_members"].append(r)
                break
        else:
            clusters.append({"scam_type": r["scam_type"], "channel": r["channel"], "_seed": tactics, "_members": [r]})
    out = []
    for c in clusters:
        m = c["_members"]
        freq: dict[str, int] = {}
        for r in m:
            for t in r["tactics"]:
                freq[t] = freq.get(t, 0) + 1
        out.append({"scam_type": c["scam_type"], "channel": c["channel"], "report_count": len(m),
                    "distinct_reporters": len({r["reporter"] for r in m}),
                    "first_week": min(r["week"] for r in m), "last_week": max(r["week"] for r in m),
                    "tactic_counts": dict(sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))),
                    "payment_requested_count": sum(bool(r.get("payment_requested")) for r in m)})
    return sorted(out, key=lambda c: (-c["distinct_reporters"], -c["report_count"], c["scam_type"], c["channel"]))


def weekly_trend(reports: list[dict]) -> list[dict]:
    """Counts per week (ISO date of Monday). Only weeks that have reports appear; nothing is invented."""
    counts: dict[str, int] = {}
    for r in reports:
        counts[r["week"]] = counts.get(r["week"], 0) + 1
    return [{"week": w, "reports": n} for w, n in sorted(counts.items())]
