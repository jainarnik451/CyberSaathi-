"""Unified analysis report: one consistent risk indicator over the Journey and Exposure results."""
from app.analysis.journey import LEVELS

INDICATOR = {
    "NOT_ENOUGH_SIGNALS": {"label": "Few warning patterns found", "tone": "neutral",
                           "headline": "The pattern rules found few warning signs. That does not prove the messages are safe."},
    "SOME_CONCERNS": {"label": "Some warning patterns", "tone": "caution",
                      "headline": "Some patterns here are commonly seen in scams. Verify who is contacting you before acting."},
    "STRONG_CONCERNS": {"label": "Strong warning patterns", "tone": "danger",
                        "headline": "Several strong warning patterns are present. Pause and verify before paying or sharing anything."},
}
_EXPOSURE_FLOOR = {"CRITICAL": "STRONG_CONCERNS", "HIGH": "SOME_CONCERNS"}


def combine_levels(*levels: str | None) -> str:
    known = [l for l in levels if l in LEVELS]
    return max(known, key=LEVELS.index) if known else "NOT_ENOUGH_SIGNALS"


def build_unified(journey: dict | None, exposure: dict | None) -> dict:
    """Either part may be None (its feature is switched off). The overall level is the highest of the parts."""
    if journey is None and exposure is None:
        raise ValueError("at least one analysis is required")
    floor = _EXPOSURE_FLOOR.get((exposure or {}).get("highest_sensitivity"))
    level = combine_levels((journey or {}).get("level"), floor)
    steps = list((journey or {}).get("next_steps", []))
    if exposure and exposure["categories"]:
        steps.append("Before sharing any personal detail, read the Exposure Map for safer alternatives.")
    return {
        "level": level, "indicator": INDICATOR[level], "journey": journey, "exposure": exposure,
        "next_steps": list(dict.fromkeys(steps)),
        "engine": "pattern-rules-v1",
        "honesty_note": "This report comes from transparent pattern rules, not an AI model. It lists indicators with evidence from your own text. "
                        "It is not a verdict about any person or organisation, and nothing was sent, opened or checked online.",
        "includes": {"journey": journey is not None, "exposure": exposure is not None},
    }
