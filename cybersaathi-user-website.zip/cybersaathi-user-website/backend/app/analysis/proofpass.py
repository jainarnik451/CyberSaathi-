"""ProofPass: organises evidence the USER supplies for each claim. It performs NO web lookups.

Honest by construction:
* VERIFIED needs evidence from a trusted source type AND the user's statement that they confirmed it
  themselves. CyberSaathi did not check it, and the result says so ("human-confirmed").
* A claim with no evidence is UNKNOWN. Absence of a website/registration/listing is never WARNING by itself.
* WARNING needs evidence that contradicts the claim, or an automated check that found a concrete inconsistency.
* Automated checks are offline text checks on what was typed (they never fetch anything) and are listed
  separately. They can add WARNING items but can never make a claim VERIFIED.
"""
import re
from datetime import date
from urllib.parse import urlsplit

CLAIM_TYPES = ("COMPANY", "INTERNSHIP", "SCHOLARSHIP", "COMPETITION", "INSTITUTION", "ONLINE_OPPORTUNITY")
SOURCE_TYPES = {  # type -> (label, official/independent class, trusted for VERIFIED)
    "OFFICIAL_WEBSITE": ("The organisation's own official website", "OFFICIAL", True),
    "GOVERNMENT_REGISTRY": ("Government or regulator record", "OFFICIAL", True),
    "INSTITUTION_CONFIRMATION": ("Confirmation from your college or institution", "INDEPENDENT", True),
    "DIRECT_CONTACT": ("You contacted the organisation through details you found yourself", "OFFICIAL", True),
    "INDEPENDENT_NEWS": ("Independent news or review source", "INDEPENDENT", True),
    "MESSAGE_ONLY": ("Only the message you received", "UNVERIFIED", False),
    "OTHER": ("Other source", "UNVERIFIED", False),
}
SUPPORTS = ("SUPPORTS", "CONTRADICTS", "NEUTRAL")
STATUSES = ("VERIFIED", "WARNING", "UNKNOWN")
MAX_CLAIMS, MAX_EVIDENCE, STALE_YEARS = 10, 8, 2
FREE_MAIL = {"gmail.com", "yahoo.com", "yahoo.in", "outlook.com", "hotmail.com", "rediffmail.com", "proton.me", "protonmail.com", "icloud.com"}
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "cutt.ly", "rb.gy", "is.gd"}


class ProofInputError(ValueError):
    pass


def _text(value, name, limit, required=True):
    if value is None or (isinstance(value, str) and not value.strip()):
        if required:
            raise ProofInputError(f"{name} is required")
        return None
    if not isinstance(value, str) or len(value) > limit:
        raise ProofInputError(f"{name} must be text of at most {limit} characters")
    return " ".join(value.split())


def clean_source_url(value) -> str | None:
    """Stored as TEXT only and never fetched. Only http/https, no embedded credentials."""
    url = _text(value, "source_url", 300, required=False)
    if not url:
        return None
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname or parts.username or parts.password:
        raise ProofInputError("source_url must be a plain http or https address without a username or password")
    return url


def parse_date(value, today: date) -> date | None:
    if value in (None, ""):
        return None
    try:
        d = date.fromisoformat(str(value))
    except ValueError:
        raise ProofInputError("source_date must look like 2026-11-04") from None
    if d > today:
        raise ProofInputError("source_date cannot be in the future")
    return d


def automated_checks(org_name: str | None, sender_email: str | None, claimed_website: str | None) -> list[dict]:
    """Offline checks on typed text. They report an observation and its limits; none contacts anyone."""
    out = []
    org_tokens = [t for t in re.findall(r"[a-z0-9]+", (org_name or "").lower()) if len(t) >= 4 and t not in ("pvt", "ltd", "limited", "private", "technologies", "solutions", "services")]
    domain = None
    if sender_email:
        if not re.fullmatch(r"[^@\s]{1,64}@[^@\s]{1,255}", sender_email.strip()):
            raise ProofInputError("sender_email does not look like an email address")
        domain = sender_email.strip().rsplit("@", 1)[1].lower()
        if domain in FREE_MAIL:
            out.append(_check("sender_free_mail", "WARNING", f"The sender uses a free email service ({domain}).",
                              "Many genuine individuals and small teams use free email, but established organisations usually use their own domain."))
        elif org_tokens and not any(t in domain for t in org_tokens):
            out.append(_check("sender_domain_mismatch", "WARNING", f"The sender's email domain ({domain}) does not contain the organisation name you gave.",
                              "Organisations sometimes use parent-company or third-party domains, so confirm which domain is theirs from an official source."))
    for label, host in (("sender domain", domain), ("website", (urlsplit(claimed_website).hostname if claimed_website else None))):
        if not host:
            continue
        host = host.lower()
        if host.startswith("xn--") or ".xn--" in host or any(ord(c) > 127 for c in host):
            out.append(_check(f"{label.replace(' ', '_')}_lookalike", "WARNING", f"The {label} ({host}) uses international or look-alike characters.",
                              "This can be used to imitate a familiar name, though some real domains use such characters."))
        if host in SHORTENERS:
            out.append(_check("link_shortener", "WARNING", f"The {label} is a link shortener ({host}), which hides the real destination.",
                              "Ask for the full address."))
    if claimed_website:
        host = (urlsplit(claimed_website).hostname or "").lower()
        if org_tokens and host and not any(t in host for t in org_tokens) and host not in SHORTENERS:
            out.append(_check("website_name_mismatch", "WARNING", f"The website address ({host}) does not contain the organisation name you gave.",
                              "Genuine organisations may use a different brand name in the web address."))
    out.append(_check("no_lookup", "INFO", "CyberSaathi did not look anything up online.",
                      "These are text checks on what you typed. They cannot confirm an organisation exists or is genuine."))
    return out


def _check(id_, level, finding, limit):
    return {"id": id_, "method": "automated_text_check", "level": level, "finding": finding, "limitation": limit}


def evaluate_claim(claim: dict, today: date) -> dict:
    text = _text(claim.get("claim") if isinstance(claim, dict) else None, "claim", 300)
    raw_ev = claim.get("evidence") or []
    if not isinstance(raw_ev, list) or len(raw_ev) > MAX_EVIDENCE:
        raise ProofInputError(f"At most {MAX_EVIDENCE} pieces of evidence per claim")
    evidence = []
    for e in raw_ev:
        if not isinstance(e, dict):
            raise ProofInputError("Each evidence item must be an object")
        stype = e.get("source_type")
        if stype not in SOURCE_TYPES:
            raise ProofInputError("source_type is not one of the allowed values")
        supports = e.get("supports", "NEUTRAL")
        if supports not in SUPPORTS:
            raise ProofInputError("supports must be SUPPORTS, CONTRADICTS or NEUTRAL")
        label, klass, trusted = SOURCE_TYPES[stype]
        sdate = parse_date(e.get("source_date"), today)
        evidence.append({
            "what_was_found": _text(e.get("what_was_found"), "what_was_found", 400),
            "source_type": stype, "source_type_label": label, "source_class": klass,
            "source_name": _text(e.get("source_name"), "source_name", 120, required=False),
            "source_url": clean_source_url(e.get("source_url")),
            "source_date": sdate.isoformat() if sdate else None,
            "supports": supports, "trusted_type": trusted,
            "confirmed_by": "user" if e.get("human_confirmed") is True else "not_confirmed",
            "checked_by_cybersaathi": False,
            "stale": bool(sdate and (today - sdate).days > 365 * STALE_YEARS),
        })
    contradicting = [e for e in evidence if e["supports"] == "CONTRADICTS"]
    verifying = [e for e in evidence if e["supports"] == "SUPPORTS" and e["trusted_type"] and e["confirmed_by"] == "user"]
    unconfirmed_support = [e for e in evidence if e["supports"] == "SUPPORTS" and e not in verifying]
    unknowns, status, reason = [], "UNKNOWN", ""
    if contradicting:
        status, reason = "WARNING", "Evidence you supplied contradicts this claim. That is a concern to investigate, not proof of fraud."
        unknowns.append("Whether the contradicting source is itself accurate and current.")
    elif verifying:
        status, reason = "VERIFIED", "Supported by a trusted source type that you confirmed yourself. CyberSaathi did not check it independently."
        if all(e["stale"] for e in verifying):
            status, reason = "UNKNOWN", "The only supporting evidence is old (over two years), so it may no longer be accurate."
            unknowns.append("Whether this is still true today.")
    elif unconfirmed_support:
        reason = "Supporting evidence was listed but not confirmed by you, or comes from a source type that cannot verify it (for example the message itself)."
        unknowns.append("Whether the supporting evidence was confirmed through a source the sender does not control.")
    else:
        reason = "No evidence was supplied. This is unknown, which is not the same as suspicious: many genuine organisations are small or hard to find online."
        unknowns.append("No independent evidence for or against this claim has been provided.")
    if not any(e["source_class"] == "OFFICIAL" for e in evidence):
        unknowns.append("No official source has been provided.")
    if not any(e["source_class"] == "INDEPENDENT" for e in evidence):
        unknowns.append("No independent source has been provided.")
    if any(e["stale"] for e in evidence) and status != "UNKNOWN":
        unknowns.append("Some sources are more than two years old.")
    next_step = {
        "VERIFIED": "Keep a record of what you checked and when. Re-check before paying or sharing sensitive data, in case things changed.",
        "WARNING": "Pause. Ask the organisation to explain the inconsistency through official contact details you find yourself, and ask your college or a trusted adult.",
        "UNKNOWN": "Look for an official source yourself (type the organisation's website address, check with your college placement cell, or find a government record) and add what you find.",
    }[status]
    return {"claim": text, "status": status, "status_reason": reason, "evidence": evidence, "remaining_unknowns": unknowns, "next_step": next_step}


def build_proofpass(payload: dict, today: date | None = None) -> dict:
    today = today or date.today()
    if not isinstance(payload, dict):
        raise ProofInputError("Send an object")
    ctype = payload.get("claim_type")
    if ctype not in CLAIM_TYPES:
        raise ProofInputError("claim_type is not one of the allowed values")
    claims = payload.get("claims")
    if not isinstance(claims, list) or not 1 <= len(claims) <= MAX_CLAIMS:
        raise ProofInputError(f"Provide between 1 and {MAX_CLAIMS} claims")
    org = _text(payload.get("organisation_name"), "organisation_name", 120, required=False)
    sender = _text(payload.get("sender_email"), "sender_email", 320, required=False)
    site = clean_source_url(payload.get("claimed_website"))
    results = [evaluate_claim(c, today) for c in claims]
    auto = automated_checks(org, sender, site)
    counts = {s: sum(r["status"] == s for r in results) for s in STATUSES}
    return {
        "claim_type": ctype, "organisation_name": org, "claims": results, "automated_checks": auto,
        "summary_counts": counts,
        "explanation": "VERIFIED means evidence from a trusted source that YOU confirmed. UNKNOWN means not enough evidence either way. "
                       "WARNING means a specific inconsistency. A missing website or listing alone is never treated as proof of fraud.",
        "separation_note": "Automated checks are text checks only. Human-confirmed items are only those you marked as confirmed yourself.",
    }
