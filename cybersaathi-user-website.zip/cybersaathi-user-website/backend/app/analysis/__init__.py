"""Pattern-based analysis engine. Pure Python: no database, no network, no AI calls.

Everything here is deterministic and testable. It reports INDICATORS with verbatim evidence; it never
declares that someone is a fraudster.
"""
