"""Trust Journey X-Ray: turns ordered messages into a timeline of indicators with evidence.

Output separates FACTS (what the text literally contains), INDICATORS (patterns worth weighing),
ASSUMPTIONS (what this tool assumes) and UNKNOWNS (what it cannot know). It never says "this is a scam";
the strongest label is "strong concerns".
"""
from app.analysis.signals import AI_INSTRUCTION, CATEGORY_LABELS, CONTEXT_CHARS, find_hits
from app.analysis.text import Message
from app.security.redaction import redact_text

ENGINE = "pattern-rules-v1"
LEVELS = ("NOT_ENOUGH_SIGNALS", "SOME_CONCERNS", "STRONG_CONCERNS")
STRONG_SCORE, SOME_SCORE = 8, 3


def evidence_snippet(text: str, start: int, end: int) -> tuple[str, str]:
    """(matched_quote, context_snippet), both redacted for output. Offsets index the cleaned text."""
    lo, hi = max(0, start - CONTEXT_CHARS), min(len(text), end + CONTEXT_CHARS)
    return redact_text(text[start:end]), ("…" if lo else "") + redact_text(text[lo:hi]) + ("…" if hi < len(text) else "")


def _level(score: int, categories: set[str], has_secret_request: bool) -> str:
    if has_secret_request or (score >= STRONG_SCORE and len(categories) >= 3):
        return "STRONG_CONCERNS"
    return "SOME_CONCERNS" if score >= SOME_SCORE else "NOT_ENOUGH_SIGNALS"


def _sequence_notes(events: list[dict]) -> list[str]:
    """Explain the ORDER of events, using only categories actually found."""
    first = {}
    for e in events:
        first.setdefault(e["category"], e)
    notes = []
    offer, pay = first.get("UNSOLICITED_OFFER"), first.get("PAYMENT_REQUEST")
    if offer and pay and offer["message_index"] <= pay["message_index"]:
        notes.append(f"A selection or reward message (message {offer['message_index'] + 1}) comes before the first request for money "
                     f"(message {pay['message_index'] + 1}). Building excitement first and asking for money afterwards is a common pattern.")
    if pay:
        later = [e for e in events if e["category"] in ("URGENCY", "PRESSURE_TACTICS") and e["message_index"] >= pay["message_index"]]
        if later:
            notes.append(f"Pressure or urgency appears at or after the money request (message {later[0]['message_index'] + 1}). "
                         "Pressure at the moment of payment leaves little time to verify.")
    shift = first.get("CHANNEL_SHIFT")
    if shift and pay and shift["message_index"] <= pay["message_index"]:
        notes.append("The conversation was moved to a private chat before money was requested.")
    return notes


def analyze_journey(messages: list[Message], ordering_note: str) -> dict:
    events, ai_attempts = [], 0
    for m in messages:
        for hit in find_hits(m.text):
            if hit.signal.category == AI_INSTRUCTION:
                ai_attempts += 1
            quote, ctx = evidence_snippet(m.text, hit.start, hit.end)
            events.append({
                "message_index": m.index, "sender": m.sender, "time": m.timestamp.isoformat() if m.timestamp else None,
                "signal_id": hit.signal.id, "category": hit.signal.category, "category_label": CATEGORY_LABELS[hit.signal.category],
                "title": hit.signal.title, "weight": hit.signal.weight, "why_it_matters": hit.signal.why,
                "possible_harmless_explanation": hit.signal.harmless, "evidence_quote": quote, "evidence_context": ctx,
            })
    scored = [e for e in events if e["weight"] > 0]
    cats = {e["category"] for e in scored}
    score = sum(e["weight"] for e in scored)
    secret = any(e["category"] == "CREDENTIAL_REQUEST" for e in scored)
    level = _level(score, cats, secret)
    timeline = [{"message_index": m.index, "sender": m.sender, "time": m.timestamp.isoformat() if m.timestamp else None,
                 "preview": redact_text(m.text[:140]) + ("…" if len(m.text) > 140 else ""),
                 "signal_ids": [e["signal_id"] for e in events if e["message_index"] == m.index],
                 "max_weight": max([e["weight"] for e in events if e["message_index"] == m.index], default=0)} for m in messages]
    facts = [f"{len(messages)} message(s) were analysed.", f"{len(scored)} pattern(s) matched across {len(cats)} categor{'y' if len(cats) == 1 else 'ies'}."]
    if ai_attempts:
        facts.append("Some text addressed an AI system. It was treated as ordinary text and not followed.")
    return {
        "engine": ENGINE, "engine_description": "Transparent pattern rules. Not an AI model and not a fraud verdict.",
        "level": level, "score": score, "ordering_note": ordering_note, "timeline": timeline, "signals": events,
        "sequence_notes": _sequence_notes(scored),
        "facts": facts,
        "indicators": [f"{e['title']} (message {e['message_index'] + 1})" for e in scored],
        "assumptions": ["The pasted messages are complete and in the real order.", "Day/month order in timestamps is assumed to be DD/MM.",
                        "Only English and a few Hindi words in Latin script are recognised."],
        "unknowns": ["Whether the sender is who they claim to be.", "Whether you applied to this organisation yourself.",
                     "Whether the payment account, links or phone numbers are genuine (none were opened or checked)."],
        "alternative_explanations": sorted({e["possible_harmless_explanation"] for e in scored}),
        "next_steps": next_steps(level, cats, secret),
        "limits": ["Patterns can match genuine messages and can miss scams worded differently.",
                   "No message was sent and no link was opened. Nothing was done on your behalf."],
    }


def next_steps(level: str, cats: set[str], secret: bool) -> list[str]:
    steps = []
    if secret:
        steps.append("Do not share any OTP, PIN, CVV, password or recovery code with anyone who contacted you.")
    if "PAYMENT_REQUEST" in cats:
        steps.append("Do not pay yet. Confirm the organisation through contact details you find yourself (official website typed in, college placement cell), not the ones in the message.")
        steps.append("Ask the organisation to confirm in writing why a payment is needed and to whom. Genuine organisations can answer this calmly.")
    if "CHANNEL_SHIFT" in cats:
        steps.append("Prefer communicating through the official platform or official email rather than a private chat.")
    if level != "NOT_ENOUGH_SIGNALS":
        steps.append("Show the messages to a trusted adult, teacher or your college placement cell before deciding.")
        steps.append("Keep screenshots of the conversation. If money or data was already sent, use the Recovery Navigator.")
    if not steps:
        steps.append("Few warning patterns were found, which does not prove safety. Still verify who is contacting you before sharing money or personal data.")
    return steps
