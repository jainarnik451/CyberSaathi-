"""Exposure Map: which kinds of personal data does a message ask for?

Detects REQUESTS (a verb asking for the item), not mere mentions. Never asks the user to enter any
sensitive value: the input is the same pasted text, analysed in memory.
"""
import re
from app.analysis.text import Message
from app.analysis.journey import evidence_snippet

SENSITIVITY = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
_ASK = r"(?:send|share|provide|give|submit|upload|enter|fill|tell|forward|mail|email|whatsapp|need|require|required|send\s+us|attach|confirm|verify|update)"
_GAP = r".{0,50}?"


def _c(items):
    return tuple(re.compile(p, re.I | re.S) for p in items)


CATEGORIES = {
    "SECRET_CODES": dict(label="Secret codes (OTP, PIN, password)", sensitivity="CRITICAL",
        patterns=_c([rf"\b{_ASK}\b{_GAP}\b(?:otp|one[- ]time\s+(?:password|code)|pin|cvv|password|passcode|recovery\s+code|verification\s+code|security\s+code)\b"]),
        risk="Anyone with these can approve payments or take over your accounts. They are designed to be known only to you.",
        safer="Never share them with anyone who contacted you, however official they sound. If it is a real request, hang up and use the official app yourself."),
    "FINANCIAL": dict(label="Financial information", sensitivity="HIGH",
        patterns=_c([rf"\b{_ASK}\b{_GAP}\b(?:bank\s+account|account\s+number|card\s+(?:number|details)|credit\s+card|debit\s+card|ifsc|upi\s+(?:id|pin)|net\s*banking|expiry\s+date)\b",
                     r"\b(?:pay|send|transfer)\b.{0,30}\b(?:fee|amount|deposit)\b"]),
        risk="Can be used to take money directly, or to set up payments you did not intend.",
        safer="Pay only through the official website or app you opened yourself, for a charge you can verify. Never send card or bank details by chat."),
    "IDENTITY": dict(label="Identity information", sensitivity="HIGH",
        patterns=_c([rf"\b{_ASK}\b{_GAP}\b(?:aadhaar|aadhar|pan\s*(?:card|number)?|passport|voter\s+id|driving\s+licen[sc]e|date\s+of\s+birth|dob|id\s+(?:proof|card)|marksheet|certificates?)\b"]),
        risk="Identity documents can be used for SIM, loan or account fraud and are hard to change once exposed.",
        safer="Share only the minimum, only with organisations you have verified, and only through their official portal. If a copy must be shared, add a note such as 'for X application only, dated today'."),
    "ACCOUNT": dict(label="Account access information", sensitivity="HIGH",
        patterns=_c([rf"\b{_ASK}\b{_GAP}\b(?:login|log[- ]in|username|user\s*id|account\s+(?:id|details)|credentials|email\s+password|screen\s*share|remote\s+access)\b",
                     r"\b(?:install|download)\b.{0,30}\b(?:anydesk|teamviewer|quicksupport|apk)\b"]),
        risk="Gives a stranger access to your accounts, messages and contacts, who can then target your friends and family.",
        safer="Never give login details or install remote-access apps for someone who contacted you. Sign in only on the official site or app that you opened yourself."),
    "PHOTOS": dict(label="Photographs", sensitivity="MEDIUM",
        patterns=_c([rf"\b{_ASK}\b{_GAP}\b(?:photos?|photographs?|selfies?|pictures?|passport[- ]size|face\s+(?:scan|photo)|video\s+call)\b"]),
        risk="Photos can be reused for fake profiles, or in blackmail. Images of documents expose everything printed on them.",
        safer="Avoid sending personal photos to unverified contacts. For genuine applications, upload through the official portal."),
    "ADDRESS": dict(label="Home or location details", sensitivity="MEDIUM",
        patterns=_c([rf"\b{_ASK}\b{_GAP}\b(?:home\s+address|address|location|pin\s*code|residence|parents'?\s+(?:names?|details|number))\b"]),
        risk="Reveals where you and your family can be found, and helps build convincing impersonation.",
        safer="Give only the city or the part of the address strictly required, and only after you have verified the organisation."),
    "PHONE_EMAIL": dict(label="Phone or email", sensitivity="LOW",
        patterns=_c([rf"\b{_ASK}\b{_GAP}\b(?:phone|mobile|contact)\s+(?:number|no\.?|details)\b", rf"\b{_ASK}\b{_GAP}\b(?:e-?mail\s+(?:id|address))\b",
                     r"\b(?:whatsapp)\s+number\b"]),
        risk="Used for follow-up scam calls and messages, and to impersonate you or contact your friends.",
        safer="Prefer to share a dedicated email address. Share a phone number only with verified organisations."),
}


def analyze_exposure(messages: list[Message]) -> dict:
    found = []
    for key, spec in CATEGORIES.items():
        evidence = []
        for m in messages:
            for pattern in spec["patterns"]:
                match = pattern.search(m.text)
                if match:
                    quote, ctx = evidence_snippet(m.text, match.start(), match.end())
                    evidence.append({"message_index": m.index, "sender": m.sender, "evidence_quote": quote, "evidence_context": ctx})
                    break
        if evidence:
            found.append({"category": key, "label": spec["label"], "sensitivity": spec["sensitivity"], "why_it_matters": spec["risk"],
                          "safer_alternative": spec["safer"], "evidence": evidence})
    found.sort(key=lambda c: -SENSITIVITY[c["sensitivity"]])
    top = found[0]["sensitivity"] if found else None
    return {
        "categories": found, "highest_sensitivity": top,
        "summary": ("No requests for personal data were detected by the pattern rules." if not found else
                    f"The messages ask for {len(found)} kind(s) of personal data. The most sensitive is: {found[0]['label']}."),
        "limits": ["Only direct requests in English (and a few Hindi words) are detected. A message that asks in other words or languages can be missed.",
                   "Asking for data is not proof of fraud: genuine applications also ask for some of it. What matters is whether you verified who is asking."],
        "do_not_enter": "CyberSaathi never needs your passwords, OTPs, PINs, recovery codes or bank credentials. Do not type them anywhere on this site.",
    }
