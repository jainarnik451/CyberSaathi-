"""Catalogue of pattern-based indicators. Data, not logic: add or tune entries here.

Every entry says WHY the pattern matters and what a harmless explanation could be, because a pattern is
evidence to weigh, not proof. Coverage: English plus a few common Hindi words in Latin script. Wording in
other languages or scripts is NOT detected (a stated limitation).
"""
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Signal:
    id: str
    category: str
    title: str
    weight: int           # 0 = reported as a notice only, never scored
    patterns: tuple[re.Pattern, ...]
    why: str
    harmless: str


def _s(id_, category, title, weight, patterns, why, harmless) -> Signal:
    return Signal(id_, category, title, weight, tuple(re.compile(p, re.I | re.S) for p in patterns), why, harmless)


CATEGORY_LABELS = {
    "URGENCY": "Urgency", "PAYMENT_REQUEST": "Payment request", "UNUSUAL_PROMISE": "Unusual promise",
    "UNSOLICITED_OFFER": "Unexpected offer", "PRESSURE_TACTICS": "Pressure", "CHANNEL_SHIFT": "Move to private chat",
    "AUTHORITY_CLAIM": "Claim of authority", "SUPPORT_IMPERSONATION": "Support or KYC pretext",
    "SUSPICIOUS_LINK": "Link prompt", "CREDENTIAL_REQUEST": "Request for secret codes",
    "PERSONAL_INFO_REQUEST": "Request for personal information", "AI_INSTRUCTION_ATTEMPT": "Instruction to an AI system",
}

AI_INSTRUCTION = "AI_INSTRUCTION_ATTEMPT"

SIGNALS: tuple[Signal, ...] = (
    _s("urgency.deadline", "URGENCY", "Tight deadline", 2,
       [r"\b(?:within|in)\s+(?:the\s+next\s+)?\d{1,2}\s*(?:hours?|hrs?|minutes?|mins?)\b", r"\b(?:today|tonight)\s+(?:only|itself)\b",
        r"\bby\s+(?:today|tonight|end\s+of\s+(?:the\s+)?day)\b", r"\boffer\s+(?:expires|ends|is\s+valid)\b",
        r"\blast\s+(?:chance|date|day)\b", r"\b(?:jaldi|turant)\b"],
       "Scammers set short deadlines so you act before you can check, ask someone or think.",
       "Real offers also have deadlines, for example an admission or application date. The concern is a deadline combined with a payment or personal-data request."),
    _s("urgency.immediate", "URGENCY", "Demand to act immediately", 2,
       [r"\b(?:immediately|right\s+now|at\s+once|asap|urgent(?:ly)?|hurry)\b", r"\bact\s+now\b"],
       "Pressure to act 'now' removes the time you need to verify who you are dealing with.",
       "People write 'urgent' casually. It matters more when it comes with a request for money or data."),
    _s("urgency.scarcity", "URGENCY", "Limited seats or slots", 1,
       [r"\b(?:only|just)\s+\d+\s+(?:seats?|slots?|positions?|vacancies)\s+(?:left|remaining)\b", r"\bslots?\s+(?:are\s+)?(?:filling|full)\b"],
       "Artificial scarcity makes people pay before checking.",
       "Some programmes do have genuinely limited places."),
    _s("payment.fee", "PAYMENT_REQUEST", "Fee or deposit requested", 3,
       [r"\b(?:registration|processing|joining|security|refundable|training|kit|verification|admin|application|onboarding|confirmation)\s+(?:fee|fees|charge|charges|deposit|amount)\b",
        r"\bpay\s+(?:a\s+|the\s+)?(?:small\s+)?(?:fee|amount|deposit)\b"],
       "A request for money from someone you have not verified, especially after an unexpected 'selection', is one of the most common scam patterns.",
       "Some genuine paid courses, exams and programmes do charge fees. What matters is whether the organisation and the payment account are independently verified."),
    _s("payment.transfer", "PAYMENT_REQUEST", "Request to send money", 3,
       [r"\b(?:pay|send|transfer|deposit|remit)\s+(?:(?:rs\.?|inr|₹)\s?\d[\d,]*|\d[\d,]*\s?(?:rs\.?|inr|rupees)|the\s+money|money)\b",
        r"(?:₹|rs\.?|inr)\s?\d[\d,]*\s*(?:/-)?\s*(?:only|to|via|through)\b",
        r"\b(?:gpay|google\s*pay|phonepe|paytm|upi|bhim)\b.{0,40}\b(?:pay|send|transfer)\b",
        r"\b(?:pay|send|transfer)\b.{0,40}\b(?:gpay|google\s*pay|phonepe|paytm|upi|bhim)\b"],
       "Payment requests to personal accounts or wallets are hard to reverse once made.",
       "Paying someone you know and trust is normal. The concern is paying someone unverified."),
    _s("payment.qr", "PAYMENT_REQUEST", "QR code or collect-request payment", 3,
       [r"\bscan\s+(?:this|the|my|our)\s+qr\b", r"\bqr\s*code\b.{0,40}\b(?:scan|pay|receive)\b",
        r"\b(?:approve|accept|authori[sz]e)\s+(?:the\s+)?(?:payment\s+)?(?:request|collect\s+request)\b"],
       "You never need to scan a QR code or approve a request in order to RECEIVE money. These actions send money out.",
       "A shop may legitimately ask you to scan its QR code to pay for something you chose to buy."),
    _s("promise.guaranteed", "UNUSUAL_PROMISE", "Guaranteed outcome", 2,
       [r"\bguarantee[sd]?\b", r"\b100\s*%\s*(?:placement|job|selection|refund|safe|genuine)\b",
        r"\bno\s+(?:interview|test|experience)\s+(?:needed|required)\b", r"\bselected\s+without\b"],
       "Genuine jobs, scholarships and programmes rarely guarantee results, especially with no interview, test or experience.",
       "Marketing language can be exaggerated without any bad intent."),
    _s("promise.easy_money", "UNUSUAL_PROMISE", "High or easy earnings promise", 2,
       [r"\bearn\s+(?:up\s+to\s+)?(?:₹|rs\.?|inr)?\s?\d[\d,]*\s*(?:per|a|/)\s*(?:day|week|hour)\b", r"\beasy\s+money\b",
        r"\bwork\s+from\s+home\b.{0,60}\b(?:₹|rs\.?|inr)\s?\d{4,}\b", r"\bdouble\s+your\s+money\b"],
       "Offers of large, fast or effortless income are a common lure.",
       "Some commission or gig roles do advertise earnings, which should be checked against the terms."),
    _s("offer.unsolicited", "UNSOLICITED_OFFER", "Selection or prize announced", 1,
       [r"\byou\s+(?:have\s+been|are|were)\s+(?:selected|shortlisted|chosen|awarded|picked)\b", r"\bcongratulations\b",
        r"\b(?:lottery|lucky\s+draw)\b.{0,40}\b(?:won|winner|selected)\b", r"\bscholarship\b.{0,40}\b(?:awarded|approved|sanctioned)\b"],
       "An unexpected reward builds excitement and trust before a request is made. Check whether you actually applied.",
       "If you did apply to this organisation, a selection message is expected."),
    _s("pressure.secrecy", "PRESSURE_TACTICS", "Request for secrecy", 3,
       [r"\b(?:don'?t|do\s+not|never)\s+(?:tell|inform|share\s+this\s+with|discuss\s+this\s+with)\s+(?:anyone|anybody|your\s+(?:parents|family|friends))\b",
        r"\bkeep\s+(?:this|it)\s+(?:confidential|secret|private)\b"],
       "Scammers isolate people from anyone who might spot the scam. Genuine organisations do not mind you asking family or your college.",
       "Some confidential processes exist, such as exam papers, but they do not involve secret payments."),
    _s("pressure.threat", "PRESSURE_TACTICS", "Threat of loss or consequences", 3,
       [r"\b(?:will\s+be|get)\s+(?:cancelled|blocked|suspended|forfeited|rejected|arrested)\b", r"\blegal\s+action\b",
        r"\b(?:final|last)\s+warning\b", r"\byou\s+will\s+lose\b", r"\b(?:fir|case)\s+(?:will\s+be\s+)?(?:filed|registered)\b"],
       "Threats create fear so you comply instead of checking.",
       "Genuine bodies also send warnings about real deadlines. Verify by contacting them through channels you find yourself."),
    _s("pressure.social", "PRESSURE_TACTICS", "Pressure by comparison", 1,
       [r"\beveryone\s+else\s+has\s+(?:already\s+)?(?:paid|joined|confirmed)\b", r"\bdon'?t\s+(?:waste|miss)\s+(?:this|the)\s+(?:opportunity|chance)\b"],
       "Making you feel left behind pushes quick decisions.", "Ordinary sales language can sound like this."),
    _s("channel.shift", "CHANNEL_SHIFT", "Move to a private chat app", 2,
       [r"\b(?:contact|message|text|chat|reach|add)\s+(?:me|us)\s+(?:on|at|via)\s+(?:whatsapp|telegram|signal)\b",
        r"\b(?:join|move\s+to|continue\s+on|switch\s+to)\s+(?:our\s+|the\s+)?(?:whatsapp|telegram)\b", r"\bt\.me/\S+"],
       "Moving off an official platform removes records and protections and makes impersonation easier.",
       "Many genuine recruiters and teachers use WhatsApp for convenience."),
    _s("authority.claim", "AUTHORITY_CLAIM", "Claim to be an official authority", 2,
       [r"\b(?:cbi|ncb|rbi|customs|income\s+tax|cyber\s*crime|police|court|trai|sebi)\s+(?:officer|department|office|team|branch)\b",
        r"\bdigital\s+arrest\b", r"\byou\s+are\s+under\s+(?:investigation|arrest)\b"],
       "Impersonating police or regulators is used to frighten people into paying. Real agencies do not demand money by chat or call, and there is no such thing as a 'digital arrest'.",
       "Real officials do contact people, but through official letters or verified numbers you can look up yourself."),
    _s("support.remote", "SUPPORT_IMPERSONATION", "Remote access or support/KYC pretext", 3,
       [r"\b(?:anydesk|teamviewer|quicksupport|ammyy|rustdesk)\b",
        r"\bcustomer\s+(?:care|support|service)\b.{0,60}\b(?:refund|kyc|blocked|update)\b", r"\b(?:update|complete|verify)\s+(?:your\s+)?kyc\b"],
       "Remote-access apps give a stranger full control of your device and bank apps. Fake support and KYC messages are common entry points.",
       "Genuine support teams sometimes use screen-sharing, but only when YOU contacted them through their official app or site."),
    _s("link.prompt", "SUSPICIOUS_LINK", "Prompt to open a link", 1,
       [r"\b(?:click|tap|open|visit)\s+(?:this|the|below)?\s*(?:link|url)\b", r"\bbit\.ly/\S+|\btinyurl\.com/\S+"],
       "Links can lead to look-alike sites. CyberSaathi does NOT open or check links here.",
       "Links in genuine messages are common. Type the organisation's address yourself instead of tapping."),
    _s("secret.codes", "CREDENTIAL_REQUEST", "Request for an OTP, PIN, password or recovery code", 4,
       [r"\b(?:send|share|tell|give|provide|enter|forward|read\s+out)\b.{0,40}\b(?:otp|one[- ]time\s+(?:password|code)|pin|cvv|password|passcode|recovery\s+code|verification\s+code|security\s+code)\b",
        r"\b(?:otp|cvv|pin)\b.{0,30}\b(?:send|share|tell|give|provide)\b"],
       "These codes exist so that ONLY you can approve something. Nobody genuine, including banks, platforms and CyberSaathi, will ask you to share them.",
       "There is almost no harmless reason for someone else to ask for these. Entering your own code on an official app you opened yourself is different."),
    _s("meta.ai_instruction", AI_INSTRUCTION, "Text that tries to instruct an AI system", 0,
       [r"ignore\s+(?:all\s+|any\s+)?(?:previous|prior|above)\s+(?:instructions|rules|messages)", r"disregard\s+(?:the\s+)?(?:above|previous|system)",
        r"\bsystem\s+prompt\b", r"\byou\s+are\s+now\s+(?:a|an|in)\b", r"reveal\s+(?:your|the)\s+(?:instructions|prompt|api\s*key|secret)",
        r"mark\s+(?:this|it|me)\s+as\s+(?:safe|genuine|legit(?:imate)?|verified)", r"\bas\s+an\s+ai\b.{0,40}\b(?:say|state|confirm|mark)\b"],
       "This text looks like an instruction aimed at an AI tool rather than at you. CyberSaathi treats everything you paste as data and did not follow it.",
       "It could be a quoted example, a test, or text copied from elsewhere."),
)

SIGNAL_BY_ID = {s.id: s for s in SIGNALS}
CONTEXT_CHARS = 60


@dataclass(frozen=True)
class Hit:
    signal: Signal
    start: int
    end: int


def find_hits(text: str) -> list[Hit]:
    """First match of each signal in one cleaned message (offsets index into `text`)."""
    hits = []
    for signal in SIGNALS:
        for pattern in signal.patterns:
            m = pattern.search(text)
            if m:
                hits.append(Hit(signal, m.start(), m.end()))
                break
    return hits
