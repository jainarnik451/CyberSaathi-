"""Validator for ANY model-produced analysis (none ships yet). Model output is untrusted data.

Rules: exact schema (unknown fields rejected), enumerated values only, bounded sizes, and every quoted
evidence string must appear verbatim in the user's own text. Nothing returned is ever executed or queried.
"""
from app.analysis.journey import LEVELS
from app.analysis.signals import CATEGORY_LABELS
from app.analysis.text import clean_text

ALLOWED_TOP = {"level", "summary", "signals", "unknowns", "alternative_explanations"}
ALLOWED_SIGNAL = {"category", "explanation", "evidence_quote", "message_index"}
MAX_SIGNALS, MAX_STR = 30, 600


class GroundingError(ValueError):
    pass


def _str(value, name, limit=MAX_STR):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise GroundingError(f"{name} must be a non-empty string of at most {limit} characters")
    return value.strip()


def validate_model_output(output: object, messages: list[str]) -> dict:
    """Return a cleaned copy or raise GroundingError. `messages` are the cleaned user messages."""
    if not isinstance(output, dict):
        raise GroundingError("output must be an object")
    extra = set(output) - ALLOWED_TOP
    if extra:
        raise GroundingError(f"unexpected fields: {sorted(extra)}")
    if output.get("level") not in LEVELS:
        raise GroundingError("level is not an allowed value")
    cleaned = {"level": output["level"], "summary": _str(output.get("summary"), "summary", 1200), "signals": []}
    signals = output.get("signals")
    if not isinstance(signals, list) or len(signals) > MAX_SIGNALS:
        raise GroundingError("signals must be a list of at most %d items" % MAX_SIGNALS)
    for s in signals:
        if not isinstance(s, dict) or set(s) - ALLOWED_SIGNAL or not {"category", "explanation", "evidence_quote", "message_index"} <= set(s):
            raise GroundingError("each signal needs exactly: category, explanation, evidence_quote, message_index")
        if s["category"] not in CATEGORY_LABELS:
            raise GroundingError("signal category is not allowed")
        idx = s["message_index"]
        if not isinstance(idx, int) or isinstance(idx, bool) or not 0 <= idx < len(messages):
            raise GroundingError("message_index is out of range")
        quote = clean_text(_str(s["evidence_quote"], "evidence_quote", 300))
        if quote.lower() not in messages[idx].lower():
            raise GroundingError("evidence quote does not appear in the cited message")  # invented evidence
        cleaned["signals"].append({"category": s["category"], "explanation": _str(s["explanation"], "explanation"),
                                   "evidence_quote": quote, "message_index": idx})
    for key in ("unknowns", "alternative_explanations"):
        items = output.get(key, [])
        if not isinstance(items, list) or len(items) > 20:
            raise GroundingError(f"{key} must be a short list")
        cleaned[key] = [_str(i, key) for i in items]
    if cleaned["level"] == "STRONG_CONCERNS" and not cleaned["signals"]:
        raise GroundingError("strong concerns need at least one evidenced signal")
    return cleaned
