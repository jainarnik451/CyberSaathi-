"""Recovery Navigator: guided checklists. CyberSaathi cannot reverse payments or recover accounts, and says so.

Official reporting details live in COUNTRY_INFO with the date and source of the last check. Update the
entry (and `verified_on`) whenever someone re-checks the official sources. Countries without an entry get
NO invented numbers, only generic advice.
"""
SITUATIONS = ("SHARED_INFORMATION", "COMPROMISED_ACCOUNT", "FRAUDULENT_PAYMENT", "SUSPICIOUS_OFFER")
CANNOT_DO = ("CyberSaathi cannot reverse a payment, recover an account, block a number or contact anyone for you. "
             "These steps tell you who can help and what to prepare.")

COUNTRY_INFO = {
    "IN": {
        "country": "India",
        "verified_on": "2026-11-04",
        "verification_note": ("Checked from a Kerala Police public notice (undated) that names helpline 1930 as available 24 hours a day and the "
                              "national portal below. The official portal itself could not be opened when this was written, so please confirm "
                              "the details on the official site before relying on them."),
        "contacts": [
            {"name": "National Cyber Crime Reporting Portal", "type": "website", "value": "https://cybercrime.gov.in",
             "use": "Report cyber crimes, including online financial fraud."},
            {"name": "National Cyber Crime Helpline", "type": "phone", "value": "1930",
             "use": "Report online financial fraud quickly. Call as soon as possible after a payment fraud."},
        ],
        "urgent_tip": "For a fraudulent payment, speed matters. Call 1930 and your bank right away, then file the report on the portal.",
    },
}
GENERIC_COUNTRY = {
    "country": "your country", "verified_on": None,
    "verification_note": "CyberSaathi has no checked reporting details for this country, so none are shown rather than guessing.",
    "contacts": [],
    "urgent_tip": "Search your own government's official website for its cybercrime or fraud reporting service, and call your bank using the number on your card.",
}

_STEPS = {
    "SHARED_INFORMATION": {
        "immediate": ["Stop replying to the person. Do not send anything more, and do not click links they sent.",
                      "Write down exactly what you shared (for example phone number, ID photo, a code)."],
        "accounts": ["If you shared a password, change it now on the official site or app, and on any other account that used the same password.",
                     "If you shared an OTP or PIN, call your bank immediately using the number on your card or in the official app, and say a code was shared.",
                     "Turn on two-step verification on important accounts, preferably with an authenticator app rather than SMS."],
        "evidence": ["Take screenshots of the chat, the sender's number or profile, and any links (do not open them again).", "Do not delete the conversation yet."],
        "contact": ["Bank: if any financial detail or code was shared.", "Platform (WhatsApp, Instagram, email provider): to report and block the sender.",
                    "A trusted adult, teacher or your college: to review what happened. You did nothing wrong by asking for help."],
    },
    "COMPROMISED_ACCOUNT": {
        "immediate": ["From a device you trust, go to the official site or app (typed or opened yourself) and try to sign in and change the password.",
                      "If you are locked out, use that service's official account-recovery page. CyberSaathi cannot recover accounts for you."],
        "accounts": ["Sign out all other sessions and remove devices or apps you do not recognise.", "Check recovery email and phone number are still yours.",
                     "Change the password of your email account first, since it can reset your other accounts.", "Turn on two-step verification."],
        "evidence": ["Screenshot login-alert emails, unexpected messages sent from your account, and changed settings.", "Note the date and time you first noticed the problem."],
        "contact": ["The platform's official support or hacked-account form.", "Friends and family: warn them not to trust messages from you until you recover the account.",
                    "Bank: if the account was linked to payments."],
    },
    "FRAUDULENT_PAYMENT": {
        "immediate": ["Contact your bank or payment app right away, using the number on your card or in the official app, and say you were defrauded.",
                      "Ask the bank whether the payment can be disputed or the receiving account frozen. They decide this, not CyberSaathi.",
                      "Do not send more money, even to 'recover' the lost amount. That is a common second scam."],
        "accounts": ["Change passwords and PINs on the accounts involved.", "Remove any remote-access app the scammer asked you to install, and consider a device security scan."],
        "evidence": ["Keep the transaction ID, date, amount, receiving account or UPI ID, and the bank's complaint number.", "Screenshot the whole conversation, the sender's number and any website or QR code used."],
        "contact": ["Bank or payment app: immediately.", "Official cybercrime reporting service for your country (see below).",
                    "Police, if your country's process asks for it, and a trusted adult to help you through it."],
    },
    "SUSPICIOUS_OFFER": {
        "immediate": ["Do not pay or share documents until the organisation is verified through sources you find yourself.",
                      "Do not stop the conversation abruptly if you want to keep evidence. You can stop replying once you have saved it."],
        "accounts": ["If you already created an account on their site, do not reuse that password anywhere else and change it where you did.",
                     "If you shared ID documents, keep a note of which ones and watch for unexpected SIM, loan or account activity."],
        "evidence": ["Save the offer letter, emails (with full headers if you can), chat screenshots, payment details they gave and the website address."],
        "contact": ["Your college placement cell or scholarship office: ask if they know the organisation.", "The platform where you found the offer: report the listing.",
                    "A trusted adult before paying anything.", "Bank: only if you already paid."],
    },
}
SECTION_TITLES = {"immediate": "Do these first", "accounts": "Secure your accounts", "evidence": "Keep evidence", "contact": "Who to contact and when"}


def get_checklist(situation: str, country: str | None = None) -> dict:
    if situation not in SITUATIONS:
        raise ValueError("unknown situation")
    info = COUNTRY_INFO.get((country or "").upper(), GENERIC_COUNTRY)
    steps = _STEPS[situation]
    return {"situation": situation, "cannot_do": CANNOT_DO,
            "sections": [{"key": k, "title": SECTION_TITLES[k], "steps": steps[k]} for k in ("immediate", "accounts", "evidence", "contact")],
            "reporting": info, "supported_countries": sorted(COUNTRY_INFO)}
