"""SafeChoice Simulator: fictional scenarios, harmless by design.

All organisations, people, numbers and links below are INVENTED. The simulator never sends anything,
never asks for real credentials, and never contains live links. Content is data so it can be reviewed.
"""
from dataclasses import dataclass

RATINGS = ("BEST", "OKAY", "RISKY")


@dataclass(frozen=True)
class Choice:
    id: str
    text: str
    rating: str
    risk: str


@dataclass(frozen=True)
class Scenario:
    id: str
    title: str
    topic: str
    situation: tuple[str, ...]
    choices: tuple[Choice, ...]
    lesson: str
    recommendation: str


def _sc(id_, title, topic, situation, choices, lesson, rec):
    return Scenario(id_, title, topic, tuple(situation), tuple(Choice(*c) for c in choices), lesson, rec)


SCENARIOS: tuple[Scenario, ...] = (
    _sc("internship-fee", "The internship that asks for a fee", "FAKE_INTERNSHIP",
        ["(Fictional) You applied to nothing recently, but 'Example Tech Labs' messages: 'Congratulations, you are selected for our internship! Pay a Rs 1,500 registration fee within 2 hours to confirm your seat.'"],
        [("a", "Pay quickly so you do not lose the seat.", "RISKY", "Money sent to an unverified account is very hard to get back, and paying shows you will comply with pressure, so more requests usually follow."),
         ("b", "Reply asking for the fee receipt format, then pay half.", "RISKY", "Negotiating still engages with an unverified request, and part payment is still lost money."),
         ("c", "Do not pay. Look up the company's official website yourself and ask your college placement cell whether they know it.", "BEST", "Takes a little time but uses sources the sender does not control. A genuine offer will survive a day's checking."),
         ("d", "Ignore it and delete the chat without telling anyone.", "OKAY", "Safe for you, but keeping the messages and telling someone helps friends who may get the same message.")],
        "An unexpected selection followed by a fee and a short deadline is a classic sequence. Pressure is the signal, not the fee alone.",
        "Do not pay under time pressure. Verify the organisation through channels you find yourself."),
    _sc("scholarship-processing", "The scholarship with a processing charge", "SCHOLARSHIP_PAYMENT",
        ["(Fictional) A message says: 'Your Merit Scholarship of Rs 50,000 is approved by Example Foundation. Send Rs 999 processing charge to release the amount today.'"],
        [("a", "Pay the small charge. It is tiny compared to Rs 50,000.", "RISKY", "A low fee lowers your guard. Genuine scholarships pay out to you; they do not ask you to pay first."),
         ("b", "Ask for an official letter and apply only through the foundation's website that you find yourself.", "BEST", "Moves the interaction to a source you can verify and tests whether the sender can offer anything official."),
         ("c", "Share your bank details so they can 'deposit' the scholarship instead.", "RISKY", "Bank details can be misused, and the 'deposit' is a common first step in taking money out."),
         ("d", "Ask a teacher or your scholarship office whether this scholarship exists.", "BEST", "A human who knows the real process is one of the best checks.")],
        "Real scholarships do not ask you to pay to receive money. 'Small' fees work because they feel safe.",
        "Never pay to receive a scholarship. Check with the awarding body using details you find yourself."),
    _sc("qr-refund", "The QR code that 'receives' money", "SUSPICIOUS_QR",
        ["(Fictional) You listed a used book for sale. A buyer says: 'I will pay you now. Scan this QR code I am sending to receive the payment.'"],
        [("a", "Scan the QR code and enter your UPI PIN to receive the money.", "RISKY", "You never need a PIN or a scan to RECEIVE money. Entering your PIN approves a payment OUT of your account."),
         ("b", "Tell the buyer you will only accept the payment shown in your own bank app, and to send it to your UPI ID.", "BEST", "Receiving money only needs your ID. If they truly want to pay, that works; if they refuse, you learn something."),
         ("c", "Approve the 'collect request' that appeared, just to see what happens.", "RISKY", "Approving a collect request sends money. Curiosity can cost real money."),
         ("d", "Stop replying and block the buyer.", "OKAY", "Safe, though reporting the listing helps protect others.")],
        "Scanning and PIN entry are for PAYING. If someone asks you to do either to be paid, it is a trick.",
        "Never scan or enter a PIN to receive money. Give only your payment address and check your own app."),
    _sc("college-impersonation", "The 'college office' on a personal number", "INSTITUTION_IMPERSONATION",
        ["(Fictional) A WhatsApp message from an unknown number: 'This is the Accounts Office of Example Institute. Your exam fee is pending. Pay Rs 3,000 to this personal UPI ID by 6 pm or your hall ticket will be blocked.'"],
        [("a", "Pay immediately so the hall ticket is not blocked.", "RISKY", "Payments to a personal ID are not college payments. The threat and the deadline are the pressure."),
         ("b", "Check your fee status on the official student portal or at the office in person, using contacts from the college's own website or notice board.", "BEST", "Confirms the facts from a source the sender cannot fake."),
         ("c", "Call back the number in the message to ask.", "RISKY", "You would be speaking to the sender. Use contact details you find yourself."),
         ("d", "Ask classmates whether they got the same message, and tell the real office.", "BEST", "Quick, human, and it alerts the college so it can warn others.")],
        "Institutions usually use official portals and receipts. A deadline and a personal payment ID are warning signs.",
        "Confirm fees only through the college's official portal or office, never via numbers in the message."),
    _sc("fake-support", "The 'customer care' that needs remote access", "FAKE_SUPPORT",
        ["(Fictional) You search online for an app's helpline and call the first number. The agent says: 'To process your refund, install a screen-sharing app and tell me the code it shows.'"],
        [("a", "Install the app and read out the code. They need it for the refund.", "RISKY", "A screen-sharing code gives them control of your device, including your banking apps."),
         ("b", "Hang up. Find the support option inside the real app or on the official website you typed yourself.", "BEST", "Search-result numbers can be planted by scammers. Official in-app support is safer."),
         ("c", "Install it but promise yourself you will not open your banking app.", "RISKY", "They can see notifications and OTPs and can guide you into mistakes. Do not install it."),
         ("d", "Ask a family member to check with you before doing anything.", "BEST", "A second person breaks the pressure and often spots the trick.")],
        "A refund never requires you to give someone control of your device.",
        "Do not install remote-access apps for someone who contacted you or whom you found by search."),
    _sc("otp-request", "The caller who needs your OTP", "OTP_REQUEST",
        ["(Fictional) A caller says he is from 'Example Bank' and that your account will be blocked today. 'You will get an OTP. Please read it out so we can stop the block.'"],
        [("a", "Read out the OTP. It will stop the block.", "RISKY", "The OTP is the key that approves a transaction. Reading it out lets them move your money."),
         ("b", "Say you will check, hang up, and call the number printed on your bank card or in the official app.", "BEST", "Uses a number you trust. Genuine banks never need you to read out an OTP."),
         ("c", "Give only the first three digits to be careful.", "RISKY", "Partial codes can still help them, and it shows you will cooperate."),
         ("d", "Keep the caller talking to see what else they ask.", "OKAY", "May be educational but risky. A wrong moment of trust could cost you. Hanging up is safer.")],
        "No genuine organisation needs you to tell them an OTP, PIN, CVV or password.",
        "Never share an OTP with anyone. End the call and contact the bank through its official channel."),
)
SCENARIO_BY_ID = {s.id: s for s in SCENARIOS}
_BEST = {s.id: {c.id for c in s.choices if c.rating == "BEST"} for s in SCENARIOS}


def list_scenarios() -> list[dict]:
    """Safe listing: no answers or ratings are revealed."""
    return [{"id": s.id, "title": s.title, "topic": s.topic} for s in SCENARIOS]


def get_scenario(scenario_id: str) -> dict | None:
    s = SCENARIO_BY_ID.get(scenario_id)
    if not s:
        return None
    return {"id": s.id, "title": s.title, "topic": s.topic, "situation": list(s.situation),
            "choices": [{"id": c.id, "text": c.text} for c in s.choices],  # ratings withheld until answered
            "fictional_notice": "Everything in this scenario is invented for practice. Nothing here is sent anywhere."}


def evaluate_choice(scenario_id: str, choice_id: str) -> dict | None:
    s = SCENARIO_BY_ID.get(scenario_id)
    chosen = next((c for c in s.choices if c.id == choice_id), None) if s else None
    if not chosen:
        return None
    return {"scenario_id": s.id, "choice_id": chosen.id, "rating": chosen.rating, "was_best": chosen.rating == "BEST",
            "risk_of_this_choice": chosen.risk, "all_choices": [{"id": c.id, "text": c.text, "rating": c.rating, "risk": c.risk} for c in s.choices],
            "recommendation": s.recommendation, "lesson": s.lesson}


def summarize_progress(attempts: list[dict]) -> dict:
    """attempts: [{'scenario_id','rating'}] oldest first. Counts only what the user really did."""
    total = len(SCENARIOS)
    first = {}
    best_ids = set()
    for a in attempts:
        sid = a.get("scenario_id")
        if sid not in SCENARIO_BY_ID:
            continue
        first.setdefault(sid, a.get("rating"))
        if a.get("rating") == "BEST":
            best_ids.add(sid)
    return {"scenarios_total": total, "scenarios_attempted": len(first), "scenarios_mastered": len(best_ids),
            "best_on_first_try": sum(r == "BEST" for r in first.values()), "attempts": sum(1 for a in attempts if a.get("scenario_id") in SCENARIO_BY_ID),
            "remaining": [s.id for s in SCENARIOS if s.id not in best_ids], "empty": not first}
