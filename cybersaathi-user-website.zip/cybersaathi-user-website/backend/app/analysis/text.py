"""Input handling for pasted conversations: cleaning, parsing, limits, ordering.

All text from users is untrusted DATA. Nothing in it is ever executed, evaluated, used as a query, or
treated as an instruction (see `signals.AI_INSTRUCTION` for how instruction-like text is reported).
"""
import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime

MAX_MESSAGES = 200
MAX_MESSAGE_CHARS = 4000
MAX_TOTAL_CHARS = 60_000
MAX_SENDER_CHARS = 60


class InputError(ValueError):
    """Raised with a plain-language message that is safe to show to the user."""


def clean_text(value: str) -> str:
    """Canonical form used for ALL matching and for all evidence offsets.

    NFKC folds look-alike forms (full-width letters/digits); every Unicode 'C' category character other than
    newline/tab is dropped. That covers zero-width, bidirectional-control and soft-hyphen characters (category Cf),
    which are used to hide words from filters.
    """
    text = unicodedata.normalize("NFKC", value)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return "".join(ch for ch in text if ch in "\n\t" or unicodedata.category(ch)[0] != "C").strip()


@dataclass(frozen=True)
class Message:
    index: int
    sender: str | None
    timestamp: datetime | None
    text: str


_WHATSAPP = re.compile(
    r"^\[?(\d{1,2})/(\d{1,2})/(\d{2,4}),?\s+(\d{1,2}):(\d{2})(?::\d{2})?\s?([AaPp][Mm])?\]?\s*[-–]?\s*([^:\n]{1,40}?):\s?(.*)$")
_SENDER_LINE = re.compile(r"^([A-Za-z][\w .'\-]{0,30}):\s+(\S.*)$")


def _wa_time(day, month, year, hour, minute, ampm) -> datetime | None:
    try:
        y = int(year) + (2000 if len(year) == 2 else 0)
        h = int(hour)
        if ampm:
            h = h % 12 + (12 if ampm.lower() == "pm" else 0)
        return datetime(y, int(month), int(day), h, int(minute))  # day/month order assumed (India)
    except ValueError:
        return None


def parse_pasted(raw: str) -> list[dict]:
    """Split pasted chat text into messages. Recognises WhatsApp exports, 'Name: text' lines, or blank-line
    separated paragraphs. Returns dicts {sender, timestamp(ISO or None), text} for `prepare_messages`."""
    if not isinstance(raw, str):
        raise InputError("Paste the conversation as text.")
    if len(raw) > MAX_TOTAL_CHARS * 2:
        raise InputError(f"That is too long. Paste up to about {MAX_TOTAL_CHARS:,} characters.")
    lines = clean_text(raw).split("\n")
    out: list[dict] = []
    structured = any(_WHATSAPP.match(ln) or _SENDER_LINE.match(ln) for ln in lines)
    if not structured:
        paras = [p.strip() for p in re.split(r"\n\s*\n", "\n".join(lines)) if p.strip()]
        return [{"sender": None, "timestamp": None, "text": p} for p in paras]
    for ln in lines:
        wa = _WHATSAPP.match(ln)
        if wa:
            ts = _wa_time(*wa.group(1, 2, 3, 4, 5, 6))
            out.append({"sender": wa.group(7).strip(), "timestamp": ts.isoformat() if ts else None, "text": wa.group(8)})
            continue
        sl = _SENDER_LINE.match(ln)
        if sl:
            out.append({"sender": sl.group(1).strip(), "timestamp": None, "text": sl.group(2)})
        elif out and ln.strip():
            out[-1]["text"] += "\n" + ln  # continuation of the previous message
    return out


def _parse_ts(value) -> datetime | None:
    if value in (None, ""):
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed.replace(tzinfo=None) if parsed.tzinfo else parsed


def prepare_messages(raw: list[dict]) -> tuple[list[Message], str]:
    """Validate, clean and order messages. Returns (messages, ordering_note)."""
    if not isinstance(raw, list) or not raw:
        raise InputError("Add at least one message.")
    if len(raw) > MAX_MESSAGES:
        raise InputError(f"Too many messages. Up to {MAX_MESSAGES} are supported.")
    items, total = [], 0
    for item in raw:
        if not isinstance(item, dict) or not isinstance(item.get("text"), str):
            raise InputError("Each message needs text.")
        text = clean_text(item["text"])
        if not text:
            continue
        if len(text) > MAX_MESSAGE_CHARS:
            raise InputError(f"A message is too long (limit {MAX_MESSAGE_CHARS:,} characters).")
        total += len(text)
        sender = item.get("sender")
        sender = clean_text(sender)[:MAX_SENDER_CHARS] if isinstance(sender, str) and sender.strip() else None
        items.append((sender, _parse_ts(item.get("timestamp")), text))
    if not items:
        raise InputError("Add at least one message with some text.")
    if total > MAX_TOTAL_CHARS:
        raise InputError(f"That is too much text in total (limit {MAX_TOTAL_CHARS:,} characters).")
    if all(ts is not None for _, ts, _ in items):
        items = sorted(items, key=lambda i: i[1])  # stable: equal times keep pasted order
        note = "Messages are ordered by the timestamps provided."
    else:
        note = "Messages are kept in the order pasted, because timestamps are missing or unreadable."
    return [Message(i, s, t, x) for i, (s, t, x) in enumerate(items)], note
