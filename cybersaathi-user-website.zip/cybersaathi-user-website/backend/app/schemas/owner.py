from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.base import Strict


class UserAdminOut(BaseModel):
    """What the owner may see about an account. Deliberately no password hash, tokens, MFA secret or content."""
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    email: str
    role: str
    status: str
    email_verified: bool
    mfa_enabled: bool
    suspended_reason: str | None
    created_at: datetime
    last_login_at: datetime | None


class UserDetailOut(UserAdminOut):
    active_sessions: int
    failed_logins_24h: int


class UserStatusUpdate(Strict):
    status: Literal["ACTIVE", "SUSPENDED"]
    reason: str | None = Field(default=None, max_length=500)
    confirm: bool = False  # sensitive change must be explicitly confirmed


class UserRoleUpdate(Strict):
    # OWNER is intentionally absent: the owner is created once, by the bootstrap command.
    role: Literal["ADMIN", "SECURITY_ANALYST", "STANDARD_USER"]
    reason: str | None = Field(default=None, max_length=500)
    confirm: bool = False


class ConfirmRequest(Strict):
    confirm: bool = False


class SecurityEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    category: str
    severity: str
    component: str
    metadata_json: dict
    status: str
    resolution_notes: str | None
    created_at: datetime


class SecurityEventUpdate(Strict):
    status: Literal["OPEN", "INVESTIGATING", "RESOLVED"]
    resolution_notes: str | None = Field(default=None, max_length=1000)


class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    actor_id: str | None
    action: str
    target_type: str | None
    target_id: str | None
    result: str
    metadata_json: dict
    created_at: datetime
    entry_hash: str


class FeatureUpdate(Strict):
    enabled: bool
    confirm: bool = False


class NotificationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    severity: str
    title: str
    body: str
    read_at: datetime | None
    created_at: datetime


class NotificationPrefsUpdate(Strict):
    in_app_enabled: bool
    min_severity: Literal["MEDIUM", "HIGH", "CRITICAL"]
    email_enabled: bool


class NotificationPrefsOut(BaseModel):
    in_app_enabled: bool
    min_severity: str
    email_enabled: bool
    email_available: bool
    critical_always_delivered: bool = True


class ReleaseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    version: str
    backend_version: str
    status: str
    notes: str
    deployed_at: datetime
