"""Shared schema building blocks (pydantic only, so they import anywhere)."""
from pydantic import BaseModel, ConfigDict


class Strict(BaseModel):
    """Request bodies reject unknown fields (stops mass-assignment such as sending role=OWNER)."""
    model_config = ConfigDict(extra="forbid")


class MessageResponse(BaseModel):
    message: str
