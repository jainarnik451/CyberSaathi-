from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.schemas.base import MessageResponse, Strict  # noqa: F401  (re-exported for existing imports)


class RegisterRequest(Strict):
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)
    full_name: str | None = Field(default=None, max_length=120)


class LoginRequest(Strict):
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)


class VerifyEmailRequest(Strict):
    token: str = Field(min_length=10, max_length=200)
    password: str = Field(min_length=1, max_length=256)  # the password chosen at registration


class ForgotPasswordRequest(Strict):
    email: EmailStr


class ResetPasswordRequest(Strict):
    token: str = Field(min_length=10, max_length=200)
    new_password: str = Field(min_length=1, max_length=256)


class MfaCodeRequest(Strict):
    code: str = Field(min_length=6, max_length=6)


class MfaDisableRequest(Strict):
    password: str = Field(min_length=1, max_length=256)
    code: str = Field(min_length=6, max_length=6)


class DeleteRequest(Strict):
    password: str = Field(min_length=1, max_length=256)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    email: str
    full_name: str | None
    role: str
    status: str
    mfa_enabled: bool
    created_at: datetime


class LoginResponse(BaseModel):
    status: str  # ok | mfa_required | mfa_enrollment_required
    user: UserOut
    csrf_token: str


class MeResponse(BaseModel):
    user: UserOut
    mfa_passed: bool
    mfa_enrollment_required: bool


class MfaSetupResponse(BaseModel):
    secret: str
    otpauth_uri: str


class SessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    created_at: datetime
    expires_at: datetime
    ip_prefix: str | None
    user_agent: str | None
    current: bool = False
