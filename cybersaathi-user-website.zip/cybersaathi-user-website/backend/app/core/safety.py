"""Configuration safety rules. Pure Python (no third-party imports) so they are unit-tested everywhere.

Fail closed: a deployment that forgets CYBERSAATHI_ENVIRONMENT=production must not quietly run with the
publicly known development secret just because the default environment is "development".
"""

DEV_DEFAULT_SECRET = "dev-only-insecure-secret-key-do-not-use-in-production"
PLACEHOLDER_PREFIX = "replace-me"


def secret_is_weak(secret: str) -> bool:
    return secret == DEV_DEFAULT_SECRET or secret.lower().startswith(PLACEHOLDER_PREFIX) or len(secret) < 32


def settings_problems(*, environment: str, secret_key: str, database_url: str, email_backend: str,
                      cors_origins: list[str], frontend_base_url: str,
                      smtp_problems: list[str] | None = None) -> list[str]:
    problems: list[str] = list(smtp_problems or [])
    production = environment == "production"
    is_sqlite = database_url.startswith("sqlite")
    # A non-SQLite database means a real deployment, whatever the environment label says.
    if secret_is_weak(secret_key) and (production or (environment != "test" and not is_sqlite)):
        problems.append("CYBERSAATHI_SECRET_KEY must be set to a random value of 32+ characters")
    if production:
        if email_backend == "dev_outbox":
            problems.append("CYBERSAATHI_EMAIL_BACKEND=dev_outbox is not allowed in production")
        if "*" in cors_origins:
            problems.append("CYBERSAATHI_CORS_ORIGINS must not contain '*'")
        if is_sqlite:
            problems.append("SQLite is not allowed in production; use PostgreSQL")
        if not frontend_base_url.startswith("https://"):
            problems.append("CYBERSAATHI_FRONTEND_BASE_URL must start with https:// in production")
    return problems


def site_mounts(mode: str) -> dict[str, bool]:
    """What each site mode serves. Unknown modes serve the minimum (fail closed): nothing from the owner side."""
    return {
        "full": {"user_app": True, "user_api": True, "owner_ui": True, "owner_api": True},
        "public": {"user_app": True, "user_api": True, "owner_ui": False, "owner_api": False},
        "owner": {"user_app": False, "user_api": False, "owner_ui": True, "owner_api": True},
    }.get(mode, {"user_app": True, "user_api": True, "owner_ui": False, "owner_api": False})
