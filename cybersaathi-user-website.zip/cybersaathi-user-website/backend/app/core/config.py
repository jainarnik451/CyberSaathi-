"""Application settings, read from environment variables (prefix CYBERSAATHI_).

Secrets are never hardcoded. In production the app refuses to start with
insecure defaults.
"""
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.core.safety import DEV_DEFAULT_SECRET, settings_problems

DEFAULT_STATUS_FILE = str(Path(__file__).resolve().parents[3] / "DEVELOPMENT_STATUS.md")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="CYBERSAATHI_", extra="ignore")

    environment: Literal["development", "test", "production"] = "development"
    app_version: str = "0.1.0"
    backend_version: str = "0.1.0"

    database_url: str = "sqlite:///./cybersaathi.db"
    secret_key: str = DEV_DEFAULT_SECRET

    # Comma-separated list of allowed browser origins.
    cors_origins: str = "http://localhost:5173"
    frontend_base_url: str = "http://127.0.0.1:8000"  # where people open CyberSaathi; used in email links

    # Sessions
    session_ttl_minutes: int = 480
    privileged_session_ttl_minutes: int = 60

    # Login protection
    max_failed_logins: int = 5
    lockout_minutes: int = 15

    # How many reverse proxies sit in front of the app (0 = none, e.g. running on your laptop). Hosting
    # providers such as Render, Railway or Fly.io are normally 1. Needed so limits apply per visitor.
    trusted_proxy_hops: int = Field(default=0, ge=0, le=5)

    # Which parts to serve: "full" (everything; local development), "public" (the user website only: the
    # owner dashboard and owner API are NOT mounted) or "owner" (the Founder Control Centre only; run it on
    # your own laptop).
    site_mode: Literal["full", "public", "owner"] = "full"

    # Request limits
    max_request_bytes: int = 1_000_000
    # Requests per minute per client IP across the whole API (0 disables). Behind a reverse proxy every
    # visitor shares the proxy's IP, so raise it or configure trusted-proxy handling first.
    global_rate_limit_per_minute: int = 300

    # External providers. "none" = not configured. Keys are read from the environment only and are
    # never returned by any API (only "credentials present: yes/no" is shown to the owner).
    ai_provider: str = "none"
    ai_api_key: SecretStr | None = None
    threat_intel_provider: str = "none"
    threat_intel_api_key: SecretStr | None = None

    # Backups (see `python -m app.cli backup`). Empty = not configured.
    backup_dir: str = ""
    backup_max_age_hours: int = 26
    backup_keep_last: int = 14

    # Markdown file shown in the Control Centre (server-side path, never user-supplied).
    status_file: str = DEFAULT_STATUS_FILE

    # Email: "disabled" (default), "dev_outbox" (writes files; development only) or "smtp" (real delivery)
    email_backend: Literal["disabled", "dev_outbox", "smtp"] = "disabled"
    dev_outbox_dir: str = "dev_outbox"
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: SecretStr | None = None  # a secret: never shown in any API or log
    smtp_from: str | None = None
    smtp_security: Literal["starttls", "ssl", "none"] = "starttls"

    @property
    def secure_cookies(self) -> bool:
        # Also secure whenever the site is served over https, even if the environment label is wrong.
        return self.environment == "production" or self.frontend_base_url.startswith("https://")

    def smtp_problems(self) -> list[str]:
        if self.email_backend != "smtp":
            return []
        from app.services.smtp import config_problems
        password = self.smtp_password.get_secret_value() if self.smtp_password else None
        return config_problems(self.smtp_host, self.smtp_port, self.smtp_from, self.smtp_username, password, self.smtp_security)

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @model_validator(mode="after")
    def _validate_safety(self) -> "Settings":
        problems = settings_problems(
            environment=self.environment, secret_key=self.secret_key, database_url=self.database_url,
            email_backend=self.email_backend, cors_origins=self.cors_origin_list,
            frontend_base_url=self.frontend_base_url, smtp_problems=self.smtp_problems())
        if problems:
            raise ValueError("Unsafe configuration: " + "; ".join(problems))
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
