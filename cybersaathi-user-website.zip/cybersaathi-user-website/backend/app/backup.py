"""Database backup, standard library only.

    python -m app.cli backup

SQLite: uses SQLite's online backup API, then runs an integrity check on the copy.   (tested)
PostgreSQL: runs `pg_dump` (must be installed). The password is passed through the environment,
never on the command line.                                                       (NOT yet tested)

Backups contain personal data (password hashes, emails). Files are created owner-readable only;
encrypting the backup directory / disk is the operator's responsibility (docs/SECURITY.md).
"""
import json
import os
import sqlite3
import subprocess  # noqa: S404  (fixed argument list, no shell)
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlsplit

from app.control.backup_status import STATUS_FILENAME

PREFIX = "cybersaathi-"


class BackupError(Exception):
    pass


def _stamp(now: datetime) -> str:
    return now.strftime("%Y%m%dT%H%M%SZ")


def _sqlite_path(url: str) -> str:
    path = url.split("sqlite:///", 1)[1] if url.startswith("sqlite:///") else ""
    if not path or path == ":memory:":
        raise BackupError("in-memory or empty SQLite database cannot be backed up")
    return path


def _backup_sqlite(url: str, target: Path) -> None:
    src_path = _sqlite_path(url)
    resolved = Path(src_path).resolve()
    if not resolved.is_file():
        raise BackupError("database file does not exist")
    # as_uri() percent-encodes characters such as ? # % and handles Windows drive letters; a hand-built
    # "file:" + path breaks on those and could smuggle extra URI parameters.
    src = sqlite3.connect(f"{resolved.as_uri()}?mode=ro", uri=True)
    try:
        dst = sqlite3.connect(target)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    check = sqlite3.connect(target)
    try:
        if check.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise BackupError("integrity check failed on the backup copy")
    finally:
        check.close()


def _backup_postgres(url: str, target: Path) -> None:
    parts = urlsplit(url.replace("postgresql+psycopg", "postgresql", 1))
    if parts.scheme not in ("postgresql", "postgres") or not parts.path.strip("/"):
        raise BackupError("unsupported PostgreSQL URL")
    env = {k: v for k, v in os.environ.items() if k in ("PATH", "SYSTEMROOT", "HOME", "TEMP", "TMP")}
    if parts.password:
        env["PGPASSWORD"] = unquote(parts.password)
    cmd = ["pg_dump", "--format=custom", f"--file={target}", f"--host={parts.hostname or 'localhost'}",
           f"--port={parts.port or 5432}", f"--username={unquote(parts.username or '')}", "--no-password",
           parts.path.lstrip("/")]
    try:
        subprocess.run(cmd, env=env, check=True, capture_output=True, timeout=900)  # noqa: S603
    except FileNotFoundError:
        raise BackupError("pg_dump is not installed") from None
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        raise BackupError("pg_dump failed") from None


def _write_status(backup_dir: Path, data: dict) -> None:
    tmp = backup_dir / (STATUS_FILENAME + ".tmp")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    os.replace(tmp, backup_dir / STATUS_FILENAME)  # atomic: readers never see a half-written file


def prune(backup_dir: Path, keep_last: int) -> list[str]:
    files = sorted(p for p in backup_dir.iterdir() if p.is_file() and p.name.startswith(PREFIX))
    removed = []
    for old in files[:-keep_last] if keep_last > 0 else []:
        old.unlink()
        removed.append(old.name)
    return removed


def run_backup(database_url: str, backup_dir: str, keep_last: int = 14, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    directory = Path(backup_dir)
    directory.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(directory, 0o700)
    except OSError:
        pass  # not supported on some Windows setups
    previous = {}
    marker = directory / STATUS_FILENAME
    if marker.is_file():
        try:
            previous = json.loads(marker.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            previous = {}

    is_sqlite = database_url.startswith("sqlite")
    target = directory / f"{PREFIX}{_stamp(now)}.{'db' if is_sqlite else 'dump'}"
    try:
        if is_sqlite:
            _backup_sqlite(database_url, target)
        elif database_url.startswith(("postgresql", "postgres")):
            _backup_postgres(database_url, target)
        else:
            raise BackupError("unsupported database type")
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass
        status = {"last_attempt_at": now.isoformat(), "last_result": "success",
                  "last_success_at": now.isoformat(), "size_bytes": target.stat().st_size, "filename": target.name}
        error = None
    except BackupError as exc:
        target.unlink(missing_ok=True)
        status = {"last_attempt_at": now.isoformat(), "last_result": "failed",
                  "last_success_at": previous.get("last_success_at"), "size_bytes": previous.get("size_bytes"),
                  "filename": previous.get("filename"), "error": str(exc)}
        error = exc
    _write_status(directory, status)
    if error is None:
        prune(directory, keep_last)
    return status
