"""Per-client request budget for the whole API (pure ASGI).

The per-endpoint limits protect login/registration/reset. This one bounds everything else, including
authenticated endpoints that do expensive work, so one client cannot monopolise the server.
"""
import json
import logging

from app.security.limiter import RateLimiter

logger = logging.getLogger(__name__)
SKIP_PATHS = {"/healthz", "/readyz"}


class GlobalRateLimitMiddleware:
    def __init__(self, app, per_minute: int, limiter: RateLimiter) -> None:
        self.app = app
        self.per_minute = per_minute
        self.limiter = limiter

    async def __call__(self, scope, receive, send) -> None:
        if (self.per_minute <= 0 or scope["type"] != "http" or scope.get("path") in SKIP_PATHS
                or scope.get("method") == "OPTIONS"):
            await self.app(scope, receive, send)
            return
        client = scope.get("client")
        result = self.limiter.hit(f"global:{client[0] if client else 'unknown'}", self.per_minute, 60)
        if result.allowed:
            await self.app(scope, receive, send)
            return
        if result.first_block:
            logger.warning("Global rate limit reached by one client (limit %d/min)", self.per_minute)
        body = json.dumps({"detail": "Too many requests. Please try again later."}).encode()
        await send({"type": "http.response.start", "status": 429, "headers": [
            (b"content-type", b"application/json"), (b"content-length", str(len(body)).encode()),
            (b"retry-after", b"60"), (b"cache-control", b"no-store"), (b"x-content-type-options", b"nosniff")]})
        await send({"type": "http.response.body", "body": body})
