"""Records request count, status class and latency. Pure ASGI. Stores no URLs, headers or bodies."""
import time

from app.control.metrics import MetricsCollector

SKIP_PATHS = {"/healthz", "/readyz"}  # monitoring probes would otherwise swamp real traffic numbers


class MetricsMiddleware:
    def __init__(self, app, collector: MetricsCollector) -> None:
        self.app = app
        self.collector = collector

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http" or scope.get("path") in SKIP_PATHS:
            await self.app(scope, receive, send)
            return
        start = time.perf_counter()
        status = 500

        async def send_wrapper(message):
            nonlocal status
            if message["type"] == "http.response.start":
                status = message["status"]
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        except Exception:
            self.collector.record(500, (time.perf_counter() - start) * 1000)
            raise
        self.collector.record(status, (time.perf_counter() - start) * 1000)
