"""Content-Security-Policy per request path (pure, so it can be tested without the web framework)."""

OWNER_UI_PREFIX = "/owner-ui"
APP_UI_PREFIX = "/app"
STATIC_UI_PREFIXES = (OWNER_UI_PREFIX, APP_UI_PREFIX)
DOCS_PREFIXES = ("/docs", "/redoc", "/openapi.json")

# JSON API: nothing may be loaded or framed.
API_CSP = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'"

# Founder dashboard and user app (static files served by the API itself): only same-origin scripts, styles, images and
# API calls. No inline script, no inline style, no eval, no framing, no forms posted elsewhere.
OWNER_UI_CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
                "connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


def csp_for_path(path: str) -> str | None:
    """None means 'send no CSP' (interactive API docs in development only)."""
    if path.startswith(DOCS_PREFIXES):
        return None
    if any(path == p or path.startswith(p + "/") for p in STATIC_UI_PREFIXES):
        return OWNER_UI_CSP  # same strict policy for both static front ends
    return API_CSP
