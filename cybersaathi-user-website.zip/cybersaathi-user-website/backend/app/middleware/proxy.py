"""Real visitor address when the site runs behind a hosting provider's reverse proxy (pure ASGI, no third-party imports).

Why: behind a proxy every request seems to come from the proxy, so per-visitor limits (5 sign-ups per hour,
the global request budget) would be shared by ALL visitors. With TRUSTED_PROXY_HOPS=1 we read the address the
proxy recorded.

Safety rule: we count from the RIGHT of X-Forwarded-For. The right-most entries were added by proxies we trust;
anything a visitor typed sits on the left and is ignored. If the header is missing, too short or not an IP
address we keep the direct address. With hops=0 (the default) the header is never trusted.
"""
import ipaddress


def pick_client_ip(forwarded_for: str | None, hops: int, direct: str | None) -> str | None:
    if hops <= 0 or not forwarded_for:
        return direct
    parts = [p.strip() for p in forwarded_for.split(",") if p.strip()]
    if len(parts) < hops:
        return direct
    candidate = parts[-hops]
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return direct


class TrustedProxyMiddleware:
    def __init__(self, app, hops: int) -> None:
        self.app = app
        self.hops = hops

    async def __call__(self, scope, receive, send) -> None:
        if self.hops > 0 and scope["type"] in ("http", "websocket"):
            raw = next((v.decode("latin-1") for k, v in scope.get("headers", []) if k == b"x-forwarded-for"), None)
            direct = (scope.get("client") or (None, 0))[0]
            ip = pick_client_ip(raw, self.hops, direct)
            if ip and ip != direct:
                scope = {**scope, "client": (ip, 0)}
        await self.app(scope, receive, send)
