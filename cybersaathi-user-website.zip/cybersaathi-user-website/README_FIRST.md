# CyberSaathi: public website package
1. Read `DEPLOY_GUIDE.md` (step by step).
2. Fill in the settings listed in `env.production.example` on your hosting provider's page (never in a file you upload).
3. This package contains only the user website. The owner dashboard is a separate package that you run on your laptop.
CyberSaathi is a decision-support tool. Nothing here is claimed to be completely secure.
