import { api } from "../api.js";
import { badge, errorBox, fmtDate, h, icon } from "../dom.js";
import { evidenceBlock, list, riskBanner, run, section, sensitivityBadge, SENS_TONE } from "../ui.js";

const EXAMPLE = `[12/10/2025, 10:32] HR Team: Congratulations! You have been selected for the internship at Example Tech Labs.
[12/10/2025, 10:35] HR Team: Please send your Aadhaar copy and a selfie to confirm your seat. Contact me on WhatsApp.
[12/10/2025, 10:40] HR Team: Pay the registration fee of Rs 1500 within 2 hours. Do not tell anyone.`;

const weightTone = (w) => (w >= 3 ? "bad" : w >= 1 ? "warn" : "");

function timeline(journey) {
  const byId = Object.fromEntries(journey.signals.map((s) => [s.signal_id, s]));
  return h("ol", { class: "timeline", "aria-label": "Conversation timeline", "data-testid": "timeline" }, journey.timeline.map((m) =>
    h("li", { class: weightTone(m.max_weight) },
      h("div", { class: "meta" }, `Message ${m.message_index + 1}`, m.sender ? ` · ${m.sender}` : "", m.time ? ` · ${fmtDate(m.time)}` : ""),
      h("div", { class: "msg" }, m.preview),
      m.signal_ids.length ? h("div", { class: "chips" }, m.signal_ids.map((id) => badge(byId[id].title, weightTone(byId[id].weight) || "muted"))) : null)));
}

function signals(journey) {
  if (!journey.signals.length) return h("p", { class: "empty" }, "No warning patterns matched. That does not prove the messages are safe.");
  return h("div", { class: "stack-cards" }, journey.signals.map((s) =>
    h("article", { class: "signal", "data-testid": "signal" },
      h("h4", null, s.title, badge(s.category_label, "muted"), h("span", { class: "note" }, `message ${s.message_index + 1}`)),
      evidenceBlock(s.evidence_quote, s.evidence_context),
      h("p", { class: "why" }, h("strong", null, "Why it matters: "), s.why_it_matters),
      h("p", { class: "alt" }, h("strong", null, "Could be harmless if: "), s.possible_harmless_explanation))));
}

const RINGS = [["CRITICAL", 38], ["HIGH", 78], ["MEDIUM", 118], ["LOW", 158]];
const SHORT = { SECRET_CODES: "Codes", FINANCIAL: "Money", IDENTITY: "ID", ACCOUNT: "Accounts", PHOTOS: "Photos", ADDRESS: "Address", PHONE_EMAIL: "Contact" };

function exposureMap(exp) {
  const svg = h("svg", { class: "expmap", viewBox: "0 0 360 360", role: "img",
    "aria-label": exp.categories.length ? `Exposure map: ${exp.categories.map((c) => `${c.label} (${c.sensitivity.toLowerCase()})`).join(", ")}` : "Exposure map: nothing requested" });
  RINGS.forEach(([, r]) => svg.append(h("circle", { cx: 180, cy: 180, r, class: "ringline" })));
  svg.append(h("circle", { cx: 180, cy: 180, r: 22, class: "you" }), h("text", { x: 180, y: 184 }, "You"));
  const perRing = {};
  exp.categories.forEach((c) => { (perRing[c.sensitivity] ||= []).push(c); });
  RINGS.forEach(([name, r]) => {
    const items = perRing[name] || [];
    items.forEach((c, i) => {
      const angle = (i / Math.max(1, items.length)) * 2 * Math.PI - Math.PI / 2 + (name === "HIGH" ? 0.6 : name === "MEDIUM" ? 1.1 : 0.3);
      const x = 180 + r * Math.cos(angle), y = 180 + r * Math.sin(angle);
      svg.append(h("circle", { cx: x.toFixed(1), cy: y.toFixed(1), r: 17, class: `node ${SENS_TONE[name]}` }),
        h("text", { x: x.toFixed(1), y: (y + 3).toFixed(1) }, SHORT[c.category] || c.category));
    });
  });
  svg.append(h("text", { x: 180, y: 352, class: "legend" }, "Inner rings = more sensitive"));
  return svg;
}

function exposureSection(exp) {
  const body = [h("p", null, exp.summary)];
  body.push(h("div", { class: "map-wrap" }, exposureMap(exp),
    h("div", { class: "stack-cards" }, exp.categories.length ? exp.categories.map((c) =>
      h("article", { class: "signal", "data-testid": "exposure-item" },
        h("h4", null, c.label, sensitivityBadge(c.sensitivity)),
        evidenceBlock(c.evidence[0].evidence_quote, c.evidence[0].evidence_context),
        h("p", { class: "why" }, h("strong", null, "Risk: "), c.why_it_matters),
        h("p", { class: "alt" }, h("strong", null, "Safer: "), c.safer_alternative))) : h("p", { class: "empty" }, "No requests for personal data were detected."))));
  body.push(h("p", { class: "note" }, exp.do_not_enter), list(exp.limits));
  return section("Exposure Map: what is being asked for", ...body);
}

function render(report) {
  const out = [riskBanner(report.indicator, report.level)];
  const j = report.journey, e = report.exposure;
  if (j) {
    if (j.sequence_notes.length) out.push(section("What happened, in order", list(j.sequence_notes)));
    out.push(section("Timeline", h("p", { class: "note" }, j.ordering_note), timeline(j)));
    out.push(section(`Warning patterns found (${j.signals.length})`, signals(j)));
    out.push(section("Facts, indicators, assumptions and unknowns", h("div", { class: "cols4" },
      h("div", null, h("h4", null, "Facts"), list(j.facts)), h("div", null, h("h4", null, "Indicators"), j.indicators.length ? list(j.indicators) : h("p", { class: "note" }, "None found.")),
      h("div", null, h("h4", null, "Assumptions"), list(j.assumptions)), h("div", null, h("h4", null, "Unknowns"), list(j.unknowns)))));
    if (j.alternative_explanations.length) out.push(section("Possible harmless explanations", list(j.alternative_explanations)));
  }
  if (e) out.push(exposureSection(e));
  out.push(section("Safe next steps", list(report.next_steps)));
  if (j) out.push(section("Limits of this analysis", list(j.limits)));
  out.push(h("p", { class: "note", "data-testid": "honesty" }, report.honesty_note));
  return h("div", { "data-testid": "report" }, out);
}

export default async function analyse(page, { flags }) {
  const text = h("textarea", { class: "paste", name: "text", maxlength: 130000, "aria-label": "Conversation to analyse", placeholder: "Paste the messages here, one per line. WhatsApp exports work too." });
  const result = h("div", { "aria-live": "polite" });
  const button = h("button", { class: "btn primary", type: "button" }, "Analyse");
  const sample = h("button", { class: "btn", type: "button", onClick: () => { text.value = EXAMPLE; } }, "Use a fictional example");
  const onError = (err) => errorBox(err.message, () => button.click());
  button.addEventListener("click", () => {
    if (!text.value.trim()) { result.replaceChildren(errorBox("Paste a conversation first.")); return; }
    run(button, result, () => api("/features/analyze", { method: "POST", body: { text: text.value } }), render, onError);
  });
  page.append(
    h("p", { class: "lede" }, "Paste a conversation to see how trust is being built, where pressure appears, and what personal information is being requested."),
    h("div", { class: "card" }, h("label", { class: "field" }, h("span", null, "Conversation"), text),
      h("p", { class: "privacy" }, icon("lock", 16), "Analysed in memory and not stored. Please remove OTPs, passwords and card numbers before pasting; "
        + "they are never needed. Phone numbers, emails and ID numbers are hidden in the results."),
      h("div", { class: "actions wrap" }, button, sample)),
    result);
  if (!flags.scam_journey && !flags.digital_footprint) page.append(errorBox("This feature is not switched on right now."));
}
