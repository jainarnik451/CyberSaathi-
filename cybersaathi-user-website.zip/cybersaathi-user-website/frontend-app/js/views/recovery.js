import { api } from "../api.js";
import { badge, errorBox, h } from "../dom.js";
import { SITUATIONS } from "../labels.js";
import { list } from "../ui.js";

function reportingCard(r) {
  const contacts = r.contacts.length ? r.contacts.map((c) => h("div", { class: "contact", "data-testid": "contact" },
    h("div", null, h("strong", null, c.value), h("div", { class: "note" }, c.name)), h("span", null, c.use))) : [h("p", { class: "empty" }, "No checked reporting details for this country are available here.")];
  return h("section", { class: "card", "data-testid": "reporting" }, h("h2", null, `Official reporting: ${r.country}`),
    ...contacts, h("p", null, r.urgent_tip),
    r.verified_on ? badge(`Last checked ${r.verified_on}`, "muted") : badge("Not checked for this country", "muted"),
    h("p", { class: "note" }, r.verification_note));
}

function render(c) {
  return h("div", { class: "stack", "data-testid": "checklist" },
    h("div", { class: "banner" }, h("p", null, c.cannot_do)),
    c.sections.map((s) => h("section", { class: "card" }, h("h2", null, s.title),
      h("ul", { class: "checklist" }, s.steps.map((t) => h("li", null, h("label", null, h("input", { type: "checkbox" }), h("span", null, t))))))),
    reportingCard(c.reporting),
    h("p", { class: "note" }, "Ticks are only for you while this page is open. Nothing is saved or sent."));
}

export default async function recovery(page) {
  let situation = null;
  const out = h("div", { "aria-live": "polite" });
  const country = h("select", { name: "country", "aria-label": "Your country" }, h("option", { value: "IN" }, "India"), h("option", { value: "" }, "Another country"));
  const buttons = Object.entries(SITUATIONS).map(([key, label]) => h("button", { type: "button", class: "btn", "aria-pressed": "false", "data-situation": key, onClick: () => { situation = key; load(); } }, label));

  async function load() {
    buttons.forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.situation === situation)));
    if (!situation) return;
    out.replaceChildren(h("p", { class: "loading", role: "status" }, "Loading…"));
    try {
      const q = country.value ? `?country=${encodeURIComponent(country.value)}` : "";
      out.replaceChildren(render(await api(`/features/recovery/${situation.toLowerCase()}${q}`)));
    } catch (err) { out.replaceChildren(errorBox(err.message, load)); }
  }
  country.addEventListener("change", load);
  page.append(
    h("p", { class: "lede" }, "If something already happened, here is what to do and who can help. CyberSaathi cannot reverse payments, recover accounts or contact anyone for you."),
    h("label", { class: "field" }, h("span", null, "Where are you?"), country),
    h("p", { class: "note" }, "What happened?"), h("div", { class: "picker", role: "group", "aria-label": "What happened" }, buttons),
    out, h("div", null, list(["If you feel unsafe or are being threatened, contact your local emergency number and a trusted adult first."])));
}
