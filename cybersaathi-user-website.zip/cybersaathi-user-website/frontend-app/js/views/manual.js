// The user manual. Plain text built with h() (never HTML). Shown as a menu page after sign-in and, before
// sign-in, from the "How to use CyberSaathi" link, so a new visitor can read it without an account.
import { h } from "../dom.js";

const STEPS = [
  ["Create your account", [
    "Open the website and choose Create account.",
    "Type your email address and choose a password of at least 12 characters. Use something only you know; do not reuse a password from another website.",
    "Press Create account. A message says an email has been sent.",
  ]],
  ["Verify your email (you cannot sign in before this)", [
    "Open the email from CyberSaathi. It can take a minute. Look in your Spam or Promotions folder too.",
    "Either click the link in the email, or copy the long code from it.",
    "On the Check your email page, make sure your email is filled in, paste the code, and type your password again (the one you just chose). Press Verify email.",
    "No email? Press Send me a new code. If you wait about a minute and still see nothing, check the address you typed.",
  ]],
  ["Sign in", [
    "Choose Sign in, type your email and password, and press Sign in.",
    "Forgot your password? Press Forgot your password?, enter your email, then use the code from the email to choose a new one.",
    "If your account has two-step verification, type the 6-digit code from your authenticator app.",
  ]],
  ["Understand a suspicious conversation (Analyse a conversation)", [
    "Copy the messages you received (for example a job or scholarship offer) and paste them into the box. Put each message on its own line.",
    "Press Analyse. You get a warning level, a timeline, the patterns found with the exact words that triggered them, and the personal details that were asked for.",
    "This is a rule-based checker, not an AI judge and not a verdict. It can miss scams and can flag honest messages. Treat it as a second opinion that helps you slow down.",
    "Do not paste passwords, OTPs, PINs or card numbers. You never need to.",
  ]],
  ["Check a claim (ProofPass)", [
    "Type the claim you want to check, for example: The company offered me this internship.",
    "Add the evidence you found yourself, such as an official page you opened or an email address you compared. Say where it came from and when you saw it.",
    "With no evidence the result is UNKNOWN. That means not enough information; it does not mean fraud. ProofPass does not look anything up on the internet for you.",
  ]],
  ["Practice safely (SafeChoice practice)", [
    "Pick a practice scenario. They are fictional, so nothing you choose affects anyone.",
    "Choose what you would do and read why each choice is safer or riskier.",
  ]],
  ["If something already went wrong (Recovery Navigator)", [
    "Choose the situation closest to yours, for example you shared a password or paid money.",
    "Follow the checklist from the top: secure your accounts, keep evidence, then report. Ticks are only for you while the page is open.",
    "Official reporting details are shown with the date they were last checked. Confirm them on the official website. CyberSaathi cannot get money or accounts back for you.",
  ]],
  ["Community alerts (only if switched on)", [
    "You can choose to report a scam pattern. Reports are checked by a person before anything is shown to others, and personal details are removed first.",
  ]],
];

const FIXES = [
  ["The email does not arrive", "Check Spam, wait a minute, then press Send me a new code. Make sure the address has no typing mistake."],
  ["Invalid email or password right after creating an account", "Your email is probably not verified yet. Verify it first (see step 2), then sign in."],
  ["Too many requests", "You tried too many times in a short while. Wait an hour and try again."],
  ["A page is missing from the menu", "That feature is switched off for now."],
  ["You were signed out", "Sessions end after a while for your safety. Sign in again."],
];

export function manualContent() {
  return h("div", { class: "stack", "data-testid": "manual" },
    h("div", { class: "banner" }, h("p", null,
      "CyberSaathi will never ask for your OTP, PIN, CVV, card number or password in a chat, an email or a call. If anyone does, stop.")),
    h("section", { class: "card" }, h("h2", null, "Quick path"),
      h("p", null, "Create account → verify email → sign in → paste a conversation you are unsure about → read the result → decide what to do. The app follows five steps: Understand, Verify, Decide, Learn, Protect.")),
    STEPS.map(([title, items], i) => h("section", { class: "card", "data-testid": "manual-step" },
      h("h2", null, `${i + 1}. ${title}`),
      h("ol", { class: "bullets" }, items.map((t) => h("li", null, t))))),
    h("section", { class: "card" }, h("h2", null, "If something does not work"),
      h("dl", { class: "stack" }, FIXES.map(([q, a]) => h("div", null, h("dt", null, h("strong", null, q)), h("dd", null, a))))),
    h("section", { class: "card", "data-testid": "manual-purpose" }, h("h2", null, "What CyberSaathi is for"),
      h("p", null, "CyberSaathi helps students and young job-seekers slow down before they trust a stranger online. Many scams follow the same shape: an exciting offer, a request for personal details, then pressure to pay or share a code quickly. CyberSaathi shows that shape in plain language so you can decide calmly."),
      h("ul", { class: "bullets" },
        h("li", null, "Understand: see how a conversation builds up and which patterns look risky."),
        h("li", null, "Verify: check a claim against evidence you collected, and see clearly what is still unknown."),
        h("li", null, "Decide: get safer next steps before you reply, click or pay."),
        h("li", null, "Learn: practise on fictional situations."),
        h("li", null, "Protect: follow a clear checklist if something already went wrong.")),
      h("p", { class: "note" }, "CyberSaathi is an educational and decision-support tool. It does not guarantee that a message is safe or unsafe, it is not legal or police advice, and no tool can make anyone completely secure. When unsure, ask a trusted adult or the official organisation using contact details you found yourself.")));
}

export default async function manual(page) {
  page.append(manualContent());
}
