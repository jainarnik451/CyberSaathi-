import { api } from "../api.js";
import { barChart, badge, errorBox, h, toast } from "../dom.js";
import { CHANNELS, SCAM_TYPES, TACTICS } from "../labels.js";
import { run } from "../ui.js";

const opt = (map) => Object.entries(map).map(([value, label]) => h("option", { value }, label));

function reportCard() {
  const type = h("select", { name: "scam_type" }, opt(SCAM_TYPES)), channel = h("select", { name: "channel" }, opt(CHANNELS));
  const pay = h("input", { type: "checkbox", name: "payment_requested" });
  const tactics = Object.entries(TACTICS).map(([k, label]) => [k, h("input", { type: "checkbox", value: k }), label]);
  const out = h("div", { "aria-live": "polite" });
  const button = h("button", { class: "btn primary", type: "button" }, "Send anonymous report");
  button.addEventListener("click", () => {
    const body = { scam_type: type.value, channel: channel.value, payment_requested: pay.checked, tactics: tactics.filter(([, i]) => i.checked).map(([k]) => k) };
    run(button, out, () => api("/community/reports", { method: "POST", body }), (r) => h("div", { class: r.status === "received" ? "banner good" : "banner", "data-testid": "report-result" }, h("p", null, r.message)), (e) => errorBox(e.message));
  });
  return h("section", { class: "card" }, h("h2", null, "Report a pattern"),
    h("p", { class: "note" }, "Choose from the lists only. There is no free-text box on purpose: do not report names, numbers or links. Reports are stored without your identity and "
      + "only count toward an alert after several different people report the same pattern and a moderator approves it."),
    h("div", { class: "grid2" }, h("label", { class: "field" }, h("span", null, "What kind of scam?"), type), h("label", { class: "field" }, h("span", null, "Where did it reach you?"), channel)),
    h("fieldset", { class: "field" }, h("span", null, "What did they do? (tick all that apply)"), h("div", { class: "checkgrid" }, tactics.map(([, input, label]) => h("label", null, input, label)))),
    h("label", { class: "check" }, pay, h("span", null, "A payment was requested")), h("div", { class: "actions wrap" }, button), out);
}

function alertCard(a, reload) {
  const flag = h("button", { class: "btn small", type: "button" }, "This looks inaccurate");
  flag.addEventListener("click", async () => {
    flag.disabled = true;
    try { const r = await api(`/community/alerts/${encodeURIComponent(a.id)}/flag`, { method: "POST" }); toast(r.message); }
    catch (err) { toast(err.message, "bad"); flag.disabled = false; }
  });
  return h("article", { class: "signal", "data-testid": "alert" }, h("h4", null, a.title, badge(`${a.reporter_count} reporters`, "muted")),
    h("p", null, a.body), h("p", { class: "note" }, a.disclaimer), h("div", { class: "actions wrap" }, flag));
}

export default async function community(page) {
  const slot = h("div", { class: "stack" });
  page.append(h("p", { class: "lede" }, "Moderated, anonymous patterns reported by several people. Alerts describe a pattern, never a named person or organisation, and are not independently verified."), slot);
  const [alerts, trends] = await Promise.all([api("/community/alerts"), api("/community/trends")]);
  slot.append(reportCard(),
    h("section", { class: "card" }, h("h2", null, "Published alerts"),
      alerts.alerts.length ? h("div", { class: "stack-cards" }, alerts.alerts.map((a) => alertCard(a))) : h("p", { class: "empty", "data-testid": "no-alerts" }, "No alerts have been published yet. That does not mean nothing is happening; alerts need several reports and a moderator's review.")),
    h("section", { class: "card" }, h("h2", null, "Report trends"),
      trends.weekly.length ? barChart(trends.weekly.map((w) => ({ label: w.week, value: w.reports })), "Reports per week") : h("p", { class: "empty" }, "No reports yet."),
      trends.patterns.length ? h("ul", { class: "bullets" }, trends.patterns.map((p) => h("li", null, `${SCAM_TYPES[p.scam_type] || p.scam_type} via ${CHANNELS[p.channel] || p.channel}: ${p.reporter_count} reporters`))) : null,
      h("p", { class: "note" }, trends.note)));
}
