export const TOPIC = {
  FAKE_INTERNSHIP: "Fake internship offers", SCHOLARSHIP_PAYMENT: "Scholarship payment requests", SUSPICIOUS_QR: "Suspicious QR codes",
  INSTITUTION_IMPERSONATION: "Institution impersonation", FAKE_SUPPORT: "Fake customer support", OTP_REQUEST: "OTP requests",
};
