import { api } from "../api.js";
import { badge, errorBox, h } from "../dom.js";
import { CLAIM_TYPES, SOURCE_TYPES, SUPPORTS } from "../labels.js";
import { list, run, section, STATUS_TONE } from "../ui.js";

const opt = (map) => Object.entries(map).map(([value, label]) => h("option", { value }, label));
const CLASS_TEXT = { OFFICIAL: "Official source", INDEPENDENT: "Independent source", UNVERIFIED: "Not a verifying source" };

function evidenceForm(onRemove) {
  const f = {
    type: h("select", { name: "source_type" }, opt(SOURCE_TYPES)), found: h("input", { name: "what_was_found", maxlength: 400, required: true }),
    name: h("input", { name: "source_name", maxlength: 120 }), url: h("input", { name: "source_url", type: "url", maxlength: 300, placeholder: "Web address (kept as text, never opened)" }),
    date: h("input", { name: "source_date", type: "date" }), supports: h("select", { name: "supports" }, opt(SUPPORTS)),
    confirmed: h("input", { type: "checkbox", name: "human_confirmed" }),
  };
  const el = h("div", { class: "evform", "data-testid": "evidence-form" },
    h("div", { class: "grid2" },
      h("label", { class: "field" }, h("span", null, "Where did you look?"), f.type),
      h("label", { class: "field" }, h("span", null, "What does it say about this claim?"), f.supports)),
    h("label", { class: "field" }, h("span", null, "What did you find?"), f.found),
    h("div", { class: "grid2" },
      h("label", { class: "field" }, h("span", null, "Source name (optional)"), f.name),
      h("label", { class: "field" }, h("span", null, "Date of the source (optional)"), f.date)),
    h("label", { class: "field" }, h("span", null, "Link (optional)"), f.url),
    h("label", { class: "check" }, f.confirmed, h("span", null, "I checked this myself")),
    h("button", { type: "button", class: "btn small", onClick: () => onRemove(el) }, "Remove this evidence"));
  el.read = () => {
    const e = { source_type: f.type.value, what_was_found: f.found.value, supports: f.supports.value, human_confirmed: f.confirmed.checked };
    if (f.name.value.trim()) e.source_name = f.name.value;
    if (f.url.value.trim()) e.source_url = f.url.value.trim();
    if (f.date.value) e.source_date = f.date.value;
    return e;
  };
  return el;
}

function claimForm(onRemove) {
  const text = h("input", { name: "claim", maxlength: 300, required: true, placeholder: "e.g. The company offered me this internship" });
  const evBox = h("div", { class: "stack" });
  const removeEv = (el) => el.remove();
  const el = h("div", { class: "subcard", "data-testid": "claim-form" },
    h("label", { class: "field" }, h("span", null, "Claim to check"), text), evBox,
    h("div", { class: "actions wrap" },
      h("button", { type: "button", class: "btn small", onClick: () => evBox.append(evidenceForm(removeEv)) }, "Add evidence I found"),
      h("button", { type: "button", class: "btn small", onClick: () => onRemove(el) }, "Remove claim")));
  el.read = () => ({ claim: text.value, evidence: [...evBox.children].map((c) => c.read()) });
  return el;
}

function claimResult(c) {
  return h("article", { class: "subcard", "data-testid": "claim-result" },
    h("div", { class: "row" }, h("strong", null, c.claim), badge(c.status, STATUS_TONE[c.status])),
    h("p", null, c.status_reason),
    c.evidence.length ? h("div", { class: "stack-cards" }, c.evidence.map((e) => h("div", { class: "evidence" },
      h("blockquote", null, e.what_was_found),
      h("figcaption", null, [e.source_type_label, CLASS_TEXT[e.source_class], e.source_name, e.source_date && `dated ${e.source_date}`,
        e.stale ? "may be out of date" : null, e.confirmed_by === "user" ? "confirmed by you" : "not confirmed by you", "not checked by CyberSaathi"].filter(Boolean).join(" · "),
      e.source_url ? h("div", null, "Link given: ", h("code", { class: "break" }, e.source_url), " (not opened)") : null)))) : h("p", { class: "note" }, "No evidence supplied."),
    h("div", null, h("strong", null, "Still unknown"), list(c.remaining_unknowns.length ? c.remaining_unknowns : ["Nothing flagged, but keep checking before paying."])),
    h("p", null, h("strong", null, "Next step: "), c.next_step));
}

function render(report) {
  const k = report.summary_counts;
  return h("div", { "data-testid": "proof-report" },
    h("p", { class: "lede" }, report.explanation),
    h("p", null, `Verified: ${k.VERIFIED} · Warning: ${k.WARNING} · Unknown: ${k.UNKNOWN}`),
    section("Claims", h("div", { class: "stack-cards" }, report.claims.map(claimResult))),
    section("Automated checks (text only, nothing was looked up online)", h("div", { class: "stack-cards" }, report.automated_checks.map((a) =>
      h("div", { class: "subcard" }, h("div", { class: "row" }, h("span", null, a.finding), badge(a.level.toLowerCase(), a.level === "WARNING" ? "warn" : "muted")), h("small", { class: "note" }, a.limitation))))),
    h("p", { class: "note" }, report.separation_note));
}

export default async function proofpass(page) {
  const type = h("select", { name: "claim_type" }, opt(CLAIM_TYPES));
  const org = h("input", { name: "organisation_name", maxlength: 120 });
  const sender = h("input", { name: "sender_email", type: "email", maxlength: 320 });
  const site = h("input", { name: "claimed_website", type: "url", maxlength: 300, placeholder: "Web address (kept as text, never opened)" });
  const claims = h("div", { class: "stack" });
  const removeClaim = (el) => el.remove();
  claims.append(claimForm(removeClaim));
  const result = h("div", { "aria-live": "polite" });
  const button = h("button", { class: "btn primary", type: "button" }, "Build my ProofPass");
  const onError = (err) => errorBox(err.message);
  button.addEventListener("click", () => {
    const body = { claim_type: type.value, claims: [...claims.children].map((c) => c.read()) };
    if (org.value.trim()) body.organisation_name = org.value;
    if (sender.value.trim()) body.sender_email = sender.value.trim();
    if (site.value.trim()) body.claimed_website = site.value.trim();
    if (!body.claims.length || body.claims.some((c) => !c.claim.trim())) { result.replaceChildren(errorBox("Add at least one claim and fill in its text.")); return; }
    run(button, result, () => api("/features/proofpass", { method: "POST", body }), render, onError);
  });
  page.append(
    h("p", { class: "lede" }, "List what is being claimed, then add evidence you found yourself. CyberSaathi does not look anything up: it organises your evidence, shows what is still unknown, "
      + "and only marks a claim VERIFIED when a trusted source type is something you confirmed. A missing website or listing never proves fraud."),
    h("div", { class: "card stack" },
      h("div", { class: "grid2" }, h("label", { class: "field" }, h("span", null, "What are you checking?"), type), h("label", { class: "field" }, h("span", null, "Organisation name (optional)"), org)),
      h("div", { class: "grid2" }, h("label", { class: "field" }, h("span", null, "Sender's email (optional)"), sender), h("label", { class: "field" }, h("span", null, "Website they gave (optional)"), site)),
      claims,
      h("div", { class: "actions wrap" }, h("button", { type: "button", class: "btn", onClick: () => claims.append(claimForm(removeClaim)) }, "Add another claim"), button)),
    result);
}
