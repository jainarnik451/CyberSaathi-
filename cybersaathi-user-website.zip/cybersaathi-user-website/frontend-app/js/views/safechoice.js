import { api } from "../api.js";
import { badge, errorBox, h, ring } from "../dom.js";
import { TOPIC } from "./topics.js";

const RATING_TONE = { BEST: "good", OKAY: "warn", RISKY: "bad" };
const RATING_TEXT = { BEST: "Safest", OKAY: "Acceptable", RISKY: "Risky" };

function progressCard(p) {
  return h("section", { class: "card", "data-testid": "progress" },
    h("div", { class: "split" }, ring(p.scenarios_total ? p.scenarios_mastered / p.scenarios_total : null, `${p.scenarios_mastered}/${p.scenarios_total}`, "mastered", "good"),
      h("div", { class: "stats" }, h("p", null, p.empty ? "You have not tried any scenarios yet. Everything here is fictional practice." : `You have tried ${p.scenarios_attempted} of ${p.scenarios_total} scenarios and chosen the safest response in ${p.scenarios_mastered}.`),
        h("p", { class: "note" }, `Safest on the first try: ${p.best_on_first_try}. Total answers: ${p.attempts}.`))));
}

export default async function safechoice(page) {
  const progressSlot = h("div"), body = h("div");
  page.append(h("p", { class: "lede" }, "Practise responding to suspicious situations. All names, numbers and offers here are invented, nothing is sent anywhere, and you will never be asked for real details."), progressSlot, body);

  async function refreshProgress() { progressSlot.replaceChildren(progressCard(await api("/features/safechoice/progress"))); }

  async function showList() {
    const [{ scenarios }] = await Promise.all([api("/features/safechoice/scenarios"), refreshProgress()]);
    body.replaceChildren(h("div", { class: "stack-cards" }, scenarios.map((s) =>
      h("button", { class: "btn choice", type: "button", "data-testid": "scenario", onClick: () => showScenario(s.id) },
        h("strong", null, s.title), " ", h("span", { class: "note" }, TOPIC[s.topic] || "")))));
  }

  async function showScenario(id) {
    const sc = await api(`/features/safechoice/scenarios/${encodeURIComponent(id)}`);
    const feedback = h("div", { "aria-live": "polite" });
    const buttons = sc.choices.map((c) => h("button", { class: "btn choice", type: "button", "data-choice": c.id,
      onClick: async () => {
        buttons.forEach((b) => { b.disabled = true; });
        try {
          const r = await api("/features/safechoice/answer", { method: "POST", body: { scenario_id: sc.id, choice_id: c.id } });
          feedback.replaceChildren(result(r)); await refreshProgress();
        } catch (err) { buttons.forEach((b) => { b.disabled = false; }); feedback.replaceChildren(errorBox(err.message)); }
      } }, c.text));
    const result = (r) => h("div", { class: "stack-cards", "data-testid": "feedback" },
      h("div", { class: `feedback ${r.rating.toLowerCase()}` }, h("strong", null, r.was_best ? "That is the safest choice." : `Your choice: ${RATING_TEXT[r.rating]}.`), h("p", null, r.risk_of_this_choice)),
      h("h3", null, "All the choices"),
      r.all_choices.map((c) => h("div", { class: `feedback ${c.rating.toLowerCase()}` }, h("div", null, badge(RATING_TEXT[c.rating], RATING_TONE[c.rating]), " ", c.text), h("p", { class: "note" }, c.risk))),
      h("div", { class: "feedback" }, h("strong", null, "Recommendation"), h("p", null, r.recommendation), h("strong", null, "Lesson"), h("p", null, r.lesson)),
      h("div", { class: "actions wrap" }, h("button", { class: "btn", type: "button", onClick: () => showScenario(sc.id) }, "Try again"), h("button", { class: "btn primary", type: "button", onClick: () => showList().catch(fail) }, "Choose another scenario")));
    body.replaceChildren(h("section", { class: "card" }, h("h2", null, sc.title), h("p", { class: "note" }, sc.fictional_notice),
      sc.situation.map((t) => h("p", null, t)), h("h3", null, "What would you do?"), h("div", { class: "choice-list" }, buttons), feedback));
  }
  const fail = (err) => body.replaceChildren(errorBox(err.message, () => showList().catch(fail)));
  await showList();
}
