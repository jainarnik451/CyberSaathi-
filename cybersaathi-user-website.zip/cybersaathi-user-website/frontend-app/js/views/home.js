import { h } from "../dom.js";

const STEPS = [
  { n: "1  UNDERSTAND", title: "Analyse a conversation", key: "analyse", needs: ["scam_journey", "digital_footprint"],
    text: "Paste messages. See how trust is built, what pressure appears, and what information is being asked for." },
  { n: "2  VERIFY", title: "ProofPass", key: "proofpass", needs: ["trustcheck"],
    text: "Check each claim against evidence you find yourself. Unknown is not the same as fake." },
  { n: "3  DECIDE", title: "Safer next steps", key: "analyse", needs: ["scam_journey", "digital_footprint"],
    text: "Every report ends with safe next steps and safer alternatives, so you choose with facts." },
  { n: "4  LEARN", title: "SafeChoice practice", key: "safechoice", needs: ["learning"],
    text: "Practise on fictional scenarios. Nothing real is sent and no credentials are ever asked for." },
  { n: "5  PROTECT", title: "Recovery and community", key: "recovery", needs: ["recovery"],
    text: "Know what to do after a scam, and see moderated community alerts about patterns." },
];

export default async function home(page, { flags, views }) {
  const on = (needs) => needs.some((n) => flags[n]);
  page.append(
    h("p", { class: "lede" }, "CyberSaathi helps you understand suspicious messages, check claims, make safer decisions and learn how to respond. "
      + "It uses transparent pattern rules, not magic: it shows its evidence, says what it cannot know, and never calls anyone a scammer."),
    h("ol", { class: "flow", "aria-label": "How CyberSaathi helps" }, STEPS.map((s) =>
      h("li", null, h("span", { class: "step" }, s.n),
        on(s.needs) ? h("a", { href: `#/${s.key}` }, s.title) : h("strong", null, s.title),
        h("p", null, s.text), on(s.needs) ? null : h("span", { class: "disabled-note" }, "Not switched on right now.")))),
    h("section", { class: "card" }, h("h2", null, "Good to know"),
      h("ul", { class: "bullets" },
        h("li", null, "Messages you paste are analysed in memory and are not stored."),
        h("li", null, "CyberSaathi never contacts senders, opens links or sends anything for you."),
        h("li", null, "Never share an OTP, PIN, password or recovery code with anyone, including with us."),
        h("li", null, "A pattern match is a reason to check, not proof of fraud. Absence of a warning does not prove safety."))));
  // Note: Element.append(null) would print the word "null", so optional content is appended only when it exists.
  if (views.length <= 1) page.append(h("p", { class: "empty" }, "No features are switched on yet. Ask the site owner to enable them in the Control Centre."));
}
