// Tiny DOM helpers. SAFETY RULES enforced here:
//  * data is only ever inserted as text (textContent / text nodes), never as HTML;
//  * the "style" and "innerHTML" props are refused (the page's CSP forbids inline styles anyway).
const SVG_TAGS = new Set(["svg", "circle", "path", "rect", "line", "g", "text", "polyline", "title"]);
const FORBIDDEN = new Set(["style", "innerhtml", "outerhtml", "srcdoc"]);

export function h(tag, props, ...children) {
  const el = SVG_TAGS.has(tag) && tag !== "title"
    ? document.createElementNS("http://www.w3.org/2000/svg", tag) : document.createElement(tag);
  for (const [key, value] of Object.entries(props || {})) {
    if (value == null || value === false) continue;
    if (FORBIDDEN.has(key.toLowerCase())) throw new Error(`h(): prop "${key}" is not allowed`);
    if (key.startsWith("on") && typeof value === "function") el.addEventListener(key.slice(2).toLowerCase(), value);
    else el.setAttribute(key, value === true ? "" : String(value));
  }
  for (const child of children.flat(Infinity)) {
    if (child == null || child === false) continue;
    el.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return el;
}

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }

// ---------- formatting (null/undefined always becomes an honest "No data", never 0)
export const NO_DATA = "No data";
export const fmtNum = (n) => (n == null ? NO_DATA : Number(n).toLocaleString("en-IN"));
export const fmtPct = (r, digits = 0) => (r == null ? NO_DATA : `${(r * 100).toFixed(digits)}%`);
export function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
}
export function fmtAgo(iso) {
  if (!iso) return "—";
  const secs = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (Number.isNaN(secs)) return "—";
  if (secs < 60) return "just now";
  if (secs < 3600) return `${Math.floor(secs / 60)} min ago`;
  if (secs < 86400) return `${Math.floor(secs / 3600)} h ago`;
  return `${Math.floor(secs / 86400)} d ago`;
}
export function fmtBytes(n) {
  if (n == null) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(i ? 1 : 0)} ${units[i]}`;
}
export function fmtDuration(seconds) {
  if (seconds == null) return "—";
  const d = Math.floor(seconds / 86400), hr = Math.floor((seconds % 86400) / 3600), m = Math.floor((seconds % 3600) / 60);
  return d ? `${d}d ${hr}h` : hr ? `${hr}h ${m}m` : `${m}m`;
}
export const humanize = (s) => String(s ?? "").replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase()).replace(/\bAi\b/g, "AI");

// ---------- tones
const GOOD = new Set(["ok", "ACTIVE", "RESOLVED", "success", "LOW"]);
const BAD = new Set(["down", "failed", "CRITICAL", "HIGH", "SUSPENDED", "unreadable"]);
const WARN = new Set(["degraded", "stale", "MEDIUM", "INVESTIGATING", "OPEN", "PENDING_DELETION", "no_backup_recorded"]);
export function tone(status) {
  if (GOOD.has(status)) return "good";
  if (BAD.has(status)) return "bad";
  if (WARN.has(status)) return "warn";
  return "muted"; // not_configured, not_implemented, no_data, configured_unverified, INFO ...
}
export const badge = (text, t = tone(text)) => h("span", { class: `badge ${t}` }, humanize(text));
export const dot = (t) => h("span", { class: `dot ${t}`, "aria-hidden": "true" });

// ---------- icons (24x24 outline paths)
const ICONS = {
  shield: "M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6l8-3z",
  users: "M16 11a4 4 0 10-8 0 4 4 0 008 0zM4 21c0-4 3.6-6 8-6s8 2 8 6",
  pulse: "M3 12h4l3-8 4 16 3-8h4",
  bell: "M6 17V11a6 6 0 1112 0v6l2 2H4l2-2zM10 21h4",
  chip: "M7 7h10v10H7zM9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4",
  box: "M3 7l9-4 9 4v10l-9 4-9-4V7zM3 7l9 4 9-4M12 11v10",
  db: "M4 6c0-2 16-2 16 0v12c0 2-16 2-16 0V6zM4 12c0 2 16 2 16 0",
  clock: "M12 7v5l3 2M12 3a9 9 0 100 18 9 9 0 000-18z",
  chart: "M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-3",
  list: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01",
  toggle: "M8 7h8a5 5 0 010 10H8A5 5 0 018 7zM8 14a2 2 0 100-4 2 2 0 000 4z",
  tag: "M3 12V4h8l10 10-8 8L3 12zM7.5 8.5h.01",
  alert: "M12 4l9 16H3L12 4zM12 10v4M12 17h.01",
  home: "M4 11l8-7 8 7v9H4v-9z",
  lock: "M6 11h12v9H6zM8 11V8a4 4 0 118 0v3",
  search: "M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5",
  check: "M4 12l5 5L20 6",
  book: "M5 4h10a3 3 0 013 3v13H8a3 3 0 01-3-3V4zM8 20a3 3 0 01-3-3",
  map: "M12 3a9 9 0 100 18 9 9 0 000-18zM12 8a4 4 0 100 8 4 4 0 000-8zM12 11.5a.5.5 0 100 1 .5.5 0 000-1z",
  flag: "M5 21V4M5 4h11l-2 4 2 4H5",
  route: "M6 19a2 2 0 100-4 2 2 0 000 4zM18 9a2 2 0 100-4 2 2 0 000 4zM8 17h6a3 3 0 003-3V9M6 15V9a3 3 0 013-3h7",
  life: "M12 3a9 9 0 100 18 9 9 0 000-18zM12 8a4 4 0 100 8 4 4 0 000-8zM5.6 5.6l3.2 3.2M15.2 15.2l3.2 3.2M18.4 5.6l-3.2 3.2M8.8 15.2l-3.2 3.2",
};
export function icon(name, size = 20) {
  return h("svg", { viewBox: "0 0 24 24", width: size, height: size, fill: "none", stroke: "currentColor",
    "stroke-width": "1.7", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true" },
    h("path", { d: ICONS[name] || ICONS.shield }));
}

// ---------- cards, rings, charts, tables
export function card(title, iconName, ...body) {
  return h("section", { class: "card" },
    h("header", { class: "card-head" }, icon(iconName), h("h2", null, title)), ...body);
}

/** Ring gauge. `ratio` 0..1 or null (no data → empty grey ring and a dash). */
export function ring(ratio, centre, caption, t = "good", size = 132) {
  const r = 52, c = 2 * Math.PI * r;
  const filled = ratio == null ? 0 : Math.max(0, Math.min(1, ratio));
  return h("div", { class: "ring", role: "img", "aria-label": `${caption}: ${centre}` },
    h("svg", { viewBox: "0 0 120 120", width: size, height: size },
      h("circle", { cx: 60, cy: 60, r, class: "ring-track", fill: "none", "stroke-width": 9 }),
      h("circle", { cx: 60, cy: 60, r, class: `ring-fill ${ratio == null ? "muted" : t}`, fill: "none",
        "stroke-width": 9, "stroke-linecap": "round", "stroke-dasharray": `${(filled * c).toFixed(1)} ${c.toFixed(1)}`,
        transform: "rotate(-90 60 60)" })),
    h("div", { class: "ring-text" }, h("strong", { class: String(centre).length > 5 ? "sm" : null }, centre), h("span", null, caption)));
}

/** Simple bar chart. values: [{label, value}]. Every bar has a text tooltip and the chart a text summary. */
export function barChart(points, summary) {
  const W = 600, H = 150, pad = 6, max = Math.max(1, ...points.map((p) => p.value));
  const bw = (W - pad * 2) / Math.max(1, points.length);
  const svg = h("svg", { viewBox: `0 0 ${W} ${H + 18}`, class: "chart", role: "img", "aria-label": summary, preserveAspectRatio: "none" },
    h("line", { x1: 0, y1: H, x2: W, y2: H, class: "axis" }));
  points.forEach((p, i) => {
    const bh = p.value ? Math.max(2, (p.value / max) * (H - 10)) : 0;
    svg.append(h("rect", { x: (pad + i * bw + 1).toFixed(1), y: (H - bh).toFixed(1), width: Math.max(1, bw - 2).toFixed(1),
      height: bh.toFixed(1), rx: 2, class: "bar" }, h("title", null, `${p.label}: ${p.value}`)));
  });
  if (points.length) {
    svg.append(h("text", { x: pad, y: H + 14, class: "axis-label" }, points[0].label),
      h("text", { x: W - pad, y: H + 14, class: "axis-label", "text-anchor": "end" }, points[points.length - 1].label));
  }
  return svg;
}

export function table(columns, rows, { empty = "Nothing to show.", onRow } = {}) {
  if (!rows.length) return h("p", { class: "empty" }, empty);
  const head = h("tr", null, columns.map((c) => h("th", { scope: "col" }, c.label)));
  const body = rows.map((row) => {
    const tr = h("tr", onRow ? { tabindex: 0, class: "clickable", onClick: () => onRow(row),
      onKeydown: (e) => { if (e.key === "Enter") onRow(row); } } : null,
      columns.map((c) => h("td", { "data-label": c.label }, c.render ? c.render(row) : (row[c.key] ?? "—"))));
    return tr;
  });
  return h("div", { class: "table-wrap" }, h("table", null, h("thead", null, head), h("tbody", null, body)));
}

export const empty = (text) => h("p", { class: "empty" }, text);
export const errorBox = (message, retry) => h("div", { class: "error-box", role: "alert" }, h("p", null, message),
  retry ? h("button", { class: "btn small", onClick: retry }, "Try again") : null);
export const kv = (label, value) => h("div", { class: "kv" }, h("span", null, label), h("strong", null, value));

// ---------- toasts and dialogs
export function toast(message, kind = "good") {
  const box = document.getElementById("toasts");
  const t = h("div", { class: `toast ${kind}` }, message);
  box.append(t);
  setTimeout(() => t.remove(), 5000);
}

/** Modal form. fields: [{name,label,type,required,options,hint}] -> resolves to values object or null. */
export function dialog({ title, message, fields = [], confirmLabel = "Confirm", danger = false }) {
  return new Promise((resolve) => {
    const dlg = h("dialog", { class: "modal", "aria-label": title });
    const inputs = {};
    const form = h("form", { method: "dialog" }, h("h3", null, title), message ? h("p", null, message) : null,
      fields.map((f) => {
        const input = f.type === "select"
          ? h("select", { name: f.name }, f.options.map((o) => h("option", { value: o }, humanize(o))))
          : h(f.type === "textarea" ? "textarea" : "input", { name: f.name, type: f.type === "textarea" ? null : (f.type || "text"),
            maxlength: f.maxlength || 500, rows: f.type === "textarea" ? 3 : null, required: f.required, autocomplete: "off" });
        inputs[f.name] = input;
        return h("label", { class: "field" }, h("span", null, f.label), input, f.hint ? h("small", null, f.hint) : null);
      }),
      h("div", { class: "actions" },
        h("button", { type: "button", class: "btn", onClick: () => dlg.close("cancel") }, "Cancel"),
        h("button", { type: "submit", class: `btn ${danger ? "danger" : "primary"}` }, confirmLabel)));
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!form.reportValidity()) return;
      dlg.close("ok");
    });
    dlg.append(form);
    dlg.addEventListener("close", () => {
      const values = dlg.returnValue === "ok"
        ? Object.fromEntries(Object.entries(inputs).map(([k, el]) => [k, el.value])) : null;
      dlg.remove();
      resolve(values);
    });
    document.body.append(dlg);
    dlg.showModal();
  });
}
