// Display names for the fixed choices the backend accepts. tests/test_feature_guards.py checks these lists
// against the backend so the two cannot silently drift apart.
export const SCAM_TYPES = {
  FAKE_INTERNSHIP: "Fake internship offer", SCHOLARSHIP_FEE: "Scholarship fee request", QR_PAYMENT: "QR-code or collect-request payment trick",
  INSTITUTION_IMPERSONATION: "Pretending to be a college or institution", FAKE_SUPPORT: "Fake customer support",
  OTP_REQUEST: "Request for an OTP or secret code", OTHER: "Something else",
};
export const CHANNELS = { WHATSAPP: "WhatsApp", TELEGRAM: "Telegram", SMS: "SMS", EMAIL: "Email", PHONE_CALL: "Phone call", SOCIAL_MEDIA: "Social media", WEBSITE: "Website", OTHER: "Other" };
export const TACTICS = {
  URGENCY: "Urgency or a short deadline", PAYMENT_REQUEST: "Asked for a payment", SECRECY: "Asked me to keep it secret",
  CHANNEL_SHIFT: "Moved me to a private chat", AUTHORITY_CLAIM: "Claimed to be an official authority",
  REMOTE_ACCESS: "Asked me to install a remote-access app", SECRET_CODES: "Asked for an OTP, PIN or password", PERSONAL_INFO_REQUEST: "Asked for personal information",
};
export const CLAIM_TYPES = { COMPANY: "A company", INTERNSHIP: "An internship", SCHOLARSHIP: "A scholarship", COMPETITION: "A competition", INSTITUTION: "An educational institution", ONLINE_OPPORTUNITY: "An online opportunity" };
export const SOURCE_TYPES = {
  OFFICIAL_WEBSITE: "The organisation's own official website", GOVERNMENT_REGISTRY: "A government or regulator record",
  INSTITUTION_CONFIRMATION: "Confirmation from my college or institution", DIRECT_CONTACT: "I contacted them using details I found myself",
  INDEPENDENT_NEWS: "Independent news or review source", MESSAGE_ONLY: "Only the message I received", OTHER: "Another source",
};
export const SUPPORTS = { SUPPORTS: "Supports the claim", CONTRADICTS: "Contradicts the claim", NEUTRAL: "Neither" };
export const SITUATIONS = {
  SHARED_INFORMATION: "I shared information or a code", COMPROMISED_ACCOUNT: "My account may be compromised",
  FRAUDULENT_PAYMENT: "I made a payment I now doubt", SUSPICIOUS_OFFER: "I got a suspicious internship or scholarship offer",
};
