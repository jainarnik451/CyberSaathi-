// Pieces shared by several pages. Everything is inserted as text through h(); nothing is HTML.
import { badge, h, icon } from "./dom.js";

export const LEVEL_TONE = { NOT_ENOUGH_SIGNALS: "muted", SOME_CONCERNS: "warn", STRONG_CONCERNS: "bad" };
export const SENS_TONE = { CRITICAL: "bad", HIGH: "bad", MEDIUM: "warn", LOW: "muted" };
export const STATUS_TONE = { VERIFIED: "good", WARNING: "bad", UNKNOWN: "muted" };

/** One consistent risk indicator used on every page that reports a level. */
export function riskBanner(indicator, level) {
  return h("div", { class: `risk ${LEVEL_TONE[level] || "muted"}`, role: "status", "data-testid": "risk-banner" },
    icon(level === "STRONG_CONCERNS" ? "alert" : level === "SOME_CONCERNS" ? "alert" : "shield", 26),
    h("div", null, h("strong", null, indicator.label), h("p", null, indicator.headline)));
}

export const list = (items, cls = "bullets") => h("ul", { class: cls }, items.map((t) => h("li", null, t)));

export function section(title, ...body) { return h("section", { class: "block-section" }, h("h3", null, title), ...body); }

export function loading(text = "Working…") { return h("p", { class: "loading", role: "status" }, text); }

/** Loading → result/error runner for a button-driven request. */
export async function run(button, slot, task, render, showError) {
  button.disabled = true;
  slot.replaceChildren(loading());
  try { slot.replaceChildren(render(await task())); }
  catch (err) { slot.replaceChildren(showError(err)); }
  finally { button.disabled = false; }
}

export function evidenceBlock(quote, context) {
  return h("figure", { class: "evidence" }, h("blockquote", null, `“${quote}”`),
    context && context !== quote ? h("figcaption", null, "In context: ", context) : null);
}

export function sensitivityBadge(s) { return badge(s.toLowerCase(), SENS_TONE[s] || "muted"); }
