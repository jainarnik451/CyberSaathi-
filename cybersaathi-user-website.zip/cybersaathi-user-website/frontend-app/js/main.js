import { api, ApiError } from "./api.js";
import { clear, errorBox, h, icon, toast } from "./dom.js";
import home from "./views/home.js";
import analyse from "./views/analyse.js";
import proofpass from "./views/proofpass.js";
import safechoice from "./views/safechoice.js";
import recovery from "./views/recovery.js";
import community from "./views/community.js";
import manual, { manualContent } from "./views/manual.js";

// A page is listed only when its feature is switched on. The server enforces the same flags on every call.
const VIEWS = [
  { key: "home", label: "Home", icon: "home", render: home, needs: [] },
  { key: "analyse", label: "Analyse a conversation", icon: "search", render: analyse, needs: ["scam_journey", "digital_footprint"], any: true },
  { key: "proofpass", label: "ProofPass", icon: "check", render: proofpass, needs: ["trustcheck"] },
  { key: "safechoice", label: "SafeChoice practice", icon: "book", render: safechoice, needs: ["learning"] },
  { key: "recovery", label: "Recovery Navigator", icon: "life", render: recovery, needs: ["recovery"] },
  { key: "community", label: "Community alerts", icon: "flag", render: community, needs: ["community"] },
  { key: "manual", label: "Manual", icon: "book", render: manual, needs: [] },
];
const root = document.getElementById("root");
let session = { user: null, flags: {} };

const allowedViews = () => VIEWS.filter((v) => !v.needs.length || (v.any ? v.needs.some((n) => session.flags[n]) : v.needs.every((n) => session.flags[n])));

// ---------------------------------------------------------------- sign-in / sign-up
const authLogo = () => h("img", { class: "auth-logo", src: "assets/logo-wordmark.png", alt: "CyberSaathi", width: 900, height: 344 });
const sideLogo = () => h("img", { class: "brand-mark", src: "assets/logo-mark.png", alt: "", width: 34, height: 34 });

function authFrame(title, ...body) {
  clear(root).append(h("main", { class: "auth", id: "main" },
    h("div", { class: "auth-card" }, authLogo(), h("h1", null, title), ...body)));
}

function tabs(active) {
  return h("div", { class: "auth-tabs", role: "group", "aria-label": "Account" },
    h("button", { class: "btn", "aria-pressed": String(active === "login"), onClick: () => showLogin() }, "Sign in"),
    h("button", { class: "btn", "aria-pressed": String(active === "register"), onClick: () => showRegister() }, "Create account"));
}

function showManual() {
  clear(root).append(h("main", { class: "auth wide-auth", id: "main" },
    h("div", { class: "auth-card" }, authLogo(),
      h("h1", null, "How to use CyberSaathi"), manualContent(),
      h("button", { class: "btn primary", onClick: () => showLogin() }, "Back to sign in"))));
}

function field(label, input) { return h("label", { class: "field" }, h("span", null, label), input); }

function showLogin(notice) {
  const msg = h("p", { class: "form-error", role: "alert" }, notice || "");
  const email = h("input", { type: "email", name: "email", required: true, autocomplete: "username", maxlength: 254 });
  const password = h("input", { type: "password", name: "password", required: true, autocomplete: "current-password", maxlength: 256 });
  const button = h("button", { class: "btn primary wide", type: "submit" }, "Sign in");
  const form = h("form", { class: "stack" }, field("Email", email), field("Password", password), msg, button);
  const help = h("p", { class: "note", hidden: true },
    "Just created your account? You must verify your email before you can sign in. ",
    h("button", { type: "button", class: "linklike", onClick: () => showVerify(email.value.trim()) }, "Enter or resend your code"));
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); button.disabled = true; msg.textContent = ""; help.hidden = true;
    try {
      const res = await api("/auth/login", { method: "POST", body: { email: email.value.trim(), password: password.value } });
      password.value = "";
      if (res.status === "mfa_required") return showMfa();
      if (res.status === "mfa_enrollment_required") return showStaffNote();
      await boot();
    } catch (err) {
      password.value = ""; msg.textContent = err instanceof ApiError ? err.message : "Something went wrong."; button.disabled = false;
      help.hidden = !(err instanceof ApiError && err.status === 401);
    }
  });
  authFrame("Welcome back", tabs("login"), form, help,
    h("button", { type: "button", class: "linklike", onClick: () => showForgot(email.value.trim()) }, "Forgot your password?"),
    h("p", { class: "note" }, "CyberSaathi never asks for your OTP, PIN or bank details. Do not type them here."),
    h("button", { type: "button", class: "linklike", onClick: showManual }, "New here? How to use CyberSaathi (manual)"));
  email.focus();
}

function showRegister() {
  const msg = h("p", { class: "form-error", role: "alert" });
  const email = h("input", { type: "email", name: "email", required: true, autocomplete: "email", maxlength: 254 });
  const password = h("input", { type: "password", name: "password", required: true, autocomplete: "new-password", maxlength: 256, minlength: 12 });
  const button = h("button", { class: "btn primary wide", type: "submit" }, "Create account");
  const form = h("form", { class: "stack" }, field("Email", email), field("Choose a password (at least 12 characters)", password), msg, button);
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); button.disabled = true; msg.textContent = "";
    try {
      await api("/auth/register", { method: "POST", body: { email: email.value.trim(), password: password.value } });
      password.value = ""; showVerify(email.value.trim());
    } catch (err) { msg.textContent = err.message; button.disabled = false; }
  });
  authFrame("Create your account", tabs("register"), form,
    h("button", { type: "button", class: "linklike", onClick: showManual }, "New here? How to use CyberSaathi (manual)"));
  email.focus();
}

function showVerify(emailText, prefill) {
  const msg = h("p", { class: "form-error", role: "alert" });
  const info = h("p", { class: "note", role: "status" });
  const token = h("input", { name: "token", required: true, autocomplete: "off", maxlength: 200, minlength: 10, value: prefill || "" });
  const password = h("input", { type: "password", name: "password", required: true, autocomplete: "current-password", maxlength: 256 });
  const email = h("input", { type: "email", name: "email", autocomplete: "email", maxlength: 254, value: emailText || "" });
  const button = h("button", { class: "btn primary wide", type: "submit" }, "Verify email");
  const resend = h("button", { type: "button", class: "btn", onClick: async () => {
    msg.textContent = ""; info.textContent = "";
    if (!email.value.trim()) { msg.textContent = "Enter your email address above first."; email.focus(); return; }
    resend.disabled = true;
    try {
      await api("/auth/resend-verification", { method: "POST", body: { email: email.value.trim() } });
      info.textContent = "If that account is waiting for verification, a new code has been sent. It can take a minute; check your spam folder too.";
    } catch (err) { msg.textContent = err.message; }
    setTimeout(() => { resend.disabled = false; }, 30000);  // gentle brake; the server also rate-limits
  } }, "Send me a new code");
  const form = h("form", { class: "stack" }, field("Your email address", email), field("Code from the email", token),
    field("Your password again (the one you chose when creating the account)", password), msg, info, button, resend);
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); button.disabled = true; msg.textContent = ""; info.textContent = "";
    try {
      await api("/auth/verify-email", { method: "POST", body: { token: token.value.trim(), password: password.value } });
      password.value = ""; showLogin("Email verified. Please sign in.");
    } catch (err) { msg.textContent = err.message; button.disabled = false; }
  });
  authFrame("Check your email",
    h("p", { class: "muted-text" }, emailText
      ? `If ${emailText} can be registered, we have sent it a verification email. Paste the code from it below, or open the link in the email. It can take a minute; check your spam folder too.`
      : "Paste the code from your verification email, or open the link in the email."), form,
    h("button", { class: "linklike", onClick: () => showLogin() }, "Back to sign in"));
  (prefill ? password : token).focus();
}

function showForgot(emailText) {
  const msg = h("p", { class: "form-error", role: "alert" });
  const info = h("p", { class: "note", role: "status" });
  const email = h("input", { type: "email", name: "email", required: true, autocomplete: "email", maxlength: 254, value: emailText || "" });
  const button = h("button", { class: "btn primary wide", type: "submit" }, "Send reset email");
  const form = h("form", { class: "stack" }, field("Your email address", email), msg, info, button);
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); button.disabled = true; msg.textContent = ""; info.textContent = "";
    try {
      await api("/auth/forgot-password", { method: "POST", body: { email: email.value.trim() } });
      info.textContent = "If that email has an account, a reset code has been sent. It can take a minute; check your spam folder too.";
    } catch (err) { msg.textContent = err.message; }
    button.disabled = false;
  });
  authFrame("Reset your password", form,
    h("button", { class: "linklike", onClick: () => showReset() }, "I already have a reset code"),
    h("button", { class: "linklike", onClick: () => showLogin() }, "Back to sign in"));
  email.focus();
}

function showReset(prefill) {
  const msg = h("p", { class: "form-error", role: "alert" });
  const token = h("input", { name: "token", required: true, autocomplete: "off", maxlength: 200, minlength: 10, value: prefill || "" });
  const password = h("input", { type: "password", name: "new_password", required: true, autocomplete: "new-password", maxlength: 256, minlength: 12 });
  const button = h("button", { class: "btn primary wide", type: "submit" }, "Set new password");
  const form = h("form", { class: "stack" }, field("Reset code from the email", token), field("New password (at least 12 characters)", password), msg, button);
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); button.disabled = true; msg.textContent = "";
    try {
      await api("/auth/reset-password", { method: "POST", body: { token: token.value.trim(), new_password: password.value } });
      password.value = ""; showLogin("Password changed. Please sign in with your new password.");
    } catch (err) { msg.textContent = err.message; password.value = ""; button.disabled = false; }
  });
  authFrame("Choose a new password", form, h("button", { class: "linklike", onClick: () => showLogin() }, "Back to sign in"));
  (prefill ? password : token).focus();
}

function showMfa() {
  const msg = h("p", { class: "form-error", role: "alert" });
  const code = h("input", { name: "code", inputmode: "numeric", pattern: "[0-9]{6}", maxlength: 6, minlength: 6, required: true, autocomplete: "one-time-code", class: "code" });
  const button = h("button", { class: "btn primary wide", type: "submit" }, "Verify");
  const form = h("form", { class: "stack" }, field("6-digit code from your authenticator app", code), msg, button);
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); button.disabled = true; msg.textContent = "";
    try { await api("/auth/mfa/verify", { method: "POST", body: { code: code.value.trim() } }); await boot(); }
    catch (err) { msg.textContent = err.message; code.value = ""; button.disabled = false; code.focus(); }
  });
  authFrame("Two-step verification", form, h("button", { class: "linklike", onClick: signOut }, "Use a different account"));
  code.focus();
}

function showStaffNote() {
  authFrame("Use the Founder Control Centre", h("p", null, "This account has staff access, which needs two-step verification. Set it up in the Founder Control Centre at /owner-ui/, then come back."),
    h("button", { class: "btn", onClick: signOut }, "Sign out"));
}

async function signOut() {
  try { await api("/auth/logout", { method: "POST" }); } catch { /* already signed out */ }
  session = { user: null, flags: {} };
  showLogin();
}

// ---------------------------------------------------------------- shell
function showApp(user) {
  const views = allowedViews();
  const main = h("main", { id: "main", tabindex: -1 });
  const nav = h("nav", { "aria-label": "CyberSaathi" }, views.map((v) =>
    h("a", { href: `#/${v.key}`, "data-key": v.key }, icon(v.icon, 18), h("span", null, v.label))));
  clear(root).append(h("div", { class: "shell" },
    h("aside", { class: "sidebar" }, h("div", { class: "brand" }, sideLogo(), h("span", null, "CyberSaathi")), nav,
      h("div", { class: "who" }, h("strong", null, user.email), h("button", { class: "btn small", onClick: signOut }, "Sign out"))),
    main));

  let token = 0;
  async function route() {
    const wanted = location.hash.replace(/^#\/?/, "");
    const view = views.find((v) => v.key === wanted) || views[0], mine = ++token;
    nav.querySelectorAll("a").forEach((a) => a.toggleAttribute("aria-current", a.dataset.key === view.key));
    clear(main).append(h("p", { class: "loading" }, "Loading…"));
    const page = h("div", { class: "page" }, h("h1", null, view.label));
    try { await view.render(page, { user, flags: session.flags, views }); }
    catch (err) { page.append(errorBox(err instanceof ApiError ? err.message : "This page failed to load.", route)); }
    if (mine === token) { clear(main).append(page); main.focus({ preventScroll: true }); }
  }
  window.onhashchange = route;
  route();
}

// Links in emails look like  /app/#/verify?token=...  The token sits after the "#", so the browser never sends it to
// any server and it does not end up in server logs. We read it once and remove it from the address bar.
function takeEmailLink() {
  const m = /^#\/(verify|reset)\?token=([\w-]{10,200})$/.exec(location.hash);
  if (!m) return null;
  history.replaceState(null, "", location.pathname + location.search);
  return { kind: m[1], token: m[2] };
}

async function boot() {
  const link = takeEmailLink();
  if (link) return link.kind === "verify" ? showVerify("", link.token) : showReset(link.token);
  let me;
  try { me = await api("/auth/me"); }
  catch (err) {
    if (err.status === 401) return showLogin();
    clear(root).append(h("main", { class: "auth" }, errorBox(err.message, boot)));
    return;
  }
  if (me.mfa_enrollment_required) return showStaffNote();
  if (!me.mfa_passed && me.user.mfa_enabled) return showMfa();
  try { session.flags = (await api("/features")).features || {}; } catch { session.flags = {}; }
  session.user = me.user;
  showApp(me.user);
}

window.addEventListener("cs-auth-expired", () => {
  if (session.user) { session = { user: null, flags: {} }; showLogin("Your session ended. Please sign in again."); toast("Session ended", "warn"); }
});
boot();
