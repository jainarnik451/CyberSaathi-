// All server calls. Same-origin, cookie session, CSRF header echoed from the readable CSRF cookie.
const BASE = "/api/v1";

export class ApiError extends Error {
  constructor(status, message, detail) { super(message); this.status = status; this.detail = detail; }
}

function csrfToken() {
  const m = document.cookie.match(/(?:^|;\s*)cs_csrf=([^;]*)/);
  return m ? decodeURIComponent(m[1]) : "";
}

function messageFrom(detail, status) {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail) && detail.length) return detail.map((d) => d.message || String(d)).join(" ");
  if (status === 429) return "Too many requests. Please wait a minute and try again.";
  if (status === 503) return "The server is busy. Please try again shortly.";
  return `Request failed (${status}).`;
}

export async function api(path, { method = "GET", body } = {}) {
  const headers = { Accept: "application/json" };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET") headers["X-CSRF-Token"] = csrfToken();
  let res;
  try {
    res = await fetch(BASE + path, { method, headers, credentials: "same-origin", cache: "no-store",
      body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new ApiError(0, "Cannot reach the server. Is the backend running?", null);
  }
  let data = null;
  try { data = await res.json(); } catch { /* empty or non-JSON body */ }
  if (!res.ok) {
    const detail = data && data.detail;
    if (res.status === 401 && !path.startsWith("/auth/login")) window.dispatchEvent(new Event("cs-auth-expired"));
    throw new ApiError(res.status, messageFrom(detail, res.status), detail);
  }
  return data;
}

export const qs = (params) => {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== "" && v != null) u.set(k, v);
  const s = u.toString();
  return s ? `?${s}` : "";
};
