# Put CyberSaathi on the internet (public website)

**Result:** people open `https://your-site-address` in Chrome, Firefox, Brave, Edge or Safari, read the manual, create an account and use the tools. This package contains **only the user website**. The Founder Control Centre is not inside it.

**Honest status:** the website's code was tested in pieces (pure logic, a test mail server, a browser against a pretend server). It has **not** been started against a real database on a real host. The `Dockerfile` has not been built here. Expect to fix a first-run problem or two; send me the error lines.

## Read this first: this is NOT a "static website"
CyberSaathi has accounts, a database and email, so it needs a **server** that runs the program. Hosts that only show files (GitHub Pages, Netlify drag-and-drop, Vercel static, Firebase Hosting without a backend, Cloudflare Pages) will show **"Not Found"** because this package has no `index.html` at its top level, and even a working page could not sign anyone in. Use a host that runs a **Docker web service** (section 3).

## 0. What you need
- A hosting account that runs Docker containers and offers PostgreSQL and HTTPS automatically. Examples: Render, Railway, Fly.io. Plans, prices and screens change, so check current pricing and whether the free database is permanent before relying on it. A database that is deleted after a trial would delete your users.
- A GitHub account (most hosts deploy from a GitHub repository).
- An email account for sending (Gmail with an App password works for a small start; a real sending service is better as you grow).
- Optional: your own domain name.

## 1. Upload the code (private repository)
1. Create a **private** repository on GitHub.
2. Unzip this package and upload everything (the `Dockerfile`, `backend`, `frontend-app`, guides).
3. Do **not** upload any `.env` file. There is none in this package; keep it that way.

## 2. Create the database
1. At your host choose **New PostgreSQL**. Name it `cybersaathi`.
2. Copy its **internal** connection address. Change the start to `postgresql+psycopg://` (if it begins `postgres://` or `postgresql://`, replace that part only).

## 3. Create the web service
1. Choose **New Web Service**, connect the repository, and select the **Docker** option (it finds the `Dockerfile`).
2. Choose the region closest to your users (for India, Singapore or Mumbai if offered).
3. Add the environment variables from `env.production.example` on the host's Environment page. Fill every `<...>`.
   - Make the secret key with `python -c "import secrets; print(secrets.token_urlsafe(48))"` and **save a private copy**: the owner laptop needs the same value.
   - `CYBERSAATHI_FRONTEND_BASE_URL` and `CYBERSAATHI_CORS_ORIGINS` must be your final `https://` address. If you only know it after the first deploy, deploy once, then fix both and redeploy.
4. Deploy. Wait for "Live".

## 4. Check it (do each one)
1. Open `https://your-address/readyz`. It must show `"status":"ok"`. If it shows `database_unavailable`, the database address is wrong.
2. Open `https://your-address/`. You should land on the sign-in page. Press **New here? How to use CyberSaathi** to confirm the manual opens.
3. Create an account with a real email address of yours. The email must arrive with a code and a link. Verify, sign in, run one analysis.
4. Open `https://your-address/owner-ui/`. It must say **Not Found**. If the dashboard appears, stop and tell me immediately.
5. Open `https://your-address/docs`. It must be **Not Found** (production hides it).

## 5. Your own domain (optional)
In the host's **Custom domain** page add your domain and copy the DNS records it shows to your domain seller. HTTPS is issued automatically. Then update the two address variables and redeploy.

## 6. Before you tell the public
- [ ] All five checks above pass.
- [ ] Database backups are switched on at your host and you know how to restore one.
- [ ] You can read the host's logs, and no log line shows a password or a code.
- [ ] The privacy and "data deletion" promises you make match what the app really does (users can delete accounts; the owner runs `process-deletions`; ask me to schedule it).
- [ ] You told users CyberSaathi is a decision-support tool, not a guarantee.
Known gaps: no proper database migrations yet (tables are created if missing; changing the database design later needs migration work), limits are kept in memory so they reset on restart and apply per running copy (run one copy), no check by a security professional, no load testing.

## 6b. If you see "Not Found"
Open these three addresses and compare:
| Address | Good result | If not |
|---|---|---|
| `https://your-address/healthz` | `{"status":"ok"}` | Nothing is running the program: you used a file-only host, or the service did not start. Open the host's **Logs** page and read the last lines. |
| `https://your-address/` | jumps to `/app/` and shows the sign-in page | Opens but `/app/` says Not Found: the `frontend-app` folder is missing from your repository. |
| `https://your-address/readyz` | `{"status":"ok"}` | `database_unavailable`: wrong database address (it must start with `postgresql+psycopg://`). |
Also check the repository: `Dockerfile`, `backend` and `frontend-app` must be at the **top level** of the repository, not inside an extra folder called `cybersaathi-user-website`.

## 7. Updating later
Push changes to GitHub; the host redeploys. Take a database backup first.

## 8. Do not
Do not set `CYBERSAATHI_SITE_MODE` to anything else. Do not add `.env` files. Do not turn on community alerts until you have time to review reports.
